// screens/card_payment_screen.dart
import 'package:flutter/material.dart';
import 'thank_you_screen.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';


class CardPaymentScreen extends StatefulWidget {
  final String title;
  final String planId;
  final double price;
  final String category;
  const CardPaymentScreen({
    super.key,
    required this.title,
    required this.planId,
    required this.price,
    required this.category,});


  @override
  State<CardPaymentScreen> createState() => _CardPaymentScreenState();
}

class _CardPaymentScreenState extends State<CardPaymentScreen> {
  final _formKey = GlobalKey<FormState>();
  final _nameController = TextEditingController();
  final _cardNumberController = TextEditingController();
  final _cvcController = TextEditingController();
  final _monthController = TextEditingController();
  final _yearController = TextEditingController();

  @override
  void dispose() {
    _nameController.dispose();
    _cardNumberController.dispose();
    _cvcController.dispose();
    _monthController.dispose();
    _yearController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        backgroundColor: Colors.black,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.white),
          onPressed: () => Navigator.pop(context),
        ),
        elevation: 0,
      ),
      body: SafeArea(
        child: LayoutBuilder(
          builder: (context, constraints) {
            return SingleChildScrollView(
              child: ConstrainedBox(
                constraints: BoxConstraints(
                  minHeight: constraints.maxHeight,
                ),
                child: IntrinsicHeight(
                  child: Padding(
                    padding: const EdgeInsets.all(20),
                    child: Form(
                      key: _formKey,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          // Title
                          Container(
                            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                            decoration: BoxDecoration(
                              color: Colors.white,
                              borderRadius: BorderRadius.circular(4),
                            ),
                            child: const Text(
                              'Card Payment',
                              style: TextStyle(
                                color: Colors.black,
                                fontSize: 16,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ),

                          const SizedBox(height: 30),

                          // Form fields
                          _buildInputField(
                            'Name of Card:',
                            _nameController,
                            TextInputType.text,
                          ),
                          _buildInputField(
                            'Card Number:',
                            _cardNumberController,
                            TextInputType.number,
                          ),
                          _buildInputField(
                            'CVC:',
                            _cvcController,
                            TextInputType.number,
                          ),
                          _buildInputField(
                            'Expiration Month:',
                            _monthController,
                            TextInputType.number,
                          ),
                          _buildInputField(
                            'Expiration Year:',
                            _yearController,
                            TextInputType.number,
                          ),

                          // 使用Expanded而不是Spacer来避免overflow
                          const Expanded(
                            child: SizedBox(height: 20),
                          ),

                          // Pay Now button
                          SizedBox(
                            width: double.infinity,
                            child: ElevatedButton(
                              onPressed: () => _navigateToThankYou(context),
                              style: ElevatedButton.styleFrom(
                                backgroundColor: Colors.deepPurple,
                                padding: const EdgeInsets.symmetric(vertical: 16),
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(25),
                                ),
                              ),
                              child: const Text(
                                'Pay Now',
                                style: TextStyle(
                                  color: Colors.white,
                                  fontSize: 18,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                            ),
                          ),

                          const SizedBox(height: 20), // 底部安全间距
                        ],
                      ),
                    ),
                  ),
                ),
              ),
            );
          },
        ),
      ),
    );
  }

  Widget _buildInputField(String label, TextEditingController controller, TextInputType keyboardType) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          label,
          style: const TextStyle(
            color: Colors.white,
            fontSize: 16,
          ),
        ),
        const SizedBox(height: 8),
        Container(
          width: double.infinity,
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(4),
          ),
          child: TextFormField(
            controller: controller,
            keyboardType: keyboardType,
            style: const TextStyle(
              color: Colors.black,
              fontSize: 16,
            ),
            decoration: const InputDecoration(
              border: InputBorder.none,
              contentPadding: EdgeInsets.symmetric(horizontal: 16, vertical: 15),
              fillColor: Colors.white,
              filled: true,
            ),
            validator: (value) {
              if (value == null || value.isEmpty) {
                return 'Please enter ${label.toLowerCase()}';
              }
              return null;
            },
          ),
        ),
        const SizedBox(height: 20),
      ],
    );
  }

  // 修复后的支付处理方法
  void _navigateToThankYou(BuildContext context) async {
    if (_formKey.currentState!.validate()) {
      try {
        final user = FirebaseAuth.instance.currentUser;
        if (user == null) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('User not logged in')),
          );
          return;
        }

        final firestore = FirebaseFirestore.instance;

        print('🔄 开始处理支付...');

        // 1. 首先确保courses集合中有对应的课程文档
        final courseRef = firestore.collection('courses').doc(widget.planId);
        final courseDoc = await courseRef.get();

        if (!courseDoc.exists) {
          // 如果课程文档不存在，创建它
          await courseRef.set({
            'title': widget.title,
            'category': widget.category,
            'description': _getCourseDescription(widget.title),
            'price': widget.price,
            'imageUrl': _getCourseImageUrl(widget.title),
            'createdAt': FieldValue.serverTimestamp(),
          });
          print('✅ 创建了课程文档: ${widget.planId}');
        } else {
          print('✅ 课程文档已存在: ${widget.planId}');
        }

        // 2. 然后写入 user_courses 集合
        await firestore.collection('user_courses').add({
          'userId': user.uid,
          'courseId': widget.planId,
          'title': widget.title,
          'category': widget.category,
          'status': 'active',
          'purchaseDate': Timestamp.now(),
          'remainingSessions': 8,
          'totalSessions': 8,
          'paymentAmount': widget.price,
          'expiryDate': Timestamp.fromDate(DateTime.now().add(const Duration(days: 30))),
          'isMainCourse': false,
          'createdAt': FieldValue.serverTimestamp(),
        });

        print('✅ 用户课程记录已保存');

        // 显示成功消息
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(
              content: Text('🎉 Payment successful! Course added to your library.'),
              backgroundColor: Colors.green,
            ),
          );
        }

        // 跳转到 Thank You 页面
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) => const ThankYouScreen(),
          ),
        );
      } catch (e) {
        print('❌ 支付处理失败: $e');
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Payment failed: $e')),
        );
      }
    }
  }

  // 获取课程描述的辅助方法
  String _getCourseDescription(String title) {
    switch (title) {
      case 'Muscle Building Plan':
        return 'Build lean muscle and increase strength with our comprehensive muscle building program.';
      case 'Fat Burning Program':
        return 'Burn calories and lose fat with high-intensity interval training and cardio workouts.';
      case 'Core & Posture Training':
        return 'Strengthen your core and improve posture with targeted exercises and techniques.';
      default:
        return 'Comprehensive fitness program designed to meet your specific goals.';
    }
  }

  // 获取课程图片URL的辅助方法（可选）
  String? _getCourseImageUrl(String title) {
    switch (title) {
      case 'Muscle Building Plan':
        return 'assets/images/muscle_building.jpg';
      case 'Fat Burning Program':
        return 'assets/images/fat_burning.jpg';
      case 'Core & Posture Training':
        return 'assets/images/core_training.jpg';
      default:
        return null;
    }
  }
}