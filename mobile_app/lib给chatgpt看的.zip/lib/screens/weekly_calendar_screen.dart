// screens/weekly_calendar_screen.dart
import 'package:flutter/material.dart';
import 'appointment_schedule_screen.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';

class WeeklyCalendarScreen extends StatefulWidget {
  const WeeklyCalendarScreen({super.key});

  @override
  State<WeeklyCalendarScreen> createState() => _WeeklyCalendarScreenState();
}

class _WeeklyCalendarScreenState extends State<WeeklyCalendarScreen> {
  int _selectedIndex = 1;
  DateTime selectedDate = DateTime.now();
  String selectedCoachId = 'coach1';
  String selectedGymId = 'gym1';
  Map<String, dynamic>? latestAppointment;

  @override
  void initState() {
    super.initState();
    _loadLatestAppointment();
  }

  void _onItemTapped(int index) async {
    setState(() {
      _selectedIndex = index;
    });

    if (index == 1) {
      final result = await Navigator.push(
        context,
        MaterialPageRoute(
          builder: (context) => AppointmentScheduleScreen(
            preselectedDate: selectedDate,
            preselectedCoachId: selectedCoachId,
            preselectedGymId: selectedGymId,
          ),
        ),
      );

      if (result != null && result is Map<String, dynamic>) {
        setState(() {
          selectedDate = result['date'] ?? selectedDate;
          selectedCoachId = result['coachId'] ?? selectedCoachId;
          selectedGymId = result['gymId'] ?? selectedGymId;
        });
        _loadLatestAppointment();
      }
    } else {
      Navigator.pushReplacementNamed(context, '/main', arguments: {'initialIndex': index});
    }
  }

  Future<void> _loadLatestAppointment() async {
    final user = FirebaseAuth.instance.currentUser;
    if (user == null) return;

    final snapshot = await FirebaseFirestore.instance
        .collection('appointments')
        .where('userId', isEqualTo: user.uid)
        .orderBy('date', descending: true)
        .limit(1)
        .get();

    if (snapshot.docs.isNotEmpty) {
      final appointmentData = snapshot.docs.first.data();

      String? coachName;
      if (appointmentData['coachId'] != null) {
        final coachDoc = await FirebaseFirestore.instance.collection('coaches').doc(appointmentData['coachId']).get();
        coachName = coachDoc.data()?['name'] ?? 'Unknown Coach';
      }

      String? gymName;
      if (appointmentData['gymId'] != null) {
        final gymDoc = await FirebaseFirestore.instance.collection('gyms').doc(appointmentData['gymId']).get();
        gymName = gymDoc.data()?['name'] ?? 'Unknown Gym';
      }

      setState(() {
        latestAppointment = {
          ...appointmentData,
          'coachName': coachName,
          'gymName': gymName,
          'date': appointmentData['date'] is Timestamp
              ? appointmentData['date']
              : Timestamp.fromDate(DateTime.parse(appointmentData['date'])),
        };
      });
    } else {
      setState(() {
        latestAppointment = null;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(title: const Text('Weekly Calendar',style: TextStyle(color: Colors.black),),
        backgroundColor: Colors.white,),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [

            const SizedBox(height: 24),
            Container(
              padding: const EdgeInsets.all(16.0),
              decoration: BoxDecoration(
                color: Colors.deepOrangeAccent,
                borderRadius: BorderRadius.circular(12),
              ),
              child: Center(
                child: (latestAppointment != null && latestAppointment!['date'] != null && latestAppointment!['date'] is Timestamp)
                    ? Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text("Appointment Date: ${(latestAppointment!['date'] as Timestamp).toDate().toLocal().toString().split(" ")[0]}", style: const TextStyle(fontSize: 16)),
                    const SizedBox(height: 8),
                    Text("Coach: ${latestAppointment!['coachName'] ?? ''}", style: const TextStyle(fontSize: 16)),
                    const SizedBox(height: 8),
                    Text("Gym: ${latestAppointment!['gymName'] ?? ''}", style: const TextStyle(fontSize: 16)),
                    const SizedBox(height: 8),
                    Text("Time Slot: ${latestAppointment!['timeSlot'] ?? ''}", style: const TextStyle(fontSize: 16)),
                  ],
                )
                    : const Text('No appointment scheduled.', style: TextStyle(fontSize: 16)),
              ),
            ),
            const SizedBox(height: 24),
            ElevatedButton(
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => AppointmentScheduleScreen(
                      preselectedDate: selectedDate,
                      preselectedCoachId: selectedCoachId,
                      preselectedGymId: selectedGymId,
                    ),
                  ),
                );
              },
              child: const Text('Make/Change Appointment'),
              style: ElevatedButton.styleFrom(
                padding: const EdgeInsets.symmetric(vertical: 16),
                textStyle: const TextStyle(fontSize: 18),
              ),
            ),
          ],
        ),
      ),
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _selectedIndex,
        onTap: _onItemTapped,
        backgroundColor: Colors.white,
        selectedItemColor: Colors.deepPurple,
        unselectedItemColor: Colors.grey,
        items: const [
          BottomNavigationBarItem(icon: Icon(Icons.home), label: 'Home'),
          BottomNavigationBarItem(icon: Icon(Icons.calendar_today), label: 'Schedule'),
          BottomNavigationBarItem(icon: Icon(Icons.analytics), label: 'Analytics'),
          BottomNavigationBarItem(icon: Icon(Icons.chat), label: 'Chat'),
        ],
      ),
    );
  }
}
