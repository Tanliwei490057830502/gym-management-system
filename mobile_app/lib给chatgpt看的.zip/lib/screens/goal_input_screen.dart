import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'aI_plan_result_screen.dart';

class GoalInputScreen extends StatefulWidget {
  final Function(String) onPlanGenerated;

  const GoalInputScreen({super.key, required this.onPlanGenerated});

  @override
  State<GoalInputScreen> createState() => _GoalInputScreenState();
}

class _GoalInputScreenState extends State<GoalInputScreen> {
  final _formKey = GlobalKey<FormState>();
  String _goalType = 'Fat Loss';
  double _weightChange = 0;
  int _durationDays = 30;
  double? _currentWeight;
  double? _height;

  final TextEditingController _weightController = TextEditingController();
  final TextEditingController _durationController = TextEditingController();

  final FirebaseAuth _auth = FirebaseAuth.instance;
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  Future<void> _submit() async {
    if (!_formKey.currentState!.validate()) return;
    _formKey.currentState!.save();

    final user = _auth.currentUser;
    if (user == null) return;

    try {
      final userDoc = await _firestore.collection('users').doc(user.uid).get();
      _currentWeight = (userDoc['weight'] ?? 70).toDouble();
      _height = (userDoc['height'] ?? 170).toDouble();

      final bmi = _currentWeight! / ((_height! / 100) * (_height! / 100));

      double realisticChange = _goalType == 'Fat Loss'
          ? (_durationDays / 7) * 0.7
          : (_durationDays / 7) * 0.5;

      bool isUnrealistic = _weightChange > realisticChange;

      String advice = '';
      if (isUnrealistic) {
        advice =
        'Based on your BMI (${bmi.toStringAsFixed(1)}) and duration, the maximum recommended ${_goalType.toLowerCase()} is ${realisticChange.toStringAsFixed(1)}kg';
        _weightChange = realisticChange;
      }

      // 导航到 AI 计划结果页面
      final result = await Navigator.push(
        context,
        MaterialPageRoute(
          builder: (_) => AIPlanResultScreen(
            goalType: _goalType,
            weightChange: _weightChange,
            durationDays: _durationDays,
            currentWeight: _currentWeight!,
            height: _height!,
            advice: advice,
            onPlanGenerated: widget.onPlanGenerated,
          ),
        ),
      );

      // 根据返回结果处理导航
      if (mounted) {
        if (result == 'saved' || result == 'completed') {
          // 如果保存了计划或完成了计划，返回到 AI Plan Modal
          Navigator.of(context).pop(result);
        } else if (result == 'not_saved' || result == 'cancelled') {
          // 如果没有保存或取消了，也返回到 AI Plan Modal
          Navigator.of(context).pop(result);
        }
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('获取用户信息失败：$e'),
            backgroundColor: Colors.red,
          ),
        );
      }
    }
  }

  Widget _buildGoalTypeCard() {
    return Expanded(
      child: Container(
        width: double.infinity,
        margin: const EdgeInsets.only(bottom: 12),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(12),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.1),
              blurRadius: 8,
              offset: const Offset(0, 2),
            ),
          ],
        ),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(12),
          child: Column(
            children: [
              // Purple section with goal type selector
              Expanded(
                flex: 2,
                child: Container(
                  width: double.infinity,
                  color: Colors.purple,
                  child: Row(
                    children: [
                      Expanded(
                        child: GestureDetector(
                          onTap: () => setState(() => _goalType = 'Fat Loss'),
                          child: Container(
                            decoration: BoxDecoration(
                              color: _goalType == 'Fat Loss' ? Colors.purple[700] : Colors.transparent,
                              border: _goalType == 'Fat Loss' ? Border.all(color: Colors.white, width: 2) : null,
                            ),
                            child: const Center(
                              child: Text(
                                'Fat Loss',
                                style: TextStyle(
                                  color: Colors.white,
                                  fontSize: 16,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                            ),
                          ),
                        ),
                      ),
                      Container(width: 1, color: Colors.white),
                      Expanded(
                        child: GestureDetector(
                          onTap: () => setState(() => _goalType = 'Muscle Gain'),
                          child: Container(
                            decoration: BoxDecoration(
                              color: _goalType == 'Muscle Gain' ? Colors.purple[700] : Colors.transparent,
                              border: _goalType == 'Muscle Gain' ? Border.all(color: Colors.white, width: 2) : null,
                            ),
                            child: const Center(
                              child: Text(
                                'Muscle Gain',
                                style: TextStyle(
                                  color: Colors.white,
                                  fontSize: 16,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              // Orange section - empty for visual design
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildWeightChangeCard() {
    return Expanded(
      child: Container(
        width: double.infinity,
        margin: const EdgeInsets.only(bottom: 12),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(12),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.1),
              blurRadius: 8,
              offset: const Offset(0, 2),
            ),
          ],
        ),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(12),
          child: Column(
            children: [
              // Purple section with label
              Expanded(
                flex: 2,
                child: Container(
                  width: double.infinity,
                  color: Colors.purple,
                  child: const Center(
                    child: Text(
                      'Expected Weight Change',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 16,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                ),
              ),
              // Orange section with input
              Expanded(
                flex: 3,
                child: Container(
                  width: double.infinity,
                  color: Colors.orange,
                  padding: const EdgeInsets.all(16),
                  child: TextFormField(
                    controller: _weightController,
                    decoration: InputDecoration(
                      hintText: 'Enter weight in kg',
                      hintStyle: TextStyle(color: Colors.white.withOpacity(0.7)),
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(8),
                        borderSide: const BorderSide(color: Colors.white),
                      ),
                      enabledBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(8),
                        borderSide: const BorderSide(color: Colors.white),
                      ),
                      focusedBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(8),
                        borderSide: const BorderSide(color: Colors.white, width: 2),
                      ),
                      filled: true,
                      fillColor: Colors.white.withOpacity(0.2),
                    ),
                    style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
                    keyboardType: TextInputType.number,
                    validator: (val) => (val == null || double.tryParse(val) == null || double.parse(val) <= 0)
                        ? 'Please enter a positive number'
                        : null,
                    onSaved: (val) => _weightChange = double.parse(val!),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildDurationCard() {
    return Expanded(
      child: Container(
        width: double.infinity,
        margin: const EdgeInsets.only(bottom: 16),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(12),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.1),
              blurRadius: 8,
              offset: const Offset(0, 2),
            ),
          ],
        ),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(12),
          child: Column(
            children: [
              // Purple section with label
              Expanded(
                flex: 2,
                child: Container(
                  width: double.infinity,
                  color: Colors.purple,
                  child: const Center(
                    child: Text(
                      'Target Duration',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 16,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                ),
              ),
              // Orange section with input
              Expanded(
                flex: 3,
                child: Container(
                  width: double.infinity,
                  color: Colors.orange,
                  padding: const EdgeInsets.all(16),
                  child: TextFormField(
                    controller: _durationController,
                    decoration: InputDecoration(
                      hintText: 'Enter days (7-365)',
                      hintStyle: TextStyle(color: Colors.white.withOpacity(0.7)),
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(8),
                        borderSide: const BorderSide(color: Colors.white),
                      ),
                      enabledBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(8),
                        borderSide: const BorderSide(color: Colors.white),
                      ),
                      focusedBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(8),
                        borderSide: const BorderSide(color: Colors.white, width: 2),
                      ),
                      filled: true,
                      fillColor: Colors.white.withOpacity(0.2),
                    ),
                    style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
                    keyboardType: TextInputType.number,
                    validator: (val) {
                      int? days = int.tryParse(val ?? '');
                      if (days == null || days < 7 || days > 365) {
                        return 'Please enter a value between 7 - 365 days';
                      }
                      return null;
                    },
                    onSaved: (val) => _durationDays = int.parse(val!),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  @override
  void dispose() {
    _weightController.dispose();
    _durationController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: () async {
        // 当用户按返回键时，返回到 AI Plan Modal
        Navigator.of(context).pop('cancelled');
        return false;
      },
      child: Scaffold(
        backgroundColor: Colors.grey[50],
        appBar: AppBar(
          title: const Text('Set Fitness Goal'),
          backgroundColor: Colors.white,
          elevation: 0,
          foregroundColor: Colors.black,
          leading: IconButton(
            icon: const Icon(Icons.arrow_back),
            onPressed: () => Navigator.of(context).pop('cancelled'),
          ),
        ),
        body: Padding(
          padding: const EdgeInsets.all(20),
          child: Form(
            key: _formKey,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // Goal type selection card
                _buildGoalTypeCard(),

                // Weight change input card
                _buildWeightChangeCard(),

                // Duration input card
                _buildDurationCard(),

                // Start button
                Container(
                  width: double.infinity,
                  height: 56,
                  margin: const EdgeInsets.only(bottom: 20),
                  child: ElevatedButton(
                    onPressed: _submit,
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.purple,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(28),
                      ),
                    ),
                    child: const Text(
                      'Generate AI Plan',
                      style: TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.w600,
                        color: Colors.white,
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}