// screens/analytics_tab_screen.dart
import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'dart:math';

class AnalyticsTabScreen extends StatefulWidget {
  const AnalyticsTabScreen({super.key});

  @override
  State<AnalyticsTabScreen> createState() => _AnalyticsTabScreenState();
}

class _AnalyticsTabScreenState extends State<AnalyticsTabScreen> {
  double? userWeight;
  double? userHeight;
  double? bmi;
  String? mainCourseTitle;
  List<int> weeklyIntensity = [1, 1, 1, 1, 1]; // 默认训练强度改为11111
  List<double> weightData = []; // 体重数据（5周）
  List<MapEntry<DateTime, double>> dailyWeights = []; // 实际体重数据
  Map<String, dynamic>? userData; // 用户数据
  bool isLoading = true;

  // 添加Firestore监听器
  Stream<DocumentSnapshot>? userDataStream;

  @override
  void initState() {
    super.initState();
    fetchUserData();
    _setupUserDataListener();
    _loadActualWeightData();
  }

  // 设置实时监听用户数据变化
  void _setupUserDataListener() {
    final user = FirebaseAuth.instance.currentUser;
    if (user != null) {
      userDataStream = FirebaseFirestore.instance
          .collection('users')
          .doc(user.uid)
          .snapshots();

      userDataStream!.listen((snapshot) {
        if (snapshot.exists && mounted) {
          final data = snapshot.data() as Map<String, dynamic>;
          setState(() {
            userData = data;
            userWeight = data['weight']?.toDouble() ?? 70.0;
            userHeight = data['height']?.toDouble() ?? 170.0;

            // 实时更新BMI
            if (userHeight != null && userHeight! > 0) {
              bmi = userWeight! / ((userHeight! / 100) * (userHeight! / 100));
            }

            // 根据新体重更新体重数据
            _updateWeightData();
          });
        }
      });
    }
  }

  // 加载实际体重数据
  Future<void> _loadActualWeightData() async {
    final user = FirebaseAuth.instance.currentUser;
    if (user == null) return;

    try {
      final snapshot = await FirebaseFirestore.instance
          .collection('weight_records')
          .where('userId', isEqualTo: user.uid)
          .orderBy('recordDate', descending: true)
          .limit(7)
          .get();

      final List<MapEntry<DateTime, double>> list = snapshot.docs.map((doc) {
        final rawWeight = doc['actualWeight'];
        final weight = (rawWeight is num) ? rawWeight.toDouble() : 0.0;
        final date = (doc['recordDate'] as Timestamp).toDate();
        return MapEntry(date, weight);
      }).toList();


      list.sort((a, b) => a.key.compareTo(b.key)); // 升序排列

      setState(() {
        dailyWeights = list;
      });
    } catch (e) {
      debugPrint('Error loading weight data: $e');
      setState(() {
        dailyWeights = [];
      });
    }
  }


  // 更新体重数据
  void _updateWeightData() {
    switch (mainCourseTitle) {
      case 'Muscle Building Plan':
        weightData = _generateWeightData(userWeight!, [0.0, 0.2, 0.5, 0.8, 1.2]); // 增重
        break;
      case 'Core & Posture Training':
        weightData = _generateWeightData(userWeight!, [0.0, -0.2, -0.6, -1.1, -1.8]); // 减重
        break;
      case 'Fat Burning Program':
        weightData = _generateWeightData(userWeight!, [0.0, -0.3, -1.0, -1.8, -2.9]); // 减重
        break;
      default:
        weightData = _generateWeightData(userWeight ?? 70, [0.0, 0.0, 0.0, 0.0, 0.0]); // 默认保持体重不变
    }
  }

  Future<void> fetchUserData() async {
    final user = FirebaseAuth.instance.currentUser;
    if (user == null) {
      setState(() => isLoading = false);
      return;
    }

    try {
      final userDoc = await FirebaseFirestore.instance.collection('users').doc(user.uid).get();
      final courseSnapshot = await FirebaseFirestore.instance
          .collection('user_courses')
          .where('userId', isEqualTo: user.uid)
          .where('status', isEqualTo: 'active')
          .where('isMainCourse', isEqualTo: true)
          .limit(1)
          .get();

      if (userDoc.exists) {
        userData = userDoc.data() as Map<String, dynamic>?;
        userWeight = userDoc['weight']?.toDouble() ?? 70.0; // 默认值
        userHeight = userDoc['height']?.toDouble() ?? 170.0; // 默认值
        if (userHeight != null && userHeight! > 0) {
          bmi = userWeight! / ((userHeight! / 100) * (userHeight! / 100));
        }
      }

      if (courseSnapshot.docs.isNotEmpty) {
        final course = courseSnapshot.docs.first.data();
        mainCourseTitle = course['title'];
      }

      setState(() {
        switch (mainCourseTitle) {
          case 'Muscle Building Plan': // 力量训练
            weeklyIntensity = [5, 4, 5, 5, 4];
            weightData = _generateWeightData(userWeight!, [0.0, -0.1, -0.3, -0.6, -1.0]);
            break;
          case 'Core & Posture Training': // 核心训练
            weeklyIntensity = [4, 3, 4, 3, 3];
            weightData = _generateWeightData(userWeight!, [0.0, -0.2, -0.6, -1.1, -1.8]);
            break;
          case 'Fat Burning Program': // 瘦身计划
            weeklyIntensity = [3, 3, 3, 3, 3];
            weightData = _generateWeightData(userWeight!, [0.0, -0.3, -1.0, -1.8, -2.9]);
            break;
          default:
            weeklyIntensity = [1, 1, 1, 1, 1]; // 改为默认11111
            weightData = _generateWeightData(userWeight ?? 70, [0.0, -0.2, -0.6, -1.1, -1.8]);
        }
        isLoading = false;
      });

      // 加载实际体重数据
      await _loadActualWeightData();
    } catch (e) {
      debugPrint('Error fetching user data: $e');
      // 设置默认值防止崩溃
      setState(() {
        userWeight = 70.0;
        userHeight = 170.0;
        weeklyIntensity = [1, 1, 1, 1, 1]; // 改为默认11111
        weightData = _generateWeightData(70.0, [0.0, 0.0, 0.0, 0.0, 0.0]); // 默认保持体重不变
        isLoading = false;
      });
    }
  }

  List<double> _generateWeightData(double baseWeight, List<double> changes) {
    // 确保生成5个数据点
    return List.generate(5, (index) {
      if (index < changes.length) {
        return double.parse((baseWeight + changes[index]).toStringAsFixed(1));
      } else {
        return baseWeight; // 如果变化数组不够长，使用基础体重
      }
    });
  }

  @override
  void dispose() {
    // 清理监听器
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (isLoading) {
      return const Scaffold(
        backgroundColor: Colors.white,
        body: Center(
          child: CircularProgressIndicator(),
        ),
      );
    }

    return Scaffold(
      backgroundColor: Colors.white, // 白色背景
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text(
                'Your training intensity',
                style: TextStyle(
                  color: Colors.black,
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 16),
              Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(10),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.grey.withOpacity(0.3),
                      spreadRadius: 2,
                      blurRadius: 5,
                      offset: const Offset(0, 3),
                    ),
                  ],
                ),
                child: Column(
                  children: [
                    // 强度标签
                    Row(
                      mainAxisAlignment: MainAxisAlignment.start,
                      children: [
                        Container(
                          padding: const EdgeInsets.only(left: 8),
                          child: const Text(
                            'Strength',
                            style: TextStyle(
                              fontSize: 16,
                              fontWeight: FontWeight.bold,
                              color: Colors.black,
                            ),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 16),
                    // 条形图
                    SizedBox(
                      height: 200,
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                        crossAxisAlignment: CrossAxisAlignment.end,
                        children: List.generate(5, (index) =>
                            _buildBarChart('W${index + 1}', weeklyIntensity.isNotEmpty ? weeklyIntensity[index] : 1, Colors.blue)),
                      ),
                    ),
                    const SizedBox(height: 8),
                    // 时间轴标签
                    const Row(
                      mainAxisAlignment: MainAxisAlignment.end,
                      children: [
                        Text(
                          'Time',
                          style: TextStyle(
                            fontSize: 12,
                            color: Colors.black54,
                          ),
                        ),
                        Icon(
                          Icons.arrow_forward,
                          size: 16,
                          color: Colors.black54,
                        ),
                      ],
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 32),

              // 用户个人资料卡片
              if (userData != null) buildUserProfileCard(),

              const SizedBox(height: 32),
              const Text(
                'Weight Progress',
                style: TextStyle(
                  color: Colors.black,
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 16),

              // 实际体重记录图表（修复版）
              Container(
                padding: const EdgeInsets.all(20),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(10),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.grey.withOpacity(0.3),
                      spreadRadius: 2,
                      blurRadius: 5,
                      offset: const Offset(0, 3),
                    ),
                  ],
                ),
                height: 350,
                width: double.infinity,
                child: Column(
                  children: [
                    // 显示当前数据状态
                    if (dailyWeights.every((entry) => entry.value <= 0))

                      Container(
                        padding: const EdgeInsets.all(8),
                        margin: const EdgeInsets.only(bottom: 10),
                        decoration: BoxDecoration(
                          color: Colors.orange.shade50,
                          borderRadius: BorderRadius.circular(8),
                          border: Border.all(color: Colors.orange.shade200),
                        ),
                        child: Row(
                          children: [
                            Icon(Icons.info_outline, color: Colors.orange.shade700, size: 16),
                            const SizedBox(width: 8),
                            Expanded(
                              child: Text(
                                'Complete training sessions to see your progress',
                                style: TextStyle(
                                  color: Colors.orange.shade700,
                                  fontSize: 12,
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    // 图表
                    Expanded(
                      child: dailyWeights.isNotEmpty
                          ? CustomPaint(
                        painter: ActualWeightChartPainterByDate(data: dailyWeights),
                      )
                          : const Center(
                        child: Text(
                          'No weight data available',
                          style: TextStyle(color: Colors.grey, fontSize: 16),
                        ),
                      ),
                    ),

                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildBarChart(String label, int value, Color color) {
    return Column(
      mainAxisAlignment: MainAxisAlignment.end,
      children: [
        Container(
          width: 30,
          height: value * 30.0, // 根据强度值调整高度
          decoration: BoxDecoration(
            color: color,
            borderRadius: BorderRadius.circular(4),
          ),
        ),
        const SizedBox(height: 8),
        Text(
          label,
          style: const TextStyle(
            color: Colors.black,
            fontSize: 12,
          ),
        ),
      ],
    );
  }

  Widget buildUserProfileCard() {
    final bmi = calculateBMI();
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 0, vertical: 8),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.blue[50],
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: Colors.blue.shade200),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(
                userData!['gender'] == 'Male' ? Icons.male : Icons.female,
                color: Colors.blue,
                size: 30,
              ),
              const SizedBox(width: 12),
              Text(
                'Your Profile',
                style: TextStyle(
                  color: Colors.blue.shade800,
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: [
              buildProfileItem(
                'Age',
                '${userData!['age'] ?? 'N/A'}',
                Icons.cake,
              ),
              buildProfileItem(
                'Weight',
                '${userData!['weight']?.toInt() ?? 'N/A'}kg',
                Icons.monitor_weight,
              ),
              buildProfileItem(
                'Height',
                '${userData!['height'] ?? 'N/A'}cm',
                Icons.height,
              ),
            ],
          ),
          if (bmi != null) ...[
            const SizedBox(height: 12),
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: getBMIColor(bmi).withOpacity(0.1),
                borderRadius: BorderRadius.circular(8),
                border: Border.all(color: getBMIColor(bmi)),
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    'BMI: ${bmi.toStringAsFixed(1)}',
                    style: TextStyle(
                      color: getBMIColor(bmi),
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  Text(
                    getBMIStatus(bmi),
                    style: TextStyle(
                      color: getBMIColor(bmi),
                      fontSize: 14,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ],
      ),
    );
  }

  Widget buildProfileItem(String label, String value, IconData icon) {
    return Column(
      children: [
        Container(
          padding: const EdgeInsets.all(8),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(8),
            boxShadow: [
              BoxShadow(
                color: Colors.grey.withOpacity(0.1),
                spreadRadius: 1,
                blurRadius: 3,
                offset: const Offset(1, 1),
              ),
            ],
          ),
          child: Icon(
            icon,
            color: Colors.blue,
            size: 24,
          ),
        ),
        const SizedBox(height: 4),
        Text(
          label,
          style: const TextStyle(
            color: Colors.grey,
            fontSize: 12,
            fontWeight: FontWeight.w500,
          ),
        ),
        const SizedBox(height: 2),
        Text(
          value,
          style: const TextStyle(
            color: Colors.black87,
            fontSize: 14,
            fontWeight: FontWeight.bold,
          ),
        ),
      ],
    );
  }

  double? calculateBMI() {
    if (userData != null &&
        userData!['weight'] != null &&
        userData!['height'] != null) {
      final weight = userData!['weight'].toDouble();
      final height = userData!['height'].toDouble();
      if (height > 0) {
        return weight / ((height / 100) * (height / 100));
      }
    }
    return null;
  }

  Color getBMIColor(double bmi) {
    if (bmi < 18.5) {
      return Colors.blue; // 偏瘦
    } else if (bmi < 25) {
      return Colors.green; // 正常
    } else if (bmi < 30) {
      return Colors.orange; // 超重
    } else {
      return Colors.red; // 肥胖
    }
  }

  String getBMIStatus(double bmi) {
    if (bmi < 18.5) {
      return 'Underweight';
    } else if (bmi < 25) {
      return 'Normal';
    } else if (bmi < 30) {
      return 'Overweight';
    } else {
      return 'Obese';
    }
  }
}

// 新的实际体重图表绘制器（只显示实际数据）
class ActualWeightChartPainterByDate extends CustomPainter {
  final List<MapEntry<DateTime, double>> data;

  ActualWeightChartPainterByDate({required this.data});

  @override
  void paint(Canvas canvas, Size size) {
    if (data.isEmpty) return;

    final margin = 40.0;
    final chartWidth = size.width - margin * 2;
    final chartHeight = size.height - margin * 2;

    final minWeight = data.map((e) => e.value).reduce(min);
    final maxWeight = data.map((e) => e.value).reduce(max);
    final weightRange = (maxWeight - minWeight).abs() < 1 ? 1 : maxWeight - minWeight;

    final textPainter = TextPainter(textDirection: TextDirection.ltr);
    final axisPaint = Paint()..color = Colors.black.withOpacity(0.6)..strokeWidth = 1.5;
    final pointPaint = Paint()..color = Colors.green;
    final linePaint = Paint()
      ..color = Colors.green
      ..strokeWidth = 2
      ..style = PaintingStyle.stroke;

    final count = data.length;
    final stepX = chartWidth / (count - 1);

    Path path = Path();

    for (int i = 0; i < data.length; i++) {
      final x = margin + stepX * i;
      final y = margin + chartHeight * (1 - (data[i].value - minWeight) / weightRange);

      if (i == 0) {
        path.moveTo(x, y);
      } else {
        path.lineTo(x, y);
      }

      canvas.drawCircle(Offset(x, y), 4, pointPaint);

      // 数值
      textPainter.text = TextSpan(
        text: data[i].value.toStringAsFixed(1),
        style: const TextStyle(fontSize: 10, color: Colors.green),
      );
      textPainter.layout();
      textPainter.paint(canvas, Offset(x - textPainter.width / 2, y - 18));

      // 日期
      textPainter.text = TextSpan(
        text: '${data[i].key.month}/${data[i].key.day}',
        style: const TextStyle(fontSize: 10, color: Colors.black),
      );
      textPainter.layout();
      textPainter.paint(canvas, Offset(x - textPainter.width / 2, size.height - 20));
    }

    canvas.drawPath(path, linePaint);
    canvas.drawLine(Offset(margin, margin), Offset(margin, margin + chartHeight), axisPaint);
    canvas.drawLine(Offset(margin, margin + chartHeight), Offset(size.width - margin, margin + chartHeight), axisPaint);
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => true;
}