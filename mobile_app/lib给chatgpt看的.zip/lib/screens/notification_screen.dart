// 通知界面 notification_screen.dart
// - 显示通知列表
// - 支持消息通知和每日8点计划提醒
// - 通知权限管理
// - 清除通知功能

import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:workmanager/workmanager.dart';

class NotificationScreen extends StatefulWidget {
  const NotificationScreen({super.key});

  @override
  State<NotificationScreen> createState() => _NotificationScreenState();
}

class _NotificationScreenState extends State<NotificationScreen> {
  final FirebaseAuth _auth = FirebaseAuth.instance;
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  final FlutterLocalNotificationsPlugin _notifications = FlutterLocalNotificationsPlugin();

  List<Map<String, dynamic>> _notifications_list = [];
  bool _isDailyReminderEnabled = false;

  @override
  void initState() {
    super.initState();
    _initializeNotifications();
    _loadNotifications();
    _loadDailyReminderSetting();
    _setupMessageListener();
  }

  // 初始化通知
  Future<void> _initializeNotifications() async {
    // 请求通知权限
    await Permission.notification.request();

    const androidSettings = AndroidInitializationSettings('@mipmap/ic_launcher');
    const iosSettings = DarwinInitializationSettings(
      requestAlertPermission: true,
      requestBadgePermission: true,
      requestSoundPermission: true,
    );

    const initSettings = InitializationSettings(
      android: androidSettings,
      iOS: iosSettings,
    );

    await _notifications.initialize(
      initSettings,
      onDidReceiveNotificationResponse: _onNotificationTapped,
    );

    // 初始化WorkManager用于后台任务
    Workmanager().initialize(callbackDispatcher, isInDebugMode: false);
  }

  // 设置消息监听器
  void _setupMessageListener() {
    final user = _auth.currentUser;
    if (user == null) return;

    // 监听所有聊天的新消息
    _firestore.collectionGroup('messages')
        .where('timestamp', isGreaterThan: Timestamp.now())
        .snapshots()
        .listen((snapshot) {
      for (var change in snapshot.docChanges) {
        if (change.type == DocumentChangeType.added) {
          final data = change.doc.data() as Map<String, dynamic>;
          if (data['senderId'] != user.uid) {
            _showMessageNotification(data);
            _addNotificationToList('新消息', data['text'] ?? '收到一条新消息');
          }
        }
      }
    });
  }

  // 显示消息通知
  Future<void> _showMessageNotification(Map<String, dynamic> messageData) async {
    const androidDetails = AndroidNotificationDetails(
      'messages',
      '消息通知',
      channelDescription: '新消息提醒',
      importance: Importance.high,
      priority: Priority.high,
      icon: '@mipmap/ic_launcher',
    );

    const iosDetails = DarwinNotificationDetails(
      presentAlert: true,
      presentBadge: true,
      presentSound: true,
    );

    const details = NotificationDetails(
      android: androidDetails,
      iOS: iosDetails,
    );

    await _notifications.show(
      DateTime.now().millisecondsSinceEpoch ~/ 1000,
      '新消息',
      messageData['text'] ?? '收到一条新消息',
      details,
    );
  }

  // 设置每日8点提醒
  Future<void> _scheduleDailyReminder() async {
    if (_isDailyReminderEnabled) {
      // 取消现有的定时任务
      await Workmanager().cancelByUniqueName('daily_reminder');

      // 设置新的定时任务
      await Workmanager().registerPeriodicTask(
        'daily_reminder',
        'dailyReminderTask',
        frequency: const Duration(days: 1),
        initialDelay: _getInitialDelay(),
        constraints: Constraints(
          networkType: NetworkType.not_required,
        ),
      );
    } else {
      await Workmanager().cancelByUniqueName('daily_reminder');
    }
  }

  // 计算到下个8点的延迟时间
  Duration _getInitialDelay() {
    final now = DateTime.now();
    var next8AM = DateTime(now.year, now.month, now.day, 8, 0);

    if (now.isAfter(next8AM)) {
      next8AM = next8AM.add(const Duration(days: 1));
    }

    return next8AM.difference(now);
  }

  // 添加通知到列表
  void _addNotificationToList(String title, String content) {
    setState(() {
      _notifications_list.insert(0, {
        'id': DateTime.now().millisecondsSinceEpoch.toString(),
        'title': title,
        'content': content,
        'time': DateTime.now(),
        'isRead': false,
      });
    });
    _saveNotifications();
  }

  // 加载通知列表
  Future<void> _loadNotifications() async {
    final user = _auth.currentUser;
    if (user == null) return;

    try {
      final doc = await _firestore
          .collection('users')
          .doc(user.uid)
          .collection('notifications')
          .doc('list')
          .get();

      if (doc.exists) {
        final data = doc.data()!;
        setState(() {
          _notifications_list = List<Map<String, dynamic>>.from(
              data['notifications']?.map((item) => {
                ...Map<String, dynamic>.from(item),
                'time': (item['time'] as Timestamp).toDate(),
              }) ?? []
          );
        });
      }
    } catch (e) {
      print('加载通知失败: $e');
    }
  }

  // 保存通知列表
  Future<void> _saveNotifications() async {
    final user = _auth.currentUser;
    if (user == null) return;

    try {
      await _firestore
          .collection('users')
          .doc(user.uid)
          .collection('notifications')
          .doc('list')
          .set({
        'notifications': _notifications_list.map((item) => {
          ...item,
          'time': Timestamp.fromDate(item['time']),
        }).toList(),
      });
    } catch (e) {
      print('保存通知失败: $e');
    }
  }

  // 加载每日提醒设置
  Future<void> _loadDailyReminderSetting() async {
    final user = _auth.currentUser;
    if (user == null) return;

    try {
      final doc = await _firestore
          .collection('users')
          .doc(user.uid)
          .collection('settings')
          .doc('notifications')
          .get();

      if (doc.exists) {
        setState(() {
          _isDailyReminderEnabled = doc.data()?['dailyReminder'] ?? false;
        });
      }
    } catch (e) {
      print('加载设置失败: $e');
    }
  }

  // 保存每日提醒设置
  Future<void> _saveDailyReminderSetting() async {
    final user = _auth.currentUser;
    if (user == null) return;

    try {
      await _firestore
          .collection('users')
          .doc(user.uid)
          .collection('settings')
          .doc('notifications')
          .set({
        'dailyReminder': _isDailyReminderEnabled,
      });

      await _scheduleDailyReminder();
    } catch (e) {
      print('保存设置失败: $e');
    }
  }

  // 标记通知为已读
  void _markAsRead(String notificationId) {
    setState(() {
      final index = _notifications_list.indexWhere((item) => item['id'] == notificationId);
      if (index != -1) {
        _notifications_list[index]['isRead'] = true;
      }
    });
    _saveNotifications();
  }

  // 清除所有通知
  void _clearAllNotifications() {
    setState(() {
      _notifications_list.clear();
    });
    _saveNotifications();
  }

  // 通知点击回调
  void _onNotificationTapped(NotificationResponse response) {
    // 处理通知点击事件
    print('通知被点击: ${response.payload}');
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('通知中心', style: TextStyle(color: Colors.black)),
        backgroundColor: Colors.white,
        iconTheme: const IconThemeData(color: Colors.black),
        actions: [
          IconButton(
            icon: const Icon(Icons.clear_all, color: Colors.black),
            onPressed: _clearAllNotifications,
            tooltip: '清除所有通知',
          ),
        ],
      ),
      body: Column(
        children: [
          // 设置区域
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: Colors.grey[100],
              border: Border(
                bottom: BorderSide(color: Colors.grey[300]!),
              ),
            ),
            child: Row(
              children: [
                const Icon(Icons.schedule, color: Colors.deepPurple),
                const SizedBox(width: 12),
                const Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        '每日8点提醒',
                        style: TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.bold,
                          color: Colors.black,
                        ),
                      ),
                      Text(
                        '开启后每天8点会收到计划提醒',
                        style: TextStyle(
                          fontSize: 12,
                          color: Colors.black54,
                        ),
                      ),
                    ],
                  ),
                ),
                Switch(
                  value: _isDailyReminderEnabled,
                  onChanged: (value) {
                    setState(() {
                      _isDailyReminderEnabled = value;
                    });
                    _saveDailyReminderSetting();
                  },
                  activeColor: Colors.deepPurple,
                ),
              ],
            ),
          ),

          // 通知列表
          Expanded(
            child: _notifications_list.isEmpty
                ? const Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(
                    Icons.notifications_none,
                    size: 64,
                    color: Colors.grey,
                  ),
                  SizedBox(height: 16),
                  Text(
                    '暂无通知',
                    style: TextStyle(
                      fontSize: 16,
                      color: Colors.grey,
                    ),
                  ),
                ],
              ),
            )
                : ListView.builder(
              itemCount: _notifications_list.length,
              itemBuilder: (context, index) {
                final notification = _notifications_list[index];
                return _buildNotificationItem(notification);
              },
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildNotificationItem(Map<String, dynamic> notification) {
    final isRead = notification['isRead'] ?? false;
    final time = notification['time'] as DateTime;

    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
      decoration: BoxDecoration(
        color: isRead ? Colors.white : Colors.blue[50],
        borderRadius: BorderRadius.circular(8),
      ),
      child: ListTile(
        leading: Container(
          width: 12,
          height: 12,
          decoration: BoxDecoration(
            color: isRead ? Colors.grey : Colors.deepPurple,
            shape: BoxShape.circle,
          ),
        ),
        title: Text(
          notification['title'] ?? '',
          style: TextStyle(
            fontSize: 16,
            fontWeight: isRead ? FontWeight.normal : FontWeight.bold,
            color: Colors.black,
          ),
        ),
        subtitle: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              notification['content'] ?? '',
              style: const TextStyle(
                fontSize: 14,
                color: Colors.black87,
              ),
            ),
            const SizedBox(height: 4),
            Text(
              _formatTime(time),
              style: const TextStyle(
                fontSize: 12,
                color: Colors.grey,
              ),
            ),
          ],
        ),
        onTap: () {
          if (!isRead) {
            _markAsRead(notification['id']);
          }
        },
        trailing: !isRead
            ? const Icon(
          Icons.circle,
          color: Colors.deepPurple,
          size: 8,
        )
            : null,
      ),
    );
  }

  String _formatTime(DateTime time) {
    final now = DateTime.now();
    final difference = now.difference(time);

    if (difference.inMinutes < 1) {
      return '刚刚';
    } else if (difference.inHours < 1) {
      return '${difference.inMinutes}分钟前';
    } else if (difference.inDays < 1) {
      return '${difference.inHours}小时前';
    } else if (difference.inDays < 7) {
      return '${difference.inDays}天前';
    } else {
      return '${time.month}月${time.day}日';
    }
  }

  @override
  void dispose() {
    super.dispose();
  }
}

// WorkManager回调函数（必须在顶层定义）
@pragma('vm:entry-point')
void callbackDispatcher() {
  Workmanager().executeTask((task, inputData) async {
    if (task == 'dailyReminderTask') {
      // 显示每日8点提醒
      final notifications = FlutterLocalNotificationsPlugin();

      const androidDetails = AndroidNotificationDetails(
        'daily_reminder',
        '每日提醒',
        channelDescription: '每天8点的计划提醒',
        importance: Importance.high,
        priority: Priority.high,
      );

      const iosDetails = DarwinNotificationDetails(
        presentAlert: true,
        presentBadge: true,
        presentSound: true,
      );

      const details = NotificationDetails(
        android: androidDetails,
        iOS: iosDetails,
      );

      await notifications.show(
        999, // 固定ID用于每日提醒
        '计划提醒',
        '新的一天开始了！快来查看今天的计划吧 ✨',
        details,
      );
    }
    return Future.value(true);
  });
}