// today_training_screen.dart - 修复AI训练完成后进度更新问题
import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';

class TrainingItem {
  final String name;
  final int durationMinutes;
  final Color color;
  final IconData icon;
  final String courseId;
  final String title;
  final String category;
  bool isCompleted;

  TrainingItem({
    required this.name,
    required this.durationMinutes,
    required this.color,
    required this.icon,
    required this.courseId,
    required this.title,
    required this.category,
    this.isCompleted = false,
  });
}

class TodayTrainingScreen extends StatefulWidget {
  final List<TrainingItem> trainingItems;
  final String courseId;
  final String? aiPlanId; // 添加AI计划ID参数

  const TodayTrainingScreen({
    super.key,
    required this.trainingItems,
    required this.courseId,
    this.aiPlanId, // AI计划ID（可选）
  });

  @override
  State<TodayTrainingScreen> createState() => _TodayTrainingScreenState();
}

class _TodayTrainingScreenState extends State<TodayTrainingScreen> with SingleTickerProviderStateMixin {
  int currentItemIndex = 0;
  Timer? timer;
  int remainingSeconds = 0;
  bool isRunning = false;
  bool isPaused = false;
  late AnimationController _animationController;
  late Animation<double> _progressAnimation;

  final FirebaseAuth _auth = FirebaseAuth.instance;
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  @override
  void initState() {
    super.initState();
    _setupCurrentItem();
    _animationController = AnimationController(vsync: this, duration: const Duration(seconds: 1));
    _progressAnimation = Tween<double>(begin: 0, end: 1).animate(_animationController);
    _startTimer();
  }

  void _setupCurrentItem() {
    remainingSeconds = widget.trainingItems[currentItemIndex].durationMinutes * 60;
  }

  void _startTimer() {
    setState(() => isRunning = true);
    timer = Timer.periodic(const Duration(seconds: 1), (t) {
      if (!isPaused) {
        setState(() => remainingSeconds--);
        if (remainingSeconds <= 0) _completeCurrentItem();
      }
    });
  }

  void _pauseTimer() => setState(() => isPaused = true);
  void _resumeTimer() => setState(() => isPaused = false);
  void _skipToNext() => _completeCurrentItem();

  void _completeCurrentItem() {
    widget.trainingItems[currentItemIndex].isCompleted = true;
    timer?.cancel();
    if (currentItemIndex < widget.trainingItems.length - 1) {
      setState(() => currentItemIndex++);
      _setupCurrentItem();
      _startTimer();
    } else {
      _finishTraining();
    }
  }

  void _finishEarly() {
    timer?.cancel();
    _finishTraining();
  }

  // 修复：简化训练完成逻辑，专注于AI计划进度更新
  Future<void> _finishTraining() async {
    final user = _auth.currentUser;
    if (user == null) return;

    try {
      print('开始处理训练完成，AI计划ID: ${widget.aiPlanId}');

      // 如果是普通课程，更新课程进度
      if (widget.aiPlanId == null) {
        await _updateCourseProgress(user.uid);
      }

      // 创建训练完成签到记录
      await _createTrainingCheckIn(user.uid);

      // 直接显示完成消息，不需要体重输入
      if (mounted) {
        _showTrainingCompletedMessage();
      }

    } catch (e) {
      print('Error updating training progress: $e');
      // 即使出错也显示完成消息
      if (mounted) {
        _showTrainingCompletedMessage();
      }
    }
  }

  // 更新课程进度
  Future<void> _updateCourseProgress(String userId) async {
    try {
      final query = await _firestore
          .collection('user_courses')
          .where('userId', isEqualTo: userId)
          .where('courseId', isEqualTo: widget.courseId)
          .limit(1)
          .get();

      if (query.docs.isNotEmpty) {
        final doc = query.docs.first.reference;
        final remaining = query.docs.first.data()['remainingSessions'] ?? 8;
        await doc.update({'remainingSessions': remaining > 0 ? remaining - 1 : 0});
        print('Course training completion recorded successfully');
      }
    } catch (e) {
      print('Error updating course progress: $e');
    }
  }

  // 创建训练签到记录
  Future<void> _createTrainingCheckIn(String userId) async {
    try {
      // 检查今日是否已签到
      final today = DateTime.now();
      final startOfDay = DateTime(today.year, today.month, today.day);
      final endOfDay = startOfDay.add(const Duration(days: 1));

      // 构建查询
      Query checkInQuery = _firestore
          .collection('check_ins')
          .where('userId', isEqualTo: userId)
          .where('checkInDate', isGreaterThanOrEqualTo: Timestamp.fromDate(startOfDay))
          .where('checkInDate', isLessThan: Timestamp.fromDate(endOfDay))
          .where('checkInType', isEqualTo: 'training_completed');

      // 如果是AI计划，添加AI计划ID条件
      if (widget.aiPlanId != null) {
        checkInQuery = checkInQuery.where('aiPlanId', isEqualTo: widget.aiPlanId);
        print('检查AI计划今日签到状态，计划ID: ${widget.aiPlanId}');
      } else {
        checkInQuery = checkInQuery.where('courseId', isEqualTo: widget.courseId);
        print('检查课程今日签到状态，课程ID: ${widget.courseId}');
      }

      final existingCheckIn = await checkInQuery.limit(1).get();

      if (existingCheckIn.docs.isEmpty) {
        // 创建签到记录
        final checkInData = {
          'userId': userId,
          'checkInDate': Timestamp.now(),
          'checkInType': 'training_completed',
          'trainingItems': widget.trainingItems.map((item) => {
            'name': item.name,
            'durationMinutes': item.durationMinutes,
            'isCompleted': item.isCompleted,
          }).toList(),
          'totalDuration': widget.trainingItems.fold(0, (sum, item) => sum + item.durationMinutes),
          'createdAt': Timestamp.now(),
        };

        // 如果是AI计划训练，添加AI计划ID
        if (widget.aiPlanId != null) {
          checkInData['aiPlanId'] = widget.aiPlanId!;
          checkInData['courseId'] = widget.courseId; // 保留courseId作为备用
          print('🔥 创建AI计划训练签到记录，计划ID: ${widget.aiPlanId}');
        } else {
          checkInData['courseId'] = widget.courseId;
          print('创建课程训练签到记录，课程ID: ${widget.courseId}');
        }

        await _firestore.collection('check_ins').add(checkInData);
        print('✅ 训练签到记录创建成功');

        // 如果是AI计划，更新计划的最后训练时间
        if (widget.aiPlanId != null) {
          await _updateAIPlanLastTraining(userId);
        }

      } else {
        print('今日该项目已签到');
      }

    } catch (e) {
      print('Error creating training check-in: $e');
      rethrow;
    }
  }

  // 更新AI计划的最后训练时间
  Future<void> _updateAIPlanLastTraining(String userId) async {
    try {
      await _firestore
          .collection('users')
          .doc(userId)
          .collection('ai_plans')
          .doc(widget.aiPlanId!)
          .update({
        'lastTrainingDate': Timestamp.now(),
        'lastTrainingAt': FieldValue.serverTimestamp(),
      });
      print('AI计划最后训练时间已更新');
    } catch (e) {
      print('Error updating AI plan last training: $e');
    }
  }

  // 显示训练完成消息
  void _showTrainingCompletedMessage() {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (BuildContext context) {
        return Dialog(
          child: Container(
            padding: const EdgeInsets.all(20),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                // 完成图标
                Container(
                  width: 80,
                  height: 80,
                  decoration: BoxDecoration(
                    color: Colors.green.shade50,
                    shape: BoxShape.circle,
                  ),
                  child: Icon(
                    Icons.check_circle,
                    size: 50,
                    color: Colors.green,
                  ),
                ),
                const SizedBox(height: 20),

                // 标题
                Text(
                  widget.aiPlanId != null ? '🎉 AI训练完成！' : '🎉 训练完成！',
                  style: const TextStyle(
                    color: Colors.black,
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 12),

                // 完成信息
                Text(
                  widget.aiPlanId != null
                      ? 'AI训练计划今日进度已更新'
                      : '课程训练进度已更新',
                  style: const TextStyle(
                    color: Colors.black87,
                    fontSize: 14,
                  ),
                ),
                const SizedBox(height: 8),

                // 训练时长
                Text(
                  '训练时长: ${widget.trainingItems.fold(0, (sum, item) => sum + item.durationMinutes)} 分钟',
                  style: TextStyle(
                    color: Colors.grey[600],
                    fontSize: 12,
                  ),
                ),
                const SizedBox(height: 8),

                // 签到状态
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                  decoration: BoxDecoration(
                    color: Colors.green.shade50,
                    borderRadius: BorderRadius.circular(20),
                    border: Border.all(color: Colors.green.shade200),
                  ),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Icon(
                        Icons.check_circle_outline,
                        size: 16,
                        color: Colors.green,
                      ),
                      const SizedBox(width: 4),
                      const Text(
                        '已签到',
                        style: TextStyle(
                          color: Colors.green,
                          fontSize: 12,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 24),

                // 返回按钮
                SizedBox(
                  width: double.infinity,
                  child: ElevatedButton.icon(
                    onPressed: () {
                      Navigator.of(context).pop(); // 关闭对话框
                      Navigator.of(context).pop('completed'); // 返回结果标识训练完成

                      // 返回主页并刷新
                      Navigator.pushReplacementNamed(
                          context,
                          '/main',
                          arguments: {'initialIndex': 0, 'refresh': true}
                      );
                    },
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.green,
                      foregroundColor: Colors.white,
                      padding: const EdgeInsets.symmetric(vertical: 12),
                    ),
                    icon: const Icon(Icons.home),
                    label: const Text(
                      '返回首页',
                      style: TextStyle(fontSize: 14, fontWeight: FontWeight.bold),
                    ),
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  String _formatTime(int totalSeconds) {
    final minutes = totalSeconds ~/ 60;
    final seconds = totalSeconds % 60;
    return '${minutes.toString().padLeft(2, '0')}:${seconds.toString().padLeft(2, '0')}';
  }

  @override
  void dispose() {
    timer?.cancel();
    _animationController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final currentItem = widget.trainingItems[currentItemIndex];

    return Scaffold(
      backgroundColor: Colors.white,
      resizeToAvoidBottomInset: false,
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0,
        leading: IconButton(icon: const Icon(Icons.arrow_back, color: Colors.black), onPressed: () => Navigator.pop(context)),
        title: Text(
          widget.aiPlanId != null ? 'AI训练进行中' : '训练进行中',
          style: const TextStyle(color: Colors.black, fontWeight: FontWeight.bold),
        ),
        actions: [
          TextButton(onPressed: _finishEarly, child: const Text('提前结束', style: TextStyle(color: Colors.red))),
        ],
      ),
      body: SafeArea(
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.all(16.0),
              child: Column(
                children: [
                  LinearProgressIndicator(
                    value: (currentItemIndex + 1) / widget.trainingItems.length,
                    backgroundColor: Colors.grey[300],
                    valueColor: AlwaysStoppedAnimation<Color>(
                      widget.aiPlanId != null ? Colors.purple : Colors.deepPurple,
                    ),
                  ),
                  const SizedBox(height: 8),
                  Text('${currentItemIndex + 1} / ${widget.trainingItems.length}', style: TextStyle(color: Colors.grey[600], fontSize: 14)),
                  const SizedBox(height: 20),
                  AnimatedBuilder(
                    animation: _progressAnimation,
                    builder: (context, child) => Container(
                      width: double.infinity,
                      padding: const EdgeInsets.all(24),
                      decoration: BoxDecoration(
                        gradient: LinearGradient(
                          begin: Alignment.centerLeft,
                          end: Alignment.centerRight,
                          stops: [_progressAnimation.value, _progressAnimation.value],
                          colors: [Colors.grey[300]!, currentItem.color],
                        ),
                        borderRadius: BorderRadius.circular(16),
                        boxShadow: [BoxShadow(color: currentItem.color.withOpacity(0.3), blurRadius: 8, offset: const Offset(0, 4))],
                      ),
                      child: Column(
                        children: [
                          Icon(currentItem.icon, size: 56, color: Colors.black87),
                          const SizedBox(height: 16),
                          Text(currentItem.name, style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold, color: Colors.black)),
                          if (widget.aiPlanId != null) ...[
                            const SizedBox(height: 8),
                            Container(
                              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                              decoration: BoxDecoration(
                                color: Colors.purple[100],
                                borderRadius: BorderRadius.circular(12),
                              ),
                              child: const Text(
                                'AI Plan Training',
                                style: TextStyle(
                                  fontSize: 12,
                                  color: Colors.purple,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                            ),
                          ],
                        ],
                      ),
                    ),
                  ),
                  const SizedBox(height: 20),
                  Text(_formatTime(remainingSeconds), style: const TextStyle(fontSize: 64, fontWeight: FontWeight.bold, color: Colors.black)),
                  const SizedBox(height: 30),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      ElevatedButton(
                        onPressed: _skipToNext,
                        style: ElevatedButton.styleFrom(backgroundColor: Colors.orange, shape: const CircleBorder(), padding: const EdgeInsets.all(18)),
                        child: const Icon(Icons.skip_next, color: Colors.white, size: 28),
                      ),
                      ElevatedButton(
                        onPressed: isRunning ? _pauseTimer : (isPaused ? _resumeTimer : _startTimer),
                        style: ElevatedButton.styleFrom(
                          backgroundColor: widget.aiPlanId != null ? Colors.purple : Colors.deepPurple,
                          shape: const CircleBorder(),
                          padding: const EdgeInsets.all(28),
                        ),
                        child: Icon(isRunning ? Icons.pause : Icons.play_arrow, color: Colors.white, size: 40),
                      ),
                      ElevatedButton(
                        onPressed: _finishEarly,
                        style: ElevatedButton.styleFrom(backgroundColor: Colors.red, shape: const CircleBorder(), padding: const EdgeInsets.all(18)),
                        child: const Icon(Icons.stop, color: Colors.white, size: 28),
                      ),
                    ],
                  ),
                ],
              ),
            ),
            const SizedBox(height: 16),
            Expanded(
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16.0),
                child: ListView.builder(
                  itemCount: widget.trainingItems.length,
                  itemBuilder: (context, index) {
                    final item = widget.trainingItems[index];
                    final isActive = index == currentItemIndex;
                    final isCompleted = item.isCompleted;

                    return Container(
                      margin: const EdgeInsets.only(bottom: 8),
                      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                      decoration: BoxDecoration(
                        color: isActive ? item.color.withOpacity(0.3) : (isCompleted ? Colors.green[100] : Colors.grey[100]),
                        borderRadius: BorderRadius.circular(8),
                        border: isActive ? Border.all(color: item.color, width: 2) : null,
                      ),
                      child: Row(
                        children: [
                          Icon(isCompleted ? Icons.check_circle : item.icon, color: isCompleted ? Colors.green : Colors.grey[600], size: 24),
                          const SizedBox(width: 12),
                          Expanded(
                            child: Text(
                              item.name,
                              style: TextStyle(
                                fontSize: 16,
                                fontWeight: isActive ? FontWeight.bold : FontWeight.normal,
                                color: isCompleted ? Colors.green[700] : Colors.black,
                                decoration: isCompleted ? TextDecoration.lineThrough : null,
                              ),
                            ),
                          ),
                          Text('${item.durationMinutes} min', style: TextStyle(fontSize: 14, color: Colors.grey[600])),
                        ],
                      ),
                    );
                  },
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}