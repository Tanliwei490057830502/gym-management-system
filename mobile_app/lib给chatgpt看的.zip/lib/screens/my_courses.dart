import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'today_training_screen.dart';
import 'ai_plan_modal.dart';

class MyCoursesScreen extends StatefulWidget {
  const MyCoursesScreen({super.key});

  @override
  State<MyCoursesScreen> createState() => _MyCoursesScreenState();
}

class _MyCoursesScreenState extends State<MyCoursesScreen> {
  final FirebaseAuth _auth = FirebaseAuth.instance;
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  List<Map<String, dynamic>> _purchasedCourses = [];
  List<Map<String, dynamic>> _aiPlans = [];
  bool _isLoading = true;
  bool _loadingAIPlans = true;
  String? _mainCourseId;

  @override
  void initState() {
    super.initState();
    _loadCourses();
    _loadAIPlans();
  }

  Future<void> _loadCourses() async {
    try {
      final user = _auth.currentUser;
      if (user == null) return;

      final snapshot = await _firestore
          .collection('user_courses')
          .where('userId', isEqualTo: user.uid)
          .get();

      final courses = snapshot.docs.map((doc) => {
        ...doc.data(),
        'userCourseId': doc.id,
      }).toList();

      final mainCourse = courses.firstWhere(
            (c) => c['isMainCourse'] == true,
        orElse: () => {},
      );

      if (mounted) {
        setState(() {
          _purchasedCourses = courses;
          _mainCourseId = mainCourse['userCourseId'];
          _isLoading = false;
        });
      }
    } catch (e) {
      print('Error loading courses: $e');
      if (mounted) {
        setState(() => _isLoading = false);
      }
    }
  }

  // Load AI plans from Firestore
  Future<void> _loadAIPlans() async {
    final user = _auth.currentUser;
    if (user == null) {
      setState(() => _loadingAIPlans = false);
      return;
    }

    try {
      final querySnapshot = await _firestore
          .collection('users')
          .doc(user.uid)
          .collection('ai_plans')
          .orderBy('createdAt', descending: true)
          .get();

      setState(() {
        _aiPlans = querySnapshot.docs.map((doc) {
          final data = doc.data();
          data['id'] = doc.id;
          return data;
        }).toList();
        _loadingAIPlans = false;
      });
    } catch (e) {
      debugPrint('Failed to load AI plans: $e');
      setState(() => _loadingAIPlans = false);
    }
  }

  Future<void> _setAsMainCourse(String userCourseId) async {
    final user = _auth.currentUser;
    if (user == null) return;

    setState(() => _isLoading = true);

    final batch = _firestore.batch();
    final allCourses = await _firestore
        .collection('user_courses')
        .where('userId', isEqualTo: user.uid)
        .get();

    for (final doc in allCourses.docs) {
      batch.update(doc.reference, {'isMainCourse': false});
    }
    batch.update(
      _firestore.collection('user_courses').doc(userCourseId),
      {'isMainCourse': true},
    );

    await batch.commit();
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('已设置为主课程')),
      );
      await _loadCourses();
    }
  }

  List<TrainingItem> _buildTrainingItems(String courseId, String title, String category) {
    List<TrainingItem> middleItems;

    if (title == 'Core & Posture Training') {
      middleItems = [
        TrainingItem(name: 'Plank', durationMinutes: 5, color: Colors.green[100]!, icon: Icons.fitness_center, courseId: courseId, title: title, category: category),
        TrainingItem(name: 'Bird Dog', durationMinutes: 5, color: Colors.yellow[100]!, icon: Icons.fitness_center, courseId: courseId, title: title, category: category),
        TrainingItem(name: 'Side Plank', durationMinutes: 5, color: Colors.blue[100]!, icon: Icons.fitness_center, courseId: courseId, title: title, category: category),
      ];
    } else if (title == 'Muscle Building Plan') {
      middleItems = [
        TrainingItem(name: 'Squat', durationMinutes: 15, color: Colors.orange, icon: Icons.fitness_center, courseId: courseId, title: title, category: category),
        TrainingItem(name: 'Bench Press', durationMinutes: 15, color: Colors.pink, icon: Icons.fitness_center, courseId: courseId, title: title, category: category),
        TrainingItem(name: 'Deadlift', durationMinutes: 15, color: Colors.purple, icon: Icons.fitness_center, courseId: courseId, title: title, category: category),
      ];
    } else if (title == 'Fat Burning Program') {
      middleItems = [
        TrainingItem(name: 'Jumping Jacks', durationMinutes: 10, color: Colors.red, icon: Icons.directions_run, courseId: courseId, title: title, category: category),
        TrainingItem(name: 'Mountain Climbers', durationMinutes: 10, color: Colors.orange, icon: Icons.directions_run, courseId: courseId, title: title, category: category),
        TrainingItem(name: 'Burpees', durationMinutes: 10, color: Colors.teal, icon: Icons.directions_run, courseId: courseId, title: title, category: category),
      ];
    } else {
      middleItems = [];
    }

    return [
      TrainingItem(name: 'Warm-up', durationMinutes: 10, color: Colors.redAccent, icon: Icons.directions_run, courseId: courseId, title: title, category: category),
      ...middleItems,
      TrainingItem(name: 'Cool-down', durationMinutes: 10, color: Colors.cyanAccent, icon: Icons.spa, courseId: courseId, title: title, category: category),
    ];
  }

  void onNewPlanSaved(String newPlanTitle) {
    // Reload AI plans when a new plan is saved
    _loadAIPlans();
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('AI 计划 "$newPlanTitle" 已添加')),
    );
  }

  void showAIPlanOptions() {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.white, // 改为白色背景而不是透明
      builder: (context) => Container(
        decoration: const BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
        ),
        child: AIPlanModal(
          onNewPlanSaved: onNewPlanSaved,
          aiPlans: const [], // Pass empty list since we're loading from Firestore
        ),
      ),
    );
  }

  // Show AI plan details
  void _showAIPlanDetails(Map<String, dynamic> plan) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (context) => DraggableScrollableSheet(
        initialChildSize: 0.7,
        minChildSize: 0.5,
        maxChildSize: 0.95,
        builder: (context, scrollController) {
          return Container(
            decoration: const BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
            ),
            child: Column(
              children: [
                // Drag indicator
                Container(
                  width: 40,
                  height: 4,
                  margin: const EdgeInsets.symmetric(vertical: 12),
                  decoration: BoxDecoration(
                    color: Colors.grey[300],
                    borderRadius: BorderRadius.circular(2),
                  ),
                ),
                Expanded(
                  child: SingleChildScrollView(
                    controller: scrollController,
                    padding: const EdgeInsets.all(20),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        // Title and status
                        Row(
                          children: [
                            Expanded(
                              child: Text(
                                plan['title'] ?? 'AI 计划',
                                style: const TextStyle(
                                  fontSize: 18,
                                  fontWeight: FontWeight.bold,
                                  color: Colors.black,
                                ),
                              ),
                            ),
                            Container(
                              padding: const EdgeInsets.symmetric(
                                horizontal: 8,
                                vertical: 4,
                              ),
                              decoration: BoxDecoration(
                                color: (plan['isCompleted'] ?? false)
                                    ? Colors.green
                                    : Colors.orange,
                                borderRadius: BorderRadius.circular(12),
                              ),
                              child: Text(
                                (plan['isCompleted'] ?? false) ? '已完成' : '进行中',
                                style: const TextStyle(
                                  color: Colors.white,
                                  fontSize: 12,
                                ),
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 16),

                        // Goal information
                        _buildDetailCard(
                          '目标信息',
                          Icons.track_changes,
                          Colors.purple,
                          [
                            _buildDetailRow('目标类型', plan['goalType'] ?? ''),
                            _buildDetailRow('当前体重', '${plan['currentWeight'] ?? 0}kg'),
                            _buildDetailRow('期望变化', '${plan['weightChange'] ?? 0}kg'),
                            _buildDetailRow('计划时长', '${plan['durationDays'] ?? 0}天'),
                          ],
                        ),

                        // Training plan
                        _buildDetailCard(
                          '训练计划',
                          Icons.fitness_center,
                          Colors.blue,
                          [
                            Text(
                              plan['trainingPlan'] ?? '无训练计划',
                              style: const TextStyle(
                                height: 1.5,
                                color: Colors.black, // Black text
                              ),
                            ),
                          ],
                        ),

                        // Diet plan
                        _buildDetailCard(
                          '饮食计划',
                          Icons.restaurant,
                          Colors.orange,
                          [
                            Text(
                              plan['dietPlan'] ?? '无饮食计划',
                              style: const TextStyle(
                                height: 1.5,
                                color: Colors.black, // Black text
                              ),
                            ),
                          ],
                        ),

                        // Advice (if available)
                        if (plan['advice'] != null && plan['advice'].isNotEmpty)
                          _buildDetailCard(
                            '专家建议',
                            Icons.lightbulb_outline,
                            Colors.amber,
                            [
                              Text(
                                plan['advice'],
                                style: const TextStyle(
                                  height: 1.5,
                                  color: Colors.black, // Black text
                                ),
                              ),
                            ],
                          ),

                        const SizedBox(height: 20),

                        // Complete button (if plan not completed)
                        if (!(plan['isCompleted'] ?? false))
                          SizedBox(
                            width: double.infinity,
                            child: ElevatedButton(
                              onPressed: () => _completePlan(plan),
                              style: ElevatedButton.styleFrom(
                                backgroundColor: Colors.green,
                                foregroundColor: Colors.white,
                                padding: const EdgeInsets.symmetric(vertical: 12),
                              ),
                              child: const Text('完成计划并更新体重'),
                            ),
                          ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          );
        },
      ),
    );
  }

  Widget _buildDetailCard(String title, IconData icon, Color color, List<Widget> children) {
    return Card(
      margin: const EdgeInsets.only(bottom: 16),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(icon, color: color),
                const SizedBox(width: 8),
                Text(
                  title,
                  style: TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                    color: color,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),
            ...children,
          ],
        ),
      ),
    );
  }

  Widget _buildDetailRow(String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            label,
            style: const TextStyle(color: Colors.grey),
          ),
          Text(
            value,
            style: const TextStyle(
              fontWeight: FontWeight.w500,
              color: Colors.black, // Black text
            ),
          ),
        ],
      ),
    );
  }

  // Complete AI plan and update weight
  Future<void> _completePlan(Map<String, dynamic> plan) async {
    final user = _auth.currentUser;
    if (user == null) return;

    try {
      // Calculate new weight
      double currentWeight = (plan['currentWeight'] ?? 0).toDouble();
      double weightChange = (plan['weightChange'] ?? 0).toDouble();
      double newWeight = currentWeight;

      if (plan['goalType'] == 'Muscle Gain') {
        newWeight += weightChange;
      } else {
        newWeight -= weightChange;
      }

      // Update user weight
      await _firestore
          .collection('users')
          .doc(user.uid)
          .update({'weight': newWeight});

      // Mark plan as completed
      await _firestore
          .collection('users')
          .doc(user.uid)
          .collection('ai_plans')
          .doc(plan['id'])
          .update({
        'isCompleted': true,
        'completedAt': FieldValue.serverTimestamp(),
        'finalWeight': newWeight,
      });

      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('计划已完成！体重已更新为 ${newWeight.toStringAsFixed(1)}kg'),
            backgroundColor: Colors.green,
          ),
        );
        Navigator.pop(context); // Close details page
        _loadAIPlans(); // Reload AI plans
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('更新失败：$e'),
            backgroundColor: Colors.red,
          ),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('My Courses', style: TextStyle(color: Colors.black)),
        backgroundColor: Colors.white,
        iconTheme: const IconThemeData(color: Colors.black),
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : Column(
        children: [
          // Courses section
          Expanded(
            child: ListView.builder(
              itemCount: _purchasedCourses.length,
              itemBuilder: (context, index) {
                final course = _purchasedCourses[index];
                final isMain = course['isMainCourse'] == true;
                final title = course['title'] ?? 'Untitled';
                final category = course['category'] ?? 'Fitness';
                final userCourseId = course['userCourseId'];

                return GestureDetector(
                  onTap: isMain
                      ? () {
                    final trainingItems = _buildTrainingItems(
                      course['courseId'],
                      title,
                      category,
                    );
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => TodayTrainingScreen(
                          trainingItems: trainingItems,
                          courseId: course['courseId'],
                        ),
                      ),
                    );
                  }
                      : null,
                  child: Container(
                    margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      color: isMain ? const Color(0xFFFF9D00) : Colors.white,
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(color: Colors.grey.shade300),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.black.withOpacity(0.05),
                          blurRadius: 6,
                          offset: const Offset(0, 2),
                        ),
                      ],
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(title, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.black)),
                                const SizedBox(height: 4),
                                Text(category, style: const TextStyle(fontSize: 14, color: Colors.black87)),
                              ],
                            ),
                            if (!isMain)
                              TextButton.icon(
                                onPressed: () => _setAsMainCourse(userCourseId),
                                icon: Icon(Icons.star_border, color: Colors.deepPurple.shade600),
                                label: Text('设为主课程', style: TextStyle(color: Colors.deepPurple.shade600)),
                              )
                            else
                              Icon(Icons.star, color: Colors.deepPurple.shade600),
                          ],
                        ),
                        const SizedBox(height: 8),
                        Text('Sessions: ${course['completedSessions'] ?? 0}/${course['totalSessions'] ?? 0}',
                            style: const TextStyle(fontSize: 14, color: Colors.black87)),
                      ],
                    ),
                  ),
                );
              },
            ),
          ),

          // AI Plans section
          if (!_loadingAIPlans && _aiPlans.isNotEmpty) ...[
            Container(
              width: double.infinity,
              margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [Colors.purple.shade50, Colors.blue.shade50],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: Colors.purple.shade200),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Icon(Icons.auto_awesome, color: Colors.purple, size: 20),
                      const SizedBox(width: 8),
                      const Text(
                        'AI 健身计划',
                        style: TextStyle(
                          fontWeight: FontWeight.bold,
                          color: Colors.black, // Black text
                          fontSize: 16,
                        ),
                      ),
                      const Spacer(),
                      TextButton(
                        onPressed: showAIPlanOptions,
                        child: const Text(
                          '查看全部',
                          style: TextStyle(color: Colors.purple),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 8),
                  // Show recent AI plans
                  ...(_aiPlans.take(3).map((plan) => GestureDetector(
                    onTap: () => _showAIPlanDetails(plan),
                    child: Container(
                      width: double.infinity,
                      margin: const EdgeInsets.only(bottom: 8),
                      padding: const EdgeInsets.all(12),
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(8),
                        border: Border.all(color: Colors.grey.shade200),
                      ),
                      child: Row(
                        children: [
                          CircleAvatar(
                            backgroundColor: (plan['isCompleted'] ?? false)
                                ? Colors.green
                                : Colors.purple,
                            radius: 16,
                            child: Icon(
                              (plan['isCompleted'] ?? false)
                                  ? Icons.check
                                  : Icons.auto_awesome,
                              color: Colors.white,
                              size: 16,
                            ),
                          ),
                          const SizedBox(width: 12),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  plan['title'] ?? 'AI 计划',
                                  style: const TextStyle(
                                    fontWeight: FontWeight.w600,
                                    color: Colors.black, // Black text
                                    fontSize: 14,
                                  ),
                                ),
                                const SizedBox(height: 2),
                                Text(
                                  '${plan['goalType'] ?? ''} • ${plan['durationDays'] ?? 0}天',
                                  style: const TextStyle(
                                    color: Colors.black87, // Dark text
                                    fontSize: 12,
                                  ),
                                ),
                              ],
                            ),
                          ),
                          Container(
                            padding: const EdgeInsets.symmetric(
                              horizontal: 6,
                              vertical: 2,
                            ),
                            decoration: BoxDecoration(
                              color: (plan['isCompleted'] ?? false)
                                  ? Colors.green.shade100
                                  : Colors.orange.shade100,
                              borderRadius: BorderRadius.circular(8),
                            ),
                            child: Text(
                              (plan['isCompleted'] ?? false) ? '已完成' : '进行中',
                              style: TextStyle(
                                fontSize: 10,
                                color: (plan['isCompleted'] ?? false)
                                    ? Colors.green.shade700
                                    : Colors.orange.shade700,
                              ),
                            ),
                          ),
                          const SizedBox(width: 8),
                          Icon(
                            Icons.arrow_forward_ios,
                            size: 14,
                            color: Colors.grey[600],
                          ),
                        ],
                      ),
                    ),
                  ))),
                ],
              ),
            ),
          ],

          // AI Generation button
          Padding(
            padding: const EdgeInsets.all(16.0),
            child: ElevatedButton.icon(
              onPressed: showAIPlanOptions,
              icon: const Icon(Icons.bolt),
              label: const Text('生成 AI 智能训练（观看广告）'),
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.deepPurple,
                foregroundColor: Colors.white,
                padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 24),
                textStyle: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
              ),
            ),
          ),
        ],
      ),
    );
  }
}