import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'today_training_screen.dart';
import 'ai_plan_modal.dart';

class MyCoursesScreen extends StatefulWidget {
  const MyCoursesScreen({super.key});

  @override
  State<MyCoursesScreen> createState() => _MyCoursesScreenState();
}

class _MyCoursesScreenState extends State<MyCoursesScreen> {
  final FirebaseAuth _auth = FirebaseAuth.instance;
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  List<Map<String, dynamic>> _purchasedCourses = [];
  List<Map<String, dynamic>> _aiPlans = [];
  bool _isLoading = true;
  bool _loadingAIPlans = true;
  String? _mainCourseId;

  @override
  void initState() {
    super.initState();
    _loadCourses();
    _loadAIPlans();
  }

  Future<void> _loadCourses() async {
    try {
      final user = _auth.currentUser;
      if (user == null) return;

      final snapshot = await _firestore
          .collection('user_courses')
          .where('userId', isEqualTo: user.uid)
          .get();

      final courses = snapshot.docs.map((doc) => {
        ...doc.data(),
        'userCourseId': doc.id,
      }).toList();

      final mainCourse = courses.firstWhere(
            (c) => c['isMainCourse'] == true,
        orElse: () => {},
      );

      if (mounted) {
        setState(() {
          _purchasedCourses = courses;
          _mainCourseId = mainCourse['userCourseId'];
          _isLoading = false;
        });
      }
    } catch (e) {
      print('Error loading courses: $e');
      if (mounted) {
        setState(() => _isLoading = false);
      }
    }
  }

  // Load AI plans from Firestore with progress calculation
  Future<void> _loadAIPlans() async {
    final user = _auth.currentUser;
    if (user == null) {
      setState(() => _loadingAIPlans = false);
      return;
    }

    try {
      final querySnapshot = await _firestore
          .collection('users')
          .doc(user.uid)
          .collection('ai_plans')
          .orderBy('createdAt', descending: true)
          .get();

      List<Map<String, dynamic>> plans = [];

      for (var doc in querySnapshot.docs) {
        final data = doc.data();
        data['id'] = doc.id;
        await _calculateActualProgress(data, user.uid);
        plans.add(data);
      }

      setState(() {
        _aiPlans = plans;
        _loadingAIPlans = false;
      });
    } catch (e) {
      debugPrint('Failed to load AI plans: $e');
      setState(() => _loadingAIPlans = false);
    }
  }

  Future<void> _calculateActualProgress(Map<String, dynamic> planData, String userId) async {
    try {
      final planId = planData['id'];
      final totalDays = planData['durationDays'] as int? ?? 0;
      final createdAt = planData['createdAt'] as Timestamp?;

      if (createdAt == null || totalDays == 0) {
        planData['actualTrainingDays'] = 0;
        planData['progressPercentage'] = 0.0;
        planData['isCompleted'] = false;
        return;
      }

      final planStartDate = createdAt.toDate();

      final checkInQuery = await _firestore
          .collection('check_ins')
          .where('userId', isEqualTo: userId)
          .where('aiPlanId', isEqualTo: planId)
          .where('checkInType', isEqualTo: 'training_completed')
          .where('checkInDate', isGreaterThanOrEqualTo: Timestamp.fromDate(planStartDate))
          .get();

      final actualTrainingDays = checkInQuery.docs.length;
      final progressPercentage = totalDays > 0
          ? (actualTrainingDays / totalDays * 100).clamp(0.0, 100.0)
          : 0.0;

      final wasManuallyCompleted = planData['isCompleted'] == true;
      final shouldAutoComplete = actualTrainingDays >= totalDays;
      final isCompleted = wasManuallyCompleted || shouldAutoComplete;

      if (shouldAutoComplete && !wasManuallyCompleted) {
        try {
          await _firestore
              .collection('users')
              .doc(userId)
              .collection('ai_plans')
              .doc(planId)
              .update({
            'isCompleted': true,
            'completedAt': FieldValue.serverTimestamp(),
            'progressPercentage': 100.0,
            'autoCompletedByTraining': true,
          });
        } catch (e) {
          debugPrint('Auto complete failed: $e');
        }
      }

      planData['actualTrainingDays'] = actualTrainingDays;
      planData['progressPercentage'] = progressPercentage;
      planData['isCompleted'] = isCompleted;
      planData['remainingDays'] = (totalDays - actualTrainingDays).clamp(0, totalDays);

    } catch (e) {
      debugPrint('Error calculating progress: $e');
      planData['actualTrainingDays'] = 0;
      planData['progressPercentage'] = 0.0;
      planData['isCompleted'] = false;
    }
  }

  Future<void> _setAsMainCourse(String userCourseId) async {
    final user = _auth.currentUser;
    if (user == null) return;

    setState(() => _isLoading = true);

    final batch = _firestore.batch();
    final allCourses = await _firestore
        .collection('user_courses')
        .where('userId', isEqualTo: user.uid)
        .get();

    for (final doc in allCourses.docs) {
      batch.update(doc.reference, {'isMainCourse': false});
    }
    batch.update(
      _firestore.collection('user_courses').doc(userCourseId),
      {'isMainCourse': true},
    );

    await batch.commit();
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('已设置为主课程')),
      );
      await _loadCourses();
    }
  }

  List<TrainingItem> _buildTrainingItems(String courseId, String title, String category) {
    List<TrainingItem> middleItems;

    if (title == 'Core & Posture Training') {
      middleItems = [
        TrainingItem(name: 'Plank', durationMinutes: 5, color: Colors.green[100]!, icon: Icons.fitness_center, courseId: courseId, title: title, category: category),
        TrainingItem(name: 'Bird Dog', durationMinutes: 5, color: Colors.yellow[100]!, icon: Icons.fitness_center, courseId: courseId, title: title, category: category),
        TrainingItem(name: 'Side Plank', durationMinutes: 5, color: Colors.blue[100]!, icon: Icons.fitness_center, courseId: courseId, title: title, category: category),
      ];
    } else if (title == 'Muscle Building Plan') {
      middleItems = [
        TrainingItem(name: 'Squat', durationMinutes: 15, color: Colors.orange, icon: Icons.fitness_center, courseId: courseId, title: title, category: category),
        TrainingItem(name: 'Bench Press', durationMinutes: 15, color: Colors.pink, icon: Icons.fitness_center, courseId: courseId, title: title, category: category),
        TrainingItem(name: 'Deadlift', durationMinutes: 15, color: Colors.purple, icon: Icons.fitness_center, courseId: courseId, title: title, category: category),
      ];
    } else if (title == 'Fat Burning Program') {
      middleItems = [
        TrainingItem(name: 'Jumping Jacks', durationMinutes: 10, color: Colors.red, icon: Icons.directions_run, courseId: courseId, title: title, category: category),
        TrainingItem(name: 'Mountain Climbers', durationMinutes: 10, color: Colors.orange, icon: Icons.directions_run, courseId: courseId, title: title, category: category),
        TrainingItem(name: 'Burpees', durationMinutes: 10, color: Colors.teal, icon: Icons.directions_run, courseId: courseId, title: title, category: category),
      ];
    } else {
      middleItems = [];
    }

    return [
      TrainingItem(name: 'Warm-up', durationMinutes: 10, color: Colors.redAccent, icon: Icons.directions_run, courseId: courseId, title: title, category: category),
      ...middleItems,
      TrainingItem(name: 'Cool-down', durationMinutes: 10, color: Colors.cyanAccent, icon: Icons.spa, courseId: courseId, title: title, category: category),
    ];
  }

  void onNewPlanSaved(String newPlanTitle) {
    // Reload AI plans when a new plan is saved
    _loadAIPlans();
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('AI 计划 "$newPlanTitle" 已添加')),
    );
  }

  void showAIPlanOptions() {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.white,
      builder: (context) => Container(
        decoration: const BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
        ),
        child: AIPlanModal(
          onNewPlanSaved: onNewPlanSaved,
          aiPlans: const [], // Pass empty list since we're loading from Firestore
        ),
      ),
    );
  }

  // Check if user has trained today for specific AI plan
  Future<bool> _hasTrainedToday(String planId) async {
    final user = _auth.currentUser;
    if (user == null) return false;

    try {
      final today = DateTime.now();
      final startOfDay = DateTime(today.year, today.month, today.day);
      final endOfDay = startOfDay.add(const Duration(days: 1));

      final querySnapshot = await _firestore
          .collection('check_ins')
          .where('userId', isEqualTo: user.uid)
          .where('aiPlanId', isEqualTo: planId)
          .where('checkInType', isEqualTo: 'training_completed')
          .where('checkInDate', isGreaterThanOrEqualTo: Timestamp.fromDate(startOfDay))
          .where('checkInDate', isLessThan: Timestamp.fromDate(endOfDay))
          .limit(1)
          .get();

      return querySnapshot.docs.isNotEmpty;
    } catch (e) {
      debugPrint('Error checking today training: $e');
      return false;
    }
  }

  // Start today's training for AI plan
  void _startTodayTraining(Map<String, dynamic> plan) async {
    final hasTrainedToday = await _hasTrainedToday(plan['id']);

    if (hasTrainedToday) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('您今天已经完成训练了！'),
          backgroundColor: Colors.orange,
        ),
      );
      return;
    }

    final trainingItems = _createSimpleTrainingItemForAI(plan);

    final result = await Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => TodayTrainingScreen(
          trainingItems: trainingItems,
          courseId: plan['id'],
          aiPlanId: plan['id'],
          fullTrainingPlan: plan['trainingPlan'],
        ),
      ),
    );

    if (result == 'completed' && mounted) {
      _loadAIPlans();
    }
  }

  // Create training item for AI plan
  List<TrainingItem> _createSimpleTrainingItemForAI(Map<String, dynamic> plan) {
    return [
      TrainingItem(
        name: plan['trainingPlan'] ?? '',
        durationMinutes: 30,
        color: Colors.purple,
        icon: Icons.auto_awesome,
        courseId: plan['id'],
        title: plan['title'] ?? 'AI Training',
        category: plan['goalType'] ?? 'Fitness',
      ),
    ];
  }

  // Delete AI plan
  Future<void> _deleteAIPlan(Map<String, dynamic> plan) async {
    final user = _auth.currentUser;
    if (user == null) return;

    // Show confirmation dialog
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text(
          '删除计划',
          style: TextStyle(color: Colors.black), // 改为黑色
        ),
        content: Text(
          '确定要删除计划 "${plan['title'] ?? 'AI 计划'}" 吗？此操作无法撤销。',
          style: const TextStyle(color: Colors.black), // 改为黑色
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(false),
            child: const Text(
              '取消',
              style: TextStyle(color: Colors.black), // 改为黑色
            ),
          ),
          TextButton(
            onPressed: () => Navigator.of(context).pop(true),
            style: TextButton.styleFrom(
              foregroundColor: Colors.red,
            ),
            child: const Text('删除'),
          ),
        ],
      ),
    );

    if (confirmed != true) return;

    try {
      // Delete the AI plan document
      await _firestore
          .collection('users')
          .doc(user.uid)
          .collection('ai_plans')
          .doc(plan['id'])
          .delete();

      // Also delete related check-ins
      final checkInsQuery = await _firestore
          .collection('check_ins')
          .where('userId', isEqualTo: user.uid)
          .where('aiPlanId', isEqualTo: plan['id'])
          .get();

      final batch = _firestore.batch();
      for (final doc in checkInsQuery.docs) {
        batch.delete(doc.reference);
      }
      await batch.commit();

      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('计划已删除'),
            backgroundColor: Colors.green,
          ),
        );
        Navigator.pop(context); // Close details page
        _loadAIPlans(); // Reload AI plans
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('删除失败：$e'),
            backgroundColor: Colors.red,
          ),
        );
      }
    }
  }

  // Show AI plan details
  void _showAIPlanDetails(Map<String, dynamic> plan) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (context) => DraggableScrollableSheet(
        initialChildSize: 0.7,
        minChildSize: 0.5,
        maxChildSize: 0.95,
        builder: (context, scrollController) {
          return Container(
            decoration: const BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
            ),
            child: Column(
              children: [
                // Drag indicator
                Container(
                  width: 40,
                  height: 4,
                  margin: const EdgeInsets.symmetric(vertical: 12),
                  decoration: BoxDecoration(
                    color: Colors.grey[300],
                    borderRadius: BorderRadius.circular(2),
                  ),
                ),
                Expanded(
                  child: SingleChildScrollView(
                    controller: scrollController,
                    padding: const EdgeInsets.all(20),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        // Title, status and delete button
                        Row(
                          children: [
                            Expanded(
                              child: Text(
                                plan['title'] ?? 'AI 计划',
                                style: const TextStyle(
                                  fontSize: 18,
                                  fontWeight: FontWeight.bold,
                                  color: Colors.black, // 改为黑色
                                ),
                              ),
                            ),
                            Container(
                              padding: const EdgeInsets.symmetric(
                                horizontal: 8,
                                vertical: 4,
                              ),
                              decoration: BoxDecoration(
                                color: (plan['isCompleted'] ?? false)
                                    ? Colors.green
                                    : Colors.orange,
                                borderRadius: BorderRadius.circular(12),
                              ),
                              child: Text(
                                (plan['isCompleted'] ?? false) ? '已完成' : '进行中',
                                style: const TextStyle(
                                  color: Colors.white,
                                  fontSize: 12,
                                ),
                              ),
                            ),
                            const SizedBox(width: 8),
                            IconButton(
                              onPressed: () => _deleteAIPlan(plan),
                              icon: const Icon(Icons.delete_outline),
                              color: Colors.red,
                              tooltip: '删除计划',
                            ),
                          ],
                        ),
                        const SizedBox(height: 16),

                        // Progress section
                        Container(
                          padding: const EdgeInsets.all(16),
                          decoration: BoxDecoration(
                            color: Colors.grey[50],
                            borderRadius: BorderRadius.circular(12),
                            border: Border.all(color: Colors.grey.shade200),
                          ),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Row(
                                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                children: [
                                  const Text(
                                    '训练进度',
                                    style: TextStyle(
                                      fontSize: 14,
                                      fontWeight: FontWeight.bold,
                                      color: Colors.black, // 改为黑色
                                    ),
                                  ),
                                  Text(
                                    '${(plan['progressPercentage'] ?? 0).toInt()}%',
                                    style: TextStyle(
                                      fontSize: 14,
                                      fontWeight: FontWeight.bold,
                                      color: (plan['isCompleted'] ?? false) ? Colors.green : Colors.orange,
                                    ),
                                  ),
                                ],
                              ),
                              const SizedBox(height: 8),
                              Container(
                                height: 8,
                                decoration: BoxDecoration(
                                  color: Colors.grey[200],
                                  borderRadius: BorderRadius.circular(4),
                                ),
                                child: FractionallySizedBox(
                                  alignment: Alignment.centerLeft,
                                  widthFactor: (plan['progressPercentage'] ?? 0) / 100,
                                  child: Container(
                                    decoration: BoxDecoration(
                                      color: (plan['isCompleted'] ?? false) ? Colors.green : Colors.orange,
                                      borderRadius: BorderRadius.circular(4),
                                    ),
                                  ),
                                ),
                              ),
                              const SizedBox(height: 8),
                              Text(
                                '训练天数: ${plan['actualTrainingDays'] ?? 0}/${plan['durationDays'] ?? 0}',
                                style: const TextStyle(
                                  fontSize: 12,
                                  color: Colors.black, // 改为黑色
                                ),
                              ),
                              if (!(plan['isCompleted'] ?? false))
                                Text(
                                  '剩余: ${plan['remainingDays'] ?? 0} 天',
                                  style: const TextStyle(
                                    fontSize: 12,
                                    color: Colors.black, // 改为黑色
                                  ),
                                ),
                            ],
                          ),
                        ),
                        const SizedBox(height: 16),

                        // Goal information
                        _buildDetailCard(
                          '目标信息',
                          Icons.track_changes,
                          Colors.purple,
                          [
                            _buildDetailRow('目标类型', plan['goalType'] ?? ''),
                            _buildDetailRow('当前体重', '${plan['currentWeight'] ?? 0}kg'),
                            _buildDetailRow('期望变化', '${plan['weightChange'] ?? 0}kg'),
                            _buildDetailRow('计划时长', '${plan['durationDays'] ?? 0}天'),
                            _buildDetailRow('每日食物预算', 'RM ${plan['dailyFoodBudget']?.toStringAsFixed(0) ?? '20'}'), // 新增预算显示
                          ],
                        ),

                        // Training plan
                        _buildDetailCard(
                          '训练计划',
                          Icons.fitness_center,
                          Colors.blue,
                          [
                            Text(
                              plan['trainingPlan'] ?? '无训练计划',
                              style: const TextStyle(
                                height: 1.5,
                                color: Colors.black, // 改为黑色
                              ),
                            ),
                          ],
                        ),

                        // Diet plan with pricing
                        _buildDetailCard(
                          '饮食计划 (含价格)', // 更新标题提及价格
                          Icons.restaurant,
                          Colors.orange,
                          [
                            Text(
                              plan['dietPlan'] ?? '无饮食计划',
                              style: const TextStyle(
                                height: 1.5,
                                color: Colors.black, // 改为黑色
                              ),
                            ),
                          ],
                        ),

                        // Advice (if available)
                        if (plan['advice'] != null && plan['advice'].isNotEmpty)
                          _buildDetailCard(
                            '专家建议',
                            Icons.lightbulb_outline,
                            Colors.amber,
                            [
                              Text(
                                plan['advice'],
                                style: const TextStyle(
                                  height: 1.5,
                                  color: Colors.black, // 改为黑色
                                ),
                              ),
                            ],
                          ),

                        const SizedBox(height: 20),

                        // Action buttons
                        Column(
                          children: [
                            // Start training button (if plan not completed)
                            if (!(plan['isCompleted'] ?? false))
                              SizedBox(
                                width: double.infinity,
                                child: ElevatedButton.icon(
                                  onPressed: () {
                                    Navigator.pop(context);
                                    _startTodayTraining(plan);
                                  },
                                  icon: const Icon(Icons.play_arrow),
                                  label: const Text('开始今天的训练'),
                                  style: ElevatedButton.styleFrom(
                                    backgroundColor: Colors.deepPurple,
                                    foregroundColor: Colors.white,
                                    padding: const EdgeInsets.symmetric(vertical: 12),
                                  ),
                                ),
                              ),

                            const SizedBox(height: 12),

                            // Delete button
                            SizedBox(
                              width: double.infinity,
                              child: OutlinedButton.icon(
                                onPressed: () => _deleteAIPlan(plan),
                                icon: const Icon(Icons.delete_outline),
                                label: const Text('删除计划'),
                                style: OutlinedButton.styleFrom(
                                  foregroundColor: Colors.red,
                                  side: const BorderSide(color: Colors.red),
                                  padding: const EdgeInsets.symmetric(vertical: 12),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          );
        },
      ),
    );
  }

  Widget _buildDetailCard(String title, IconData icon, Color color, List<Widget> children) {
    return Card(
      margin: const EdgeInsets.only(bottom: 16),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(icon, color: color),
                const SizedBox(width: 8),
                Text(
                  title,
                  style: TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                    color: color, // 保持图标的颜色一致性
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),
            ...children,
          ],
        ),
      ),
    );
  }

  Widget _buildDetailRow(String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            label,
            style: const TextStyle(color: Colors.black), // 改为黑色
          ),
          Text(
            value,
            style: const TextStyle(
              fontWeight: FontWeight.w500,
              color: Colors.black, // 改为黑色
            ),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
            'My Courses',
            style: TextStyle(color: Colors.black) // 改为黑色
        ),
        backgroundColor: Colors.white,
        iconTheme: const IconThemeData(color: Colors.black),
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : Column(
        children: [
          // Courses section
          Expanded(
            child: ListView.builder(
              itemCount: _purchasedCourses.length,
              itemBuilder: (context, index) {
                final course = _purchasedCourses[index];
                final isMain = course['isMainCourse'] == true;
                final title = course['title'] ?? 'Untitled';
                final category = course['category'] ?? 'Fitness';
                final userCourseId = course['userCourseId'];

                return GestureDetector(
                  onTap: isMain
                      ? () {
                    final trainingItems = _buildTrainingItems(
                      course['courseId'],
                      title,
                      category,
                    );
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => TodayTrainingScreen(
                          trainingItems: trainingItems,
                          courseId: course['courseId'],
                        ),
                      ),
                    );
                  }
                      : null,
                  child: Container(
                    margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      color: isMain ? const Color(0xFFFF9D00) : Colors.white,
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(color: Colors.grey.shade300),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.black.withOpacity(0.05),
                          blurRadius: 6,
                          offset: const Offset(0, 2),
                        ),
                      ],
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                    title,
                                    style: const TextStyle(
                                        fontSize: 18,
                                        fontWeight: FontWeight.bold,
                                        color: Colors.black
                                    )
                                ),
                                const SizedBox(height: 4),
                                Text(
                                    category,
                                    style: const TextStyle(
                                        fontSize: 14,
                                        color: Colors.black // 改为黑色
                                    )
                                ),
                              ],
                            ),
                            if (!isMain)
                              TextButton.icon(
                                onPressed: () => _setAsMainCourse(userCourseId),
                                icon: Icon(Icons.star_border, color: Colors.deepPurple.shade600),
                                label: Text(
                                    '设为主课程',
                                    style: TextStyle(color: Colors.deepPurple.shade600)
                                ),
                              )
                            else
                              Icon(Icons.star, color: Colors.deepPurple.shade600),
                          ],
                        ),
                        const SizedBox(height: 8),
                        Text(
                            'Sessions: ${course['completedSessions'] ?? 0}/${course['totalSessions'] ?? 0}',
                            style: const TextStyle(
                                fontSize: 14,
                                color: Colors.black // 改为黑色
                            )
                        ),
                      ],
                    ),
                  ),
                );
              },
            ),
          ),

          // AI Plans section
          if (!_loadingAIPlans && _aiPlans.isNotEmpty) ...[
            Container(
              width: double.infinity,
              margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [Colors.purple.shade50, Colors.blue.shade50],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: Colors.purple.shade200),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Icon(Icons.auto_awesome, color: Colors.purple, size: 20),
                      const SizedBox(width: 8),
                      const Text(
                        'AI 健身计划 (含预算)', // 更新标题提及预算
                        style: TextStyle(
                          fontWeight: FontWeight.bold,
                          color: Colors.black, // 改为黑色
                          fontSize: 16,
                        ),
                      ),
                      const Spacer(),
                      TextButton(
                        onPressed: showAIPlanOptions,
                        child: const Text(
                          '查看全部',
                          style: TextStyle(color: Colors.purple),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 8),
                  // Show recent AI plans with progress
                  ...(_aiPlans.take(3).map((plan) => GestureDetector(
                    onTap: () => _showAIPlanDetails(plan),
                    child: Container(
                      width: double.infinity,
                      margin: const EdgeInsets.only(bottom: 8),
                      padding: const EdgeInsets.all(12),
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(8),
                        border: Border.all(color: Colors.grey.shade200),
                      ),
                      child: Column(
                        children: [
                          Row(
                            children: [
                              CircleAvatar(
                                backgroundColor: (plan['isCompleted'] ?? false)
                                    ? Colors.green
                                    : Colors.purple,
                                radius: 16,
                                child: Icon(
                                  (plan['isCompleted'] ?? false)
                                      ? Icons.check
                                      : Icons.auto_awesome,
                                  color: Colors.white,
                                  size: 16,
                                ),
                              ),
                              const SizedBox(width: 12),
                              Expanded(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      plan['title'] ?? 'AI 计划',
                                      style: const TextStyle(
                                        fontWeight: FontWeight.w600,
                                        color: Colors.black, // 改为黑色
                                        fontSize: 14,
                                      ),
                                    ),
                                    const SizedBox(height: 2),
                                    Text(
                                      '${plan['goalType'] ?? ''} • ${plan['durationDays'] ?? 0}天 • RM${plan['dailyFoodBudget']?.toStringAsFixed(0) ?? '20'}/日', // 添加预算信息
                                      style: const TextStyle(
                                        color: Colors.black, // 改为黑色
                                        fontSize: 12,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              Container(
                                padding: const EdgeInsets.symmetric(
                                  horizontal: 6,
                                  vertical: 2,
                                ),
                                decoration: BoxDecoration(
                                  color: (plan['isCompleted'] ?? false)
                                      ? Colors.green.shade100
                                      : Colors.orange.shade100,
                                  borderRadius: BorderRadius.circular(8),
                                ),
                                child: Text(
                                  (plan['isCompleted'] ?? false) ? '已完成' : '进行中',
                                  style: TextStyle(
                                    fontSize: 10,
                                    color: (plan['isCompleted'] ?? false)
                                        ? Colors.green.shade700
                                        : Colors.orange.shade700,
                                  ),
                                ),
                              ),
                              const SizedBox(width: 8),
                              // Quick delete button
                              InkWell(
                                onTap: () => _deleteAIPlan(plan),
                                borderRadius: BorderRadius.circular(12),
                                child: Container(
                                  padding: const EdgeInsets.all(4),
                                  child: Icon(
                                    Icons.close,
                                    size: 16,
                                    color: Colors.grey[600],
                                  ),
                                ),
                              ),
                              const SizedBox(width: 4),
                              Icon(
                                Icons.arrow_forward_ios,
                                size: 14,
                                color: Colors.grey[600],
                              ),
                            ],
                          ),
                          const SizedBox(height: 8),
                          // Progress bar
                          Container(
                            height: 4,
                            decoration: BoxDecoration(
                              color: Colors.grey[200],
                              borderRadius: BorderRadius.circular(2),
                            ),
                            child: FractionallySizedBox(
                              alignment: Alignment.centerLeft,
                              widthFactor: (plan['progressPercentage'] ?? 0) / 100,
                              child: Container(
                                decoration: BoxDecoration(
                                  color: (plan['isCompleted'] ?? false) ? Colors.green : Colors.purple,
                                  borderRadius: BorderRadius.circular(2),
                                ),
                              ),
                            ),
                          ),
                          const SizedBox(height: 4),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Text(
                                '${(plan['progressPercentage'] ?? 0).toInt()}% 完成',
                                style: const TextStyle(
                                  fontSize: 10,
                                  color: Colors.black, // 改为黑色
                                ),
                              ),
                              Text(
                                '训练: ${plan['actualTrainingDays'] ?? 0}/${plan['durationDays'] ?? 0}',
                                style: const TextStyle(
                                  fontSize: 10,
                                  color: Colors.black, // 改为黑色
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ))),
                ],
              ),
            ),
          ],

          // AI Generation button
          Padding(
            padding: const EdgeInsets.all(16.0),
            child: ElevatedButton.icon(
              onPressed: showAIPlanOptions,
              icon: const Icon(Icons.bolt),
              label: const Text('生成 AI 智能训练（观看广告）'),
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.deepPurple,
                foregroundColor: Colors.white,
                padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 24),
                textStyle: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
              ),
            ),
          ),
        ],
      ),
    );
  }
}