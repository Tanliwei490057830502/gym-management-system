// screens/appointment_schedule_screen.dart
import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import '../services/firebase_service.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class AppointmentScheduleScreen extends StatefulWidget {
  final DateTime? preselectedDate;
  final String? preselectedCoachId;
  final String? preselectedGymId;

  const AppointmentScheduleScreen({
    super.key,
    this.preselectedDate,
    this.preselectedCoachId,
    this.preselectedGymId,
  });

  @override
  State<AppointmentScheduleScreen> createState() => _AppointmentScheduleScreenState();
}

class _AppointmentScheduleScreenState extends State<AppointmentScheduleScreen> {
  late DateTime selectedDate;
  String? selectedTimeSlot;
  String? selectedCoachId;
  String? selectedGymId;
  int _selectedIndex = 1;

  List<Map<String, dynamic>> coaches = [
    {'id': 'coach1', 'name': 'John Doe', 'specialization': 'Strength Training'},
    {'id': 'coach2', 'name': 'Jane Smith', 'specialization': 'Cardio Fitness'},
  ];

  List<Map<String, dynamic>> gyms = [
    {'id': 'gym1', 'name': 'LTC Fitness Center', 'address': '123 Gym St'},
    {'id': 'gym2', 'name': 'Downtown Gym', 'address': '456 Workout Ave'},
  ];

  List<String> bookedTimeSlots = [];

  final List<String> allTimeSlots = [
    '8:00 AM - 10:00 AM',
    '10:00 AM - 12:00 PM',
    '1:00 PM - 3:00 PM',
    '3:00 PM - 5:00 PM',
    '5:00 PM - 7:00 PM',
  ];

  bool _isLoading = false;
  bool _isBooking = false;

  @override
  void initState() {
    super.initState();
    selectedDate = widget.preselectedDate ?? DateTime.now();
    selectedCoachId = widget.preselectedCoachId ?? coaches.first['id'];
    selectedGymId = widget.preselectedGymId ?? gyms.first['id'];
    _loadBookedTimeSlots();
  }

  Future<void> _loadBookedTimeSlots() async {
    setState(() => bookedTimeSlots = ['10:00 AM - 12:00 PM']);
  }

  List<String> get availableSlots =>
      allTimeSlots.where((slot) => !bookedTimeSlots.contains(slot)).toList();

  void _onItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });
    Navigator.pushReplacementNamed(context, '/main', arguments: {'initialIndex': index});
  }

  Future<void> _bookAppointment() async {
    final user = FirebaseAuth.instance.currentUser;
    if (user == null || selectedCoachId == null || selectedGymId == null || selectedTimeSlot == null) return;

    setState(() => _isBooking = true);

    final selectedCoach = coaches.firstWhere((c) => c['id'] == selectedCoachId);
    final selectedGym = gyms.firstWhere((g) => g['id'] == selectedGymId);

    final appointmentData = {
      'userId': user.uid,
      'userEmail': user.email,
      'coachId': selectedCoachId,
      'coachName': selectedCoach['name'],
      'gymId': selectedGymId,
      'gymName': selectedGym['name'],
      'date': Timestamp.fromDate(selectedDate),
      'timeSlot': selectedTimeSlot,
      'status': 'confirmed',
      'createdAt': Timestamp.now(),
    };

    try {
      await FirebaseService.createAppointment(
        coachId: selectedCoachId!,
        gymId: selectedGymId!,
        date: selectedDate,
        timeSlot: selectedTimeSlot!,
        userId: user.uid,
      );

      if (mounted) {
        // 导航到成功页面
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) => AppointmentSuccessScreen(
              appointmentData: appointmentData,
            ),
          ),
        );
      }
    } catch (e) {
      if (mounted) {
        showDialog(
          context: context,
          builder: (_) => AlertDialog(
            title: const Text('Error'),
            content: Text('Failed to book appointment: $e'),
            actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('OK'))],
          ),
        );
      }
    } finally {
      setState(() => _isBooking = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        title: const Text('Book Appointment'),
        backgroundColor: Colors.white,
        foregroundColor: Colors.black,
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            DropdownButtonFormField<String>(
              value: selectedCoachId,
              items: coaches
                  .map((c) => DropdownMenuItem<String>(
                value: c['id'] as String,
                child: Text(c['name'], style: const TextStyle(color: Colors.black)),
              ))
                  .toList(),
              onChanged: (val) {
                setState(() => selectedCoachId = val);
                _loadBookedTimeSlots();
              },
              decoration: const InputDecoration(
                labelText: 'Coach',
                labelStyle: TextStyle(color: Colors.black),
              ),
              style: const TextStyle(color: Colors.black),
            ),
            const SizedBox(height: 10),
            DropdownButtonFormField<String>(
              value: selectedGymId,
              items: gyms
                  .map((g) => DropdownMenuItem<String>(
                value: g['id'] as String,
                child: Text(g['name']),
              ))
                  .toList(),
              onChanged: (val) {
                setState(() => selectedGymId = val);
                _loadBookedTimeSlots();
              },
              decoration: const InputDecoration(labelText: 'Gym'),
            ),
            const SizedBox(height: 10),
            ElevatedButton(
              onPressed: _selectDate,
              style: ElevatedButton.styleFrom(
                foregroundColor: Colors.black,
                backgroundColor: Colors.grey[200],
              ),
              child: Text('Select Date: ${selectedDate.day}/${selectedDate.month}/${selectedDate.year}'),
            ),
            const SizedBox(height: 10),
            DropdownButtonFormField<String>(
              value: selectedTimeSlot,
              items: availableSlots
                  .map((s) => DropdownMenuItem<String>(value: s, child: Text(s)))
                  .toList(),
              onChanged: (val) => setState(() => selectedTimeSlot = val),
              decoration: const InputDecoration(
                labelText: 'Time Slot',
                labelStyle: TextStyle(color: Colors.black),
              ),
              style: const TextStyle(color: Colors.black),
            ),
            const Spacer(),
            ElevatedButton(
              onPressed: _isBooking ? null : _bookAppointment,
              child: _isBooking ? const CircularProgressIndicator() : const Text('Book Appointment'),
            ),
          ],
        ),
      ),
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _selectedIndex,
        onTap: _onItemTapped,
        backgroundColor: Colors.white,
        selectedItemColor: Colors.deepPurple,
        unselectedItemColor: Colors.grey,
        items: const [
          BottomNavigationBarItem(icon: Icon(Icons.home), label: 'Home'),
          BottomNavigationBarItem(icon: Icon(Icons.calendar_today), label: 'Schedule'),
          BottomNavigationBarItem(icon: Icon(Icons.analytics), label: 'Analytics'),
          BottomNavigationBarItem(icon: Icon(Icons.chat), label: 'Chat'),
        ],
      ),
    );
  }

  Future<void> _selectDate() async {
    final picked = await showDatePicker(
      context: context,
      initialDate: selectedDate,
      firstDate: DateTime.now(),
      lastDate: DateTime.now().add(const Duration(days: 30)),
    );
    if (picked != null) {
      setState(() => selectedDate = picked);
      _loadBookedTimeSlots();
    }
  }
}

// Appointment Success Screen
class AppointmentSuccessScreen extends StatelessWidget {
  final Map<String, dynamic> appointmentData;

  const AppointmentSuccessScreen({
    super.key,
    required this.appointmentData,
  });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(20),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              // Success icon
              Container(
                width: 100,
                height: 100,
                decoration: const BoxDecoration(
                  color: Colors.green,
                  shape: BoxShape.circle,
                ),
                child: const Icon(
                  Icons.check,
                  color: Colors.white,
                  size: 60,
                ),
              ),

              const SizedBox(height: 40),

              // Success message
              const Text(
                'Appointment Booked!',
                style: TextStyle(
                  fontSize: 32,
                  fontWeight: FontWeight.bold,
                  color: Colors.black,
                ),
              ),

              const SizedBox(height: 16),

              const Text(
                'Your appointment has been successfully scheduled.',
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontSize: 16,
                  color: Colors.grey,
                ),
              ),

              const SizedBox(height: 30),

              // Appointment details card
              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(20),
                decoration: BoxDecoration(
                  color: Colors.deepPurple[50],
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: Colors.deepPurple.shade100),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text(
                      'Appointment Details',
                      style: TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                        color: Colors.deepPurple,
                      ),
                    ),
                    const SizedBox(height: 12),
                    _buildDetailRow('Date:', (appointmentData['date'] as Timestamp).toDate().toLocal().toString().split(' ')[0]),
                    _buildDetailRow('Time:', appointmentData['timeSlot'] ?? ''),
                    _buildDetailRow('Coach:', appointmentData['coachName'] ?? ''),
                    _buildDetailRow('Gym:', appointmentData['gymName'] ?? ''),
                  ],
                ),
              ),

              const SizedBox(height: 40),

              Column(
                children: [
                  // Go Home - 返回到主界面
                  SizedBox(
                    width: double.infinity,
                    child: ElevatedButton(
                      onPressed: () {
                        // 清除所有导航栈，直接到主界面
                        Navigator.pushNamedAndRemoveUntil(
                          context,
                          '/main',
                              (route) => false,
                        );
                      },
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.deepPurple,
                        padding: const EdgeInsets.symmetric(vertical: 16),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(25),
                        ),
                      ),
                      child: const Text(
                        'Go Home',
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                  ),

                  const SizedBox(height: 16),

                  // View My Appointments - 跳转到预约页面
                  SizedBox(
                    width: double.infinity,
                    child: OutlinedButton(
                      onPressed: () {
                        Navigator.pushNamedAndRemoveUntil(
                          context,
                          '/main',
                              (route) => false,
                          arguments: {'initialIndex': 1}, // 跳转到Schedule页面
                        );
                      },
                      style: OutlinedButton.styleFrom(
                        side: const BorderSide(color: Colors.deepPurple),
                        padding: const EdgeInsets.symmetric(vertical: 16),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(25),
                        ),
                      ),
                      child: const Text(
                        'View My Appointments',
                        style: TextStyle(
                          color: Colors.deepPurple,
                          fontSize: 16,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildDetailRow(String label, String value) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(
            width: 60,
            child: Text(
              label,
              style: const TextStyle(
                fontSize: 14,
                fontWeight: FontWeight.w500,
                color: Colors.black87,
              ),
            ),
          ),
          Expanded(
            child: Text(
              value,
              style: const TextStyle(
                fontSize: 14,
                color: Colors.black,
              ),
            ),
          ),
        ],
      ),
    );
  }
}