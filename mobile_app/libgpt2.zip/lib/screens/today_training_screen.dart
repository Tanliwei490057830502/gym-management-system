import 'dart:async';
import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';

class TrainingItem {
  final String name;
  final int durationMinutes;
  final Color color;
  final IconData icon;
  final String courseId;
  final String title;
  final String category;
  bool isCompleted;

  TrainingItem({
    required this.name,
    required this.durationMinutes,
    required this.color,
    required this.icon,
    required this.courseId,
    required this.title,
    required this.category,
    this.isCompleted = false,
  });
}

class TodayTrainingScreen extends StatefulWidget {
  final List<TrainingItem> trainingItems;
  final String courseId;
  final String? aiPlanId;
  final String? fullTrainingPlan; // 🔥 新增：完整训练计划参数

  const TodayTrainingScreen({
    super.key,
    required this.trainingItems,
    required this.courseId,
    this.aiPlanId,
    this.fullTrainingPlan, // 🔥 新增：完整训练计划参数
  });

  @override
  State<TodayTrainingScreen> createState() => _TodayTrainingScreenState();
}

class _TodayTrainingScreenState extends State<TodayTrainingScreen> with SingleTickerProviderStateMixin {
  int currentItemIndex = 0;
  Timer? timer;
  int remainingSeconds = 0;
  bool isRunning = false;
  bool isPaused = false;
  late AnimationController _animationController;
  late Animation<double> _progressAnimation;

  final FirebaseAuth _auth = FirebaseAuth.instance;
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  String? _todayTrainingText;

  @override
  void initState() {
    super.initState();

    if (widget.aiPlanId != null) {
      // 🔥 AI计划模式 - 提取当天训练内容
      _extractTodayTrainingText();
    } else {
      // 课程模式 - 使用计时器
      _setupCurrentItem();
      _animationController = AnimationController(vsync: this, duration: const Duration(seconds: 1));
      _progressAnimation = Tween<double>(begin: 0, end: 1).animate(_animationController);
      _startTimer();
    }
  }

  // 🔥 修复：正确提取当天的训练内容
  void _extractTodayTrainingText() {
    if (widget.fullTrainingPlan == null || widget.fullTrainingPlan!.isEmpty) {
      _todayTrainingText = '未找到训练计划内容';
      return;
    }

    final fullPlan = widget.fullTrainingPlan!;
    final todayWeekday = DateTime.now().weekday; // 1=Monday, 7=Sunday

    // 转换为 Day 1-7 的格式
    final dayNumber = todayWeekday;
    final dayPattern = 'Day $dayNumber:';

    try {
      // 查找当天的训练内容
      final dayIndex = fullPlan.indexOf(dayPattern);
      if (dayIndex != -1) {
        // 找到当天的开始位置
        final startIndex = dayIndex + dayPattern.length;

        // 找到下一天的开始位置或文本结尾
        final nextDayPattern = RegExp(r'Day \d+:');
        final remainingText = fullPlan.substring(startIndex);
        final nextDayMatch = nextDayPattern.firstMatch(remainingText);

        String todayContent;
        if (nextDayMatch != null) {
          // 找到下一天，截取到下一天之前
          todayContent = remainingText.substring(0, nextDayMatch.start).trim();
        } else {
          // 没有找到下一天，取到文本结尾
          todayContent = remainingText.trim();
        }

        _todayTrainingText = todayContent.isNotEmpty ? todayContent : '今日无特定训练内容';
      } else {
        // 没有找到当天的训练内容，尝试循环（如果是Day 8就找Day 1）
        final cyclicDayNumber = ((todayWeekday - 1) % 7) + 1;
        final cyclicDayPattern = 'Day $cyclicDayNumber:';
        final cyclicDayIndex = fullPlan.indexOf(cyclicDayPattern);

        if (cyclicDayIndex != -1) {
          final startIndex = cyclicDayIndex + cyclicDayPattern.length;
          final nextDayPattern = RegExp(r'Day \d+:');
          final remainingText = fullPlan.substring(startIndex);
          final nextDayMatch = nextDayPattern.firstMatch(remainingText);

          String todayContent;
          if (nextDayMatch != null) {
            todayContent = remainingText.substring(0, nextDayMatch.start).trim();
          } else {
            todayContent = remainingText.trim();
          }

          _todayTrainingText = todayContent.isNotEmpty ? todayContent : '今日无特定训练内容';
        } else {
          // 完全找不到，显示第一段内容
          final lines = fullPlan.split('\n');
          final nonEmptyLines = lines.where((line) => line.trim().isNotEmpty).toList();

          if (nonEmptyLines.isNotEmpty) {
            // 取前几行作为今日训练内容
            final todayLines = nonEmptyLines.take(10).toList();
            _todayTrainingText = todayLines.join('\n');
          } else {
            _todayTrainingText = '训练计划格式异常，请检查内容';
          }
        }
      }
    } catch (e) {
      print('Error extracting today training text: $e');
      _todayTrainingText = '提取今日训练内容时出错：${e.toString()}';
    }

    print('🗓️ 今日是周$todayWeekday，提取的训练内容：$_todayTrainingText');
  }

  void _setupCurrentItem() {
    if (widget.trainingItems.isNotEmpty) {
      remainingSeconds = widget.trainingItems[currentItemIndex].durationMinutes * 60;
    }
  }

  void _startTimer() {
    setState(() => isRunning = true);
    timer = Timer.periodic(const Duration(seconds: 1), (t) {
      if (!isPaused) {
        setState(() => remainingSeconds--);
        if (remainingSeconds <= 0) _completeCurrentItem();
      }
    });
  }

  void _pauseTimer() => setState(() => isPaused = true);
  void _resumeTimer() => setState(() => isPaused = false);
  void _skipToNext() => _completeCurrentItem();

  void _completeCurrentItem() {
    if (widget.trainingItems.isNotEmpty) {
      widget.trainingItems[currentItemIndex].isCompleted = true;
    }
    timer?.cancel();
    if (currentItemIndex < widget.trainingItems.length - 1) {
      setState(() => currentItemIndex++);
      _setupCurrentItem();
      _startTimer();
    } else {
      _finishTraining();
    }
  }

  void _finishEarly() {
    timer?.cancel();
    _finishTraining();
  }

  Future<void> _finishTraining() async {
    final user = _auth.currentUser;
    if (user == null) return;

    try {
      print('开始处理训练完成，AI计划ID: ${widget.aiPlanId}');

      // 只有非AI计划才更新课程进度
      if (widget.aiPlanId == null) {
        await _updateCourseProgress(user.uid);
      }

      // 创建训练签到记录
      await _createTrainingCheckIn(user.uid);

      if (mounted) {
        // 🔥 新增：先询问体重，再显示完成消息
        await _showWeightInputDialog();
      }
    } catch (e) {
      print('Error updating training progress: $e');
      if (mounted) {
        _showTrainingCompletedMessage();
      }
    }
  }

  // 🔥 新增：显示体重输入对话框
  Future<void> _showWeightInputDialog() async {
    final TextEditingController weightController = TextEditingController();

    final weight = await showDialog<double>(
      context: context,
      barrierDismissible: false,
      builder: (context) => AlertDialog(
        backgroundColor: Colors.white,
        title: const Text(
          '记录体重',
          style: TextStyle(
            fontSize: 18,
            fontWeight: FontWeight.bold,
            color: Colors.black,
          ),
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Text(
              '训练完成！请记录您当前的体重：',
              style: TextStyle(color: Colors.black),
            ),
            const SizedBox(height: 16),
            TextField(
              controller: weightController,
              keyboardType: const TextInputType.numberWithOptions(decimal: true),
              decoration: const InputDecoration(
                labelText: '体重 (kg)',
                labelStyle: TextStyle(color: Colors.black),
                border: OutlineInputBorder(),
                suffixText: 'kg',
                suffixStyle: TextStyle(color: Colors.black),
              ),
              style: const TextStyle(color: Colors.black),
              autofocus: true,
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(null),
            child: const Text(
              '跳过',
              style: TextStyle(color: Colors.grey),
            ),
          ),
          ElevatedButton(
            onPressed: () {
              final weightText = weightController.text.trim();
              if (weightText.isNotEmpty) {
                final weight = double.tryParse(weightText);
                if (weight != null && weight > 0 && weight < 1000) {
                  Navigator.of(context).pop(weight);
                } else {
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(
                      content: Text('请输入有效的体重值'),
                      backgroundColor: Colors.red,
                    ),
                  );
                }
              }
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.green,
              foregroundColor: Colors.white,
            ),
            child: const Text('保存'),
          ),
        ],
      ),
    );

    // 如果用户输入了体重，保存到数据库
    if (weight != null) {
      await _saveWeightRecord(weight);
    }

    // 显示训练完成消息
    if (mounted) {
      _showTrainingCompletedMessage();
    }
  }

  // 🔥 修复：保存体重记录 - 统一使用 weight 字段
  Future<void> _saveWeightRecord(double weight) async {
    final user = _auth.currentUser;
    if (user == null) return;

    try {
      // 保存体重记录
      await _firestore.collection('weight_records').add({
        'userId': user.uid,
        'actualWeight': weight, // 体重记录中使用 actualWeight 字段，与分析界面读取的字段一致
        'recordDate': Timestamp.now(),
        'recordType': 'post_training',
        'aiPlanId': widget.aiPlanId,
        'courseId': widget.courseId,
        'createdAt': Timestamp.now(),
      });

      // 更新用户的当前体重（如果是AI计划）
      if (widget.aiPlanId != null) {
        await _firestore
            .collection('users')
            .doc(user.uid)
            .collection('ai_plans')
            .doc(widget.aiPlanId!)
            .update({
          'currentWeight': weight,
          'lastWeightUpdate': Timestamp.now(),
        });
      }

      // 🔥 修复：更新用户资料的当前体重 - 改为使用 weight 字段与分析界面一致
      await _firestore
          .collection('users')
          .doc(user.uid)
          .update({
        'weight': weight, // ✅ 改为 weight 字段，与分析界面读取的字段一致
        'lastWeightUpdate': Timestamp.now(),
      });

      print('✅ 体重记录已保存: ${weight}kg');

      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('体重记录已保存: ${weight}kg'),
            backgroundColor: Colors.green,
          ),
        );
      }
    } catch (e) {
      print('Error saving weight record: $e');
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('保存体重记录失败'),
            backgroundColor: Colors.red,
          ),
        );
      }
    }
  }

  Future<void> _updateCourseProgress(String userId) async {
    try {
      final query = await _firestore
          .collection('user_courses')
          .where('userId', isEqualTo: userId)
          .where('courseId', isEqualTo: widget.courseId)
          .limit(1)
          .get();

      if (query.docs.isNotEmpty) {
        final doc = query.docs.first.reference;
        final remaining = query.docs.first.data()['remainingSessions'] ?? 8;
        await doc.update({'remainingSessions': remaining > 0 ? remaining - 1 : 0});
        print('Course training completion recorded successfully');
      }
    } catch (e) {
      print('Error updating course progress: $e');
    }
  }

  Future<void> _createTrainingCheckIn(String userId) async {
    try {
      final today = DateTime.now();
      final startOfDay = DateTime(today.year, today.month, today.day);
      final endOfDay = startOfDay.add(const Duration(days: 1));

      // 检查今日是否已签到
      Query checkInQuery = _firestore
          .collection('check_ins')
          .where('userId', isEqualTo: userId)
          .where('checkInDate', isGreaterThanOrEqualTo: Timestamp.fromDate(startOfDay))
          .where('checkInDate', isLessThan: Timestamp.fromDate(endOfDay))
          .where('checkInType', isEqualTo: 'training_completed');

      if (widget.aiPlanId != null) {
        checkInQuery = checkInQuery.where('aiPlanId', isEqualTo: widget.aiPlanId);
        print('检查AI计划今日签到状态');
      } else {
        checkInQuery = checkInQuery.where('courseId', isEqualTo: widget.courseId);
        print('检查课程今日签到状态');
      }

      final existing = await checkInQuery.limit(1).get();

      if (existing.docs.isEmpty) {
        // 创建签到记录
        final checkInData = {
          'userId': userId,
          'checkInDate': Timestamp.now(),
          'checkInType': 'training_completed',
          'createdAt': Timestamp.now(),
        };

        if (widget.aiPlanId != null) {
          // AI计划签到
          checkInData['aiPlanId'] = widget.aiPlanId!;
          checkInData['courseId'] = widget.courseId;
          checkInData['trainingType'] = 'ai_plan';
          checkInData['todayTrainingContent'] = _todayTrainingText ?? '';
          checkInData['totalDuration'] = 30; // AI计划默认30分钟

          // 更新AI计划的最后训练时间
          await _updateAIPlanLastTraining(userId);
        } else {
          // 课程训练签到
          checkInData['courseId'] = widget.courseId;
          checkInData['trainingType'] = 'course';
          checkInData['trainingItems'] = widget.trainingItems.map((item) => {
            'name': item.name,
            'durationMinutes': item.durationMinutes,
            'isCompleted': item.isCompleted,
          }).toList();
          checkInData['totalDuration'] = widget.trainingItems.fold<int>(0, (sum, item) => sum + item.durationMinutes);
        }

        await _firestore.collection('check_ins').add(checkInData);
        print('✅ 签到记录已创建');
      } else {
        print('今日已签到');
      }
    } catch (e) {
      print('Error creating training check-in: $e');
    }
  }

  Future<void> _updateAIPlanLastTraining(String userId) async {
    try {
      await _firestore
          .collection('users')
          .doc(userId)
          .collection('ai_plans')
          .doc(widget.aiPlanId!)
          .update({
        'lastTrainingDate': Timestamp.now(),
        'lastTrainingAt': FieldValue.serverTimestamp(),
      });
      print('✅ AI计划最后训练时间已更新');
    } catch (e) {
      print('Error updating AI plan last training: $e');
    }
  }

  void _showTrainingCompletedMessage() {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => Dialog(
        backgroundColor: Colors.white,
        child: Padding(
          padding: const EdgeInsets.all(20),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Icon(Icons.check_circle, size: 80, color: Colors.green),
              const SizedBox(height: 20),
              Text(
                widget.aiPlanId != null ? '🎉 AI训练完成！' : '🎉 训练完成！',
                style: const TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                  color: Colors.black,
                ),
              ),
              const SizedBox(height: 8),
              Text(
                widget.aiPlanId != null
                    ? 'AI训练计划今日进度已更新'
                    : '课程训练进度已更新',
                textAlign: TextAlign.center,
                style: const TextStyle(color: Colors.black),
              ),
              const SizedBox(height: 16),
              ElevatedButton.icon(
                onPressed: () {
                  Navigator.of(context).pop();
                  Navigator.of(context).pop('completed');
                  Navigator.pushReplacementNamed(
                    context,
                    '/main',
                    arguments: {'initialIndex': 0, 'refresh': true},
                  );
                },
                icon: const Icon(Icons.home),
                label: const Text('返回首页'),
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.green,
                  foregroundColor: Colors.white,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  String _formatTime(int totalSeconds) {
    final minutes = totalSeconds ~/ 60;
    final seconds = totalSeconds % 60;
    return '${minutes.toString().padLeft(2, '0')}:${seconds.toString().padLeft(2, '0')}';
  }

  @override
  void dispose() {
    timer?.cancel();
    if (widget.aiPlanId == null) {
      _animationController.dispose();
    }
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          widget.aiPlanId != null ? 'AI训练进行中' : '训练进行中',
          style: const TextStyle(color: Colors.white),
        ),
        backgroundColor: widget.aiPlanId != null ? Colors.purple : Colors.deepPurple,
        foregroundColor: Colors.white,
        actions: [
          TextButton(
            onPressed: _finishEarly,
            child: const Text('提前结束', style: TextStyle(color: Colors.white)),
          ),
        ],
      ),
      body: SafeArea(
        child: widget.aiPlanId != null
            ? _buildAITrainingTextView()
            : _buildCourseTimerView(),
      ),
    );
  }

  // 🔥 修复：AI训练文本显示界面
  Widget _buildAITrainingTextView() {
    return Padding(
      padding: const EdgeInsets.all(16),
      child: Column(
        children: [
          // 头部信息
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [Colors.purple.shade100, Colors.purple.shade50],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: Colors.purple.shade200),
            ),
            child: Column(
              children: [
                Row(
                  children: [
                    Icon(Icons.auto_awesome, color: Colors.purple.shade600),
                    const SizedBox(width: 8),
                    Text(
                      '📅 今日训练计划',
                      style: TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                        color: Colors.black,
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 8),
                Text(
                  '${DateTime.now().year}年${DateTime.now().month}月${DateTime.now().day}日 - 周${_getWeekdayName(DateTime.now().weekday)}',
                  style: const TextStyle(
                    fontSize: 14,
                    color: Colors.black,
                  ),
                ),
              ],
            ),
          ),

          const SizedBox(height: 16),

          // 训练内容
          Expanded(
            child: SingleChildScrollView(
              child: Container(
                width: double.infinity,
                padding: const EdgeInsets.all(20),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: Colors.grey.shade200),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withOpacity(0.05),
                      blurRadius: 10,
                      offset: const Offset(0, 2),
                    ),
                  ],
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Icon(Icons.fitness_center, color: Colors.orange.shade600, size: 20),
                        const SizedBox(width: 8),
                        Text(
                          '训练内容',
                          style: TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.bold,
                            color: Colors.black,
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 16),
                    Text(
                      _todayTrainingText ?? '正在加载训练内容...',
                      style: const TextStyle(
                        fontSize: 16,
                        height: 1.6,
                        color: Colors.black,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),

          const SizedBox(height: 20),

          // 完成按钮
          SizedBox(
            width: double.infinity,
            child: ElevatedButton.icon(
              onPressed: _finishTraining,
              icon: const Icon(Icons.check_circle),
              label: const Text(
                '完成今日训练',
                style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
              ),
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.green,
                foregroundColor: Colors.white,
                padding: const EdgeInsets.symmetric(vertical: 16),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  // 课程计时器视图
  Widget _buildCourseTimerView() {
    if (widget.trainingItems.isEmpty) {
      return const Center(
        child: Text(
          '没有训练项目',
          style: TextStyle(color: Colors.black),
        ),
      );
    }

    final currentItem = widget.trainingItems[currentItemIndex];
    return Padding(
      padding: const EdgeInsets.all(16),
      child: Column(
        children: [
          const SizedBox(height: 16),

          // 进度条
          LinearProgressIndicator(
            value: (currentItemIndex + 1) / widget.trainingItems.length,
            backgroundColor: Colors.grey.shade200,
            valueColor: AlwaysStoppedAnimation<Color>(Colors.deepPurple),
          ),
          const SizedBox(height: 8),
          Text(
            '${currentItemIndex + 1} / ${widget.trainingItems.length}',
            style: const TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.w500,
              color: Colors.black,
            ),
          ),

          const SizedBox(height: 32),

          // 当前训练项目
          Container(
            padding: const EdgeInsets.all(24),
            decoration: BoxDecoration(
              color: currentItem.color.withOpacity(0.1),
              borderRadius: BorderRadius.circular(20),
              border: Border.all(color: currentItem.color.withOpacity(0.3)),
            ),
            child: Column(
              children: [
                Icon(
                  currentItem.icon,
                  size: 48,
                  color: currentItem.color,
                ),
                const SizedBox(height: 16),
                Text(
                  currentItem.name,
                  style: const TextStyle(
                    fontSize: 22,
                    fontWeight: FontWeight.bold,
                    color: Colors.black,
                  ),
                  textAlign: TextAlign.center,
                ),
                const SizedBox(height: 24),

                // 计时器显示
                Text(
                  _formatTime(remainingSeconds),
                  style: const TextStyle(
                    fontSize: 48,
                    fontWeight: FontWeight.bold,
                    color: Colors.black,
                  ),
                ),
              ],
            ),
          ),

          const SizedBox(height: 48),

          // 控制按钮
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              // 跳过按钮
              ElevatedButton.icon(
                onPressed: _skipToNext,
                icon: const Icon(Icons.skip_next),
                label: const Text('跳过'),
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.orange,
                  foregroundColor: Colors.white,
                  padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
                ),
              ),

              // 播放/暂停按钮
              ElevatedButton.icon(
                onPressed: isRunning
                    ? _pauseTimer
                    : (isPaused ? _resumeTimer : _startTimer),
                icon: Icon(
                  isRunning
                      ? Icons.pause
                      : Icons.play_arrow,
                ),
                label: Text(
                  isRunning
                      ? '暂停'
                      : (isPaused ? '继续' : '开始'),
                ),
                style: ElevatedButton.styleFrom(
                  backgroundColor: isRunning ? Colors.orange : Colors.green,
                  foregroundColor: Colors.white,
                  padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
                ),
              ),

              // 结束按钮
              ElevatedButton.icon(
                onPressed: _finishEarly,
                icon: const Icon(Icons.stop),
                label: const Text('结束'),
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.red,
                  foregroundColor: Colors.white,
                  padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
                ),
              ),
            ],
          ),

          const Spacer(),

          // 训练项目列表
          Container(
            height: 120,
            child: ListView.builder(
              scrollDirection: Axis.horizontal,
              itemCount: widget.trainingItems.length,
              itemBuilder: (context, index) {
                final item = widget.trainingItems[index];
                final isActive = index == currentItemIndex;
                final isCompleted = item.isCompleted;

                return Container(
                  width: 100,
                  margin: const EdgeInsets.symmetric(horizontal: 4),
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    color: isCompleted
                        ? Colors.green.shade50
                        : (isActive ? item.color.withOpacity(0.2) : Colors.grey.shade50),
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(
                      color: isCompleted
                          ? Colors.green
                          : (isActive ? item.color : Colors.grey.shade300),
                      width: isActive ? 2 : 1,
                    ),
                  ),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(
                        isCompleted ? Icons.check_circle : item.icon,
                        color: isCompleted
                            ? Colors.green
                            : (isActive ? item.color : Colors.grey),
                        size: 24,
                      ),
                      const SizedBox(height: 8),
                      Text(
                        item.name,
                        style: TextStyle(
                          fontSize: 10,
                          fontWeight: isActive ? FontWeight.bold : FontWeight.normal,
                          color: isCompleted
                              ? Colors.green
                              : (isActive ? Colors.black : Colors.grey),
                        ),
                        textAlign: TextAlign.center,
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                      ),
                      const SizedBox(height: 4),
                      Text(
                        '${item.durationMinutes}min',
                        style: TextStyle(
                          fontSize: 8,
                          color: Colors.grey.shade600,
                        ),
                      ),
                    ],
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }

  // 获取星期名称的辅助方法
  String _getWeekdayName(int weekday) {
    const weekdays = ['一', '二', '三', '四', '五', '六', '日'];
    return weekdays[weekday - 1];
  }
}