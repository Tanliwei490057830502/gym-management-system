// screens/plan_detail_screen.dart
import 'package:flutter/material.dart';
import 'card_payment_screen.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';


class PlanDetailScreen extends StatelessWidget {
  final String title;
  final String subtitle;
  final String rating;
  final Color color1;
  final Color color2;

  const PlanDetailScreen({
    super.key,
    required this.title,
    required this.subtitle,
    required this.rating,
    required this.color1,
    required this.color2,
  });

  // 根据不同计划返回对应的详细信息
  Map<String, dynamic> _getPlanDetails() {
    switch (title) {
      case 'Muscle Building Plan':
        return {
          'introduction': 'This plan is designed for individuals who want to build lean muscle, increase strength, and improve overall physique. Whether you\'re a beginner or have gym experience, this structured program provides progressive resistance training and nutrition guidance to help you sculpt the body you want.',
          'activities': [
            '4-Day Strength Training',
            'Muscle Isolation Circuits',
            'Protein Meal Plan',
            'Monthly Progress Check'
          ],
          'priceBreakdown': [
            'Coach Supervision (RM 39)',
            'Protein Supplement Guide (RM 20)',
            'Gym Access / Equipment (RM 30)',
            'Progress Evaluation Report (RM 10)'
          ]
        };
      case 'Fat Burning Program':
        return {
          'introduction': 'Ideal for individuals focused on losing body fat, increasing stamina, and boosting metabolism. This plan combines cardio-intensive workouts and balanced meal guidance to help you achieve a fitter, leaner shape.',
          'activities': [
            'HIIT & Cardio Sessions',
            'Fat-Loss Meal Plan',
            'Group Coaching & Motivation',
            'Body Fat Tracking'
          ],
          'priceBreakdown': [
            'Cardio Coaching (RM 35)',
            'Meal Plan Guidance (RM 25)',
            'Gym / HIIT Zone Access (RM 30)',
            'Progress Tracker (RM 9)'
          ]
        };
      case 'Core & Posture Training':
        return {
          'introduction': 'Perfect for improving core strength, correcting posture, and enhancing body stability. This program includes targeted movements and flexibility work to support daily balance and long-term spine health.',
          'activities': [
            'Core Strength Workouts',
            'Posture Correction Exercises',
            'Breathing & Balance Drills',
            'Monthly Check-in Feedback'
          ],
          'priceBreakdown': [
            'Posture Training Guide (RM 29)',
            'Core Stability Sessions (RM 30)',
            'Equipment / Mat Use (RM 25)',
            'Monthly Feedback (RM 15)'
          ]
        };
      default:
        return {
          'introduction': 'Comprehensive fitness program designed to meet your specific goals.',
          'activities': ['Custom Training', 'Nutrition Guidance', 'Progress Tracking'],
          'priceBreakdown': ['Training Sessions', 'Meal Planning', 'Progress Reports']
        };
    }
  }

  @override
  Widget build(BuildContext context) {
    final planDetails = _getPlanDetails();

    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.black),
          onPressed: () => Navigator.pop(context),
        ),
        title: Row(
          children: [
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
              decoration: BoxDecoration(
                border: Border.all(color: Colors.black, width: 2),
                borderRadius: BorderRadius.circular(6),
              ),
              child: const Text(
                'LTC',
                style: TextStyle(
                  color: Colors.black,
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
          ],
        ),
      ),
      body: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const SizedBox(height: 30),

            // 标题部分
            Center(
              child: Container(
                width: double.infinity,
                margin: const EdgeInsets.symmetric(horizontal: 20),
                padding: const EdgeInsets.all(20),
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [color1, color2],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                  borderRadius: BorderRadius.circular(15),
                ),
                child: Text(
                  title,
                  textAlign: TextAlign.center,
                  style: const TextStyle(
                    fontSize: 24,
                    fontWeight: FontWeight.bold,
                    color: Colors.white,
                  ),
                ),
              ),
            ),

            const SizedBox(height: 30),

            // Introduction 部分
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    'Introduction :',
                    style: TextStyle(
                      fontSize: 20,
                      fontWeight: FontWeight.bold,
                      color: Colors.black,
                    ),
                  ),
                  const SizedBox(height: 10),
                  Container(
                    width: double.infinity,
                    padding: const EdgeInsets.all(15),
                    decoration: BoxDecoration(
                      color: Colors.orange[100],
                      borderRadius: BorderRadius.circular(10),
                      border: Border.all(color: Colors.orange[300]!, width: 1),
                    ),
                    child: Text(
                      planDetails['introduction'],
                      style: const TextStyle(
                        fontSize: 14,
                        color: Colors.black87,
                        height: 1.4,
                      ),
                    ),
                  ),
                ],
              ),
            ),

            const SizedBox(height: 30),

            // Program Activities 部分
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    'Program Activities :',
                    style: TextStyle(
                      fontSize: 20,
                      fontWeight: FontWeight.bold,
                      color: Colors.black,
                    ),
                  ),
                  const SizedBox(height: 15),
                  ...planDetails['activities'].map<Widget>((activity) =>
                      Container(
                        width: double.infinity,
                        margin: const EdgeInsets.only(bottom: 8),
                        padding: const EdgeInsets.symmetric(horizontal: 15, vertical: 12),
                        decoration: BoxDecoration(
                          color: Colors.orange[200],
                          borderRadius: BorderRadius.circular(8),
                        ),
                        child: Text(
                          '• $activity',
                          style: const TextStyle(
                            fontSize: 14,
                            fontWeight: FontWeight.w600,
                            color: Colors.black87,
                          ),
                        ),
                      ),
                  ).toList(),
                ],
              ),
            ),

            const SizedBox(height: 30),

            // Price 部分
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    'Price : RM 99/Month',
                    style: TextStyle(
                      fontSize: 20,
                      fontWeight: FontWeight.bold,
                      color: Colors.black,
                    ),
                  ),
                  const SizedBox(height: 15),
                  ...planDetails['priceBreakdown'].map<Widget>((item) =>
                      Container(
                        width: double.infinity,
                        margin: const EdgeInsets.only(bottom: 8),
                        padding: const EdgeInsets.symmetric(horizontal: 15, vertical: 12),
                        decoration: BoxDecoration(
                          color: Colors.orange[200],
                          borderRadius: BorderRadius.circular(8),
                        ),
                        child: Text(
                          '• $item',
                          style: const TextStyle(
                            fontSize: 14,
                            fontWeight: FontWeight.w600,
                            color: Colors.black87,
                          ),
                        ),
                      ),
                  ).toList(),
                ],
              ),
            ),

            const SizedBox(height: 100), // 给底部按钮留空间
          ],
        ),
      ),
      bottomNavigationBar: Container(
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(
          color: Colors.white,
          boxShadow: [
            BoxShadow(
              color: Colors.grey.withOpacity(0.2),
              spreadRadius: 1,
              blurRadius: 5,
              offset: const Offset(0, -2),
            ),
          ],
        ),
        child: SizedBox(
          width: double.infinity,
          child: ElevatedButton(
            onPressed: () => _navigateToPayment(context),
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.deepPurple,
              padding: const EdgeInsets.symmetric(vertical: 16),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(25),
              ),
            ),
            child: const Text(
              'Continue to Payment',
              style: TextStyle(
                color: Colors.white,
                fontSize: 18,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
        ),
      ),
    );
  }

  void _navigateToPayment(BuildContext context) {
    Navigator.push(
      context,
        MaterialPageRoute(
          builder: (context) => CardPaymentScreen(
            title: title,
            planId: title.replaceAll(' ', '_').toLowerCase(), // eg: muscle_building_plan
            price: 99.0,
            category: 'Fitness', // 加上这一行！
          ),


    ),
    );
  }

}