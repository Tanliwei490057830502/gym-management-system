import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

import 'welcome_screen.dart';
import 'package:gym_app_system/screens/main_navigation_screen.dart' as user_nav;
import 'package:gym_app_system/screens/coach_main_navigation_screen.dart' as coach_nav;

class AuthGate extends StatelessWidget {
  const AuthGate({super.key});

  @override
  Widget build(BuildContext context) {
    final user = FirebaseAuth.instance.currentUser;

    if (user == null) {
      return const WelcomeScreen(); // 未登录
    }

    // 同时从两个集合取文档
    final usersRef = FirebaseFirestore.instance.collection('users').doc(user.uid).get();
    final coachesRef = FirebaseFirestore.instance.collection('coaches').doc(user.uid).get();

    return FutureBuilder<List<DocumentSnapshot>>(
      future: Future.wait([usersRef, coachesRef]),
      builder: (context, snapshot) {
        if (snapshot.connectionState != ConnectionState.done) {
          return const Scaffold(
            body: Center(child: CircularProgressIndicator()),
          );
        }

        if (snapshot.hasError) {
          return const Scaffold(
            body: Center(child: Text('发生错误，请稍后重试')),
          );
        }

        final userDoc = snapshot.data![0];
        final coachDoc = snapshot.data![1];

        if (userDoc.exists) {
          return const user_nav.MainNavigationScreen();
        } else if (coachDoc.exists) {
          return const coach_nav.CoachMainNavigationScreen();
        } else {
          return const WelcomeScreen(); // 没有注册信息
        }
      },
    );
  }
}
