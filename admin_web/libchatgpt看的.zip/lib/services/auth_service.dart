// lib/services/auth_service.dart
// 用途：认证服务管理

import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import '../models/auth_result.dart';
import '../models/admin_info.dart';

class AuthService {
  static final FirebaseAuth _auth = FirebaseAuth.instance;
  static final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  // 当前用户
  static User? get currentUser => _auth.currentUser;

  // 认证状态流
  static Stream<User?> get authStateChanges => _auth.authStateChanges();

  // 检查用户是否已登录
  static bool get isLoggedIn => _auth.currentUser != null;

  // 获取当前用户邮箱
  static String get currentUserEmail => _auth.currentUser?.email ?? '';

  // 获取当前用户UID
  static String get currentUserUid => _auth.currentUser?.uid ?? '';

  // 获取当前用户显示名称
  static String get currentUserDisplayName => _auth.currentUser?.displayName ?? '';

  /// 管理员登录
  static Future<AuthResult> signInAdmin({
    required String email,
    required String password,
  }) async {
    try {
      print('🔐 Attempting admin login for: $email');

      // 验证输入
      if (email.isEmpty || password.isEmpty) {
        return AuthResult.error('Please fill in all fields');
      }

      if (!email.contains('@')) {
        return AuthResult.error('Please enter a valid email address');
      }

      // Firebase 登录
      UserCredential userCredential = await _auth.signInWithEmailAndPassword(
        email: email,
        password: password,
      );

      print('✅ Firebase authentication successful');

      // 验证是否为管理员账户
      bool isAdmin = await _checkAdminRole(userCredential.user!.uid);
      if (!isAdmin) {
        await signOut();
        print('❌ Admin role verification failed');
        return AuthResult.error('Access denied. Admin privileges required.');
      }

      // 更新最后登录时间
      await _updateLastLogin(userCredential.user!.uid);

      print('✅ Admin login successful');
      return AuthResult.success('Login successful! Welcome to LTC Gym Admin.');

    } on FirebaseAuthException catch (e) {
      print('❌ Firebase Auth Error: ${e.code} - ${e.message}');
      return AuthResult.error(_getAuthErrorMessage(e.code));
    } catch (e) {
      print('❌ Unexpected error during login: $e');
      return AuthResult.error('An unexpected error occurred. Please try again.');
    }
  }

  /// 注册管理员账户（仅供开发使用）
  static Future<AuthResult> registerAdmin({
    required String email,
    required String password,
    required String name,
  }) async {
    try {
      print('📝 Registering admin account for: $email');

      // 验证输入
      if (email.isEmpty || password.isEmpty || name.isEmpty) {
        return AuthResult.error('Please fill in all fields');
      }

      if (password.length < 6) {
        return AuthResult.error('Password must be at least 6 characters');
      }

      // 创建用户账户
      UserCredential userCredential = await _auth.createUserWithEmailAndPassword(
        email: email,
        password: password,
      );

      // 更新用户显示名称
      await userCredential.user?.updateDisplayName(name);

      // 保存管理员信息到 Firestore
      await _firestore.collection('admins').doc(userCredential.user!.uid).set({
        'uid': userCredential.user!.uid,
        'email': email,
        'name': name,
        'role': 'admin',
        'isActive': true,
        'createdAt': FieldValue.serverTimestamp(),
        'lastLogin': FieldValue.serverTimestamp(),
      });

      print('✅ Admin account created successfully');
      return AuthResult.success('Admin account created successfully!');

    } on FirebaseAuthException catch (e) {
      print('❌ Firebase Auth Error during registration: ${e.code}');
      return AuthResult.error(_getAuthErrorMessage(e.code));
    } catch (e) {
      print('❌ Error creating admin account: $e');
      return AuthResult.error('Failed to create admin account.');
    }
  }

  /// 登出
  static Future<void> signOut() async {
    try {
      print('🚪 Signing out user');
      await _auth.signOut();
      print('✅ User signed out successfully');
    } catch (e) {
      print('❌ Error signing out: $e');
      throw Exception('Failed to sign out');
    }
  }

  /// 重置密码
  static Future<AuthResult> resetPassword(String email) async {
    try {
      print('🔄 Sending password reset email to: $email');

      if (email.isEmpty) {
        return AuthResult.error('Please enter your email address');
      }

      if (!email.contains('@')) {
        return AuthResult.error('Please enter a valid email address');
      }

      await _auth.sendPasswordResetEmail(email: email);

      print('✅ Password reset email sent successfully');
      return AuthResult.success('Password reset email sent. Please check your inbox.');

    } on FirebaseAuthException catch (e) {
      print('❌ Error sending password reset email: ${e.code}');
      return AuthResult.error(_getAuthErrorMessage(e.code));
    } catch (e) {
      print('❌ Unexpected error during password reset: $e');
      return AuthResult.error('Failed to send reset email.');
    }
  }

  /// 更改密码
  static Future<AuthResult> changePassword({
    required String currentPassword,
    required String newPassword,
  }) async {
    try {
      print('🔐 Changing password for current user');

      final user = _auth.currentUser;
      if (user == null) {
        return AuthResult.error('No user logged in');
      }

      if (newPassword.length < 6) {
        return AuthResult.error('New password must be at least 6 characters');
      }

      // 重新认证用户
      final credential = EmailAuthProvider.credential(
        email: user.email!,
        password: currentPassword,
      );

      await user.reauthenticateWithCredential(credential);
      print('✅ User re-authenticated successfully');

      // 更新密码
      await user.updatePassword(newPassword);
      print('✅ Password updated successfully');

      return AuthResult.success('Password updated successfully!');

    } on FirebaseAuthException catch (e) {
      print('❌ Error changing password: ${e.code}');
      return AuthResult.error(_getAuthErrorMessage(e.code));
    } catch (e) {
      print('❌ Unexpected error during password change: $e');
      return AuthResult.error('Failed to update password.');
    }
  }

  /// 获取管理员信息
  static Future<AdminInfo?> getAdminInfo() async {
    try {
      final user = _auth.currentUser;
      if (user == null) return null;

      print('📋 Fetching admin info for: ${user.uid}');

      final doc = await _firestore.collection('admins').doc(user.uid).get();
      if (!doc.exists) {
        print('❌ Admin document not found');
        return null;
      }

      final data = doc.data()!;
      return AdminInfo(
        uid: data['uid'],
        email: data['email'],
        name: data['name'],
        role: data['role'],
        isActive: data['isActive'] ?? true,
        createdAt: (data['createdAt'] as Timestamp?)?.toDate(),
        lastLogin: (data['lastLogin'] as Timestamp?)?.toDate(),
      );
    } catch (e) {
      print('❌ Error fetching admin info: $e');
      return null;
    }
  }

  /// 更新管理员信息
  static Future<AuthResult> updateAdminInfo({
    String? name,
    Map<String, dynamic>? additionalData,
  }) async {
    try {
      final user = _auth.currentUser;
      if (user == null) {
        return AuthResult.error('No user logged in');
      }

      print('📝 Updating admin info for: ${user.uid}');

      Map<String, dynamic> updateData = {};

      if (name != null) {
        updateData['name'] = name;
        // 同时更新 Firebase Auth 中的显示名称
        await user.updateDisplayName(name);
      }

      if (additionalData != null) updateData.addAll(additionalData);

      updateData['updatedAt'] = FieldValue.serverTimestamp();

      await _firestore.collection('admins').doc(user.uid).update(updateData);

      print('✅ Admin info updated successfully');
      return AuthResult.success('Profile updated successfully!');
    } catch (e) {
      print('❌ Error updating admin info: $e');
      return AuthResult.error('Failed to update profile.');
    }
  }

  /// 获取所有管理员列表（仅超级管理员）
  static Future<List<AdminInfo>> getAllAdmins() async {
    try {
      final snapshot = await _firestore
          .collection('admins')
          .orderBy('createdAt', descending: true)
          .get();

      return snapshot.docs.map((doc) {
        final data = doc.data();
        return AdminInfo(
          uid: data['uid'],
          email: data['email'],
          name: data['name'],
          role: data['role'],
          isActive: data['isActive'] ?? true,
          createdAt: (data['createdAt'] as Timestamp?)?.toDate(),
          lastLogin: (data['lastLogin'] as Timestamp?)?.toDate(),
        );
      }).toList();
    } catch (e) {
      print('❌ Error fetching all admins: $e');
      return [];
    }
  }

  /// 私有方法：检查管理员角色
  static Future<bool> _checkAdminRole(String uid) async {
    try {
      final doc = await _firestore.collection('admins').doc(uid).get();
      if (!doc.exists) return false;

      final data = doc.data()!;
      return data['role'] == 'admin' && (data['isActive'] ?? false);
    } catch (e) {
      print('❌ Error checking admin role: $e');
      return false;
    }
  }

  /// 私有方法：更新最后登录时间
  static Future<void> _updateLastLogin(String uid) async {
    try {
      await _firestore.collection('admins').doc(uid).update({
        'lastLogin': FieldValue.serverTimestamp(),
      });
    } catch (e) {
      print('❌ Error updating last login: $e');
      // 忽略错误，不影响登录流程
    }
  }

  /// 私有方法：获取认证错误信息
  static String _getAuthErrorMessage(String code) {
    switch (code) {
      case 'user-not-found':
        return 'No admin account found with this email.';
      case 'wrong-password':
        return 'Incorrect password. Please try again.';
      case 'invalid-email':
        return 'Invalid email address format.';
      case 'user-disabled':
        return 'This admin account has been disabled.';
      case 'too-many-requests':
        return 'Too many failed attempts. Please try again later.';
      case 'weak-password':
        return 'Password is too weak. Please choose a stronger password.';
      case 'email-already-in-use':
        return 'An account with this email already exists.';
      case 'requires-recent-login':
        return 'Please log out and log in again to perform this action.';
      case 'invalid-credential':
        return 'Invalid login credentials. Please check your email and password.';
      case 'network-request-failed':
        return 'Network error. Please check your internet connection.';
      default:
        return 'Authentication failed. Please try again.';
    }
  }

  /// 验证当前用户是否为管理员
  static Future<bool> verifyAdminStatus() async {
    final user = _auth.currentUser;
    if (user == null) return false;

    return await _checkAdminRole(user.uid);
  }

  /// 获取认证统计信息
  static Future<Map<String, dynamic>> getAuthStatistics() async {
    try {
      final adminSnapshot = await _firestore.collection('admins').get();
      final activeAdmins = adminSnapshot.docs.where((doc) {
        final data = doc.data();
        return data['isActive'] ?? false;
      }).length;

      return {
        'totalAdmins': adminSnapshot.docs.length,
        'activeAdmins': activeAdmins,
        'inactiveAdmins': adminSnapshot.docs.length - activeAdmins,
        'currentUser': currentUserEmail,
        'isLoggedIn': isLoggedIn,
      };
    } catch (e) {
      print('❌ Error getting auth statistics: $e');
      return {};
    }
  }
}