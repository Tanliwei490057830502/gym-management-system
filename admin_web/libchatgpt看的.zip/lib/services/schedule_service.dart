// lib/services/schedule_service.dart
// 用途：行程管理服务类

import 'package:cloud_firestore/cloud_firestore.dart';
import '../models/models.dart';

class ScheduleService {
  static final _firestore = FirebaseFirestore.instance;

  /// 获取今日预约列表
  static Stream<List<Appointment>> getTodayAppointments() {
    final today = DateTime.now();
    final startOfDay = DateTime(today.year, today.month, today.day);
    final endOfDay = DateTime(today.year, today.month, today.day, 23, 59, 59);

    return _firestore
        .collection('appointments')
        .where('date', isGreaterThanOrEqualTo: Timestamp.fromDate(startOfDay))
        .where('date', isLessThanOrEqualTo: Timestamp.fromDate(endOfDay))
        .orderBy('date')
        .orderBy('timeSlot')
        .snapshots()
        .map((snapshot) => snapshot.docs
        .map((doc) => Appointment.fromFirestore(doc))
        .toList());
  }

  /// 获取指定月份的预约列表
  static Stream<List<Appointment>> getMonthlyAppointments(int year, int month) {
    final startOfMonth = DateTime(year, month, 1);
    final endOfMonth = DateTime(year, month + 1, 0, 23, 59, 59);

    return _firestore
        .collection('appointments')
        .where('date', isGreaterThanOrEqualTo: Timestamp.fromDate(startOfMonth))
        .where('date', isLessThanOrEqualTo: Timestamp.fromDate(endOfMonth))
        .orderBy('date')
        .snapshots()
        .map((snapshot) => snapshot.docs
        .map((doc) => Appointment.fromFirestore(doc))
        .toList());
  }

  /// 获取当前月份的预约列表
  static Stream<List<Appointment>> getCurrentMonthAppointments() {
    final now = DateTime.now();
    return getMonthlyAppointments(now.year, now.month);
  }

  /// 获取指定日期的预约数量统计
  static Map<String, int> getDayAppointmentStats(List<Appointment> appointments, DateTime date) {
    final dayAppointments = appointments.where((appointment) =>
    appointment.date.year == date.year &&
        appointment.date.month == date.month &&
        appointment.date.day == date.day).toList();

    return {
      'total': dayAppointments.length,
      'pending': dayAppointments.where((a) => a.status == 'pending').length,
      'confirmed': dayAppointments.where((a) => a.status == 'confirmed').length,
      'completed': dayAppointments.where((a) => a.status == 'completed').length,
      'cancelled': dayAppointments.where((a) => a.status == 'cancelled').length,
    };
  }

  /// 获取月度预约统计
  static MonthlyScheduleStats getMonthlyStats(List<Appointment> appointments) {
    final stats = <DateTime, DayScheduleStats>{};

    for (final appointment in appointments) {
      final dateKey = DateTime(appointment.date.year, appointment.date.month, appointment.date.day);

      if (!stats.containsKey(dateKey)) {
        stats[dateKey] = DayScheduleStats(
          date: dateKey,
          total: 0,
          pending: 0,
          confirmed: 0,
          completed: 0,
          cancelled: 0,
        );
      }

      final dayStat = stats[dateKey]!;
      stats[dateKey] = DayScheduleStats(
        date: dateKey,
        total: dayStat.total + 1,
        pending: dayStat.pending + (appointment.status == 'pending' ? 1 : 0),
        confirmed: dayStat.confirmed + (appointment.status == 'confirmed' ? 1 : 0),
        completed: dayStat.completed + (appointment.status == 'completed' ? 1 : 0),
        cancelled: dayStat.cancelled + (appointment.status == 'cancelled' ? 1 : 0),
      );
    }

    return MonthlyScheduleStats(dayStats: stats);
  }

  /// 批量更新预约状态
  static Future<void> batchUpdateAppointmentStatus(
      List<String> appointmentIds,
      String newStatus,
      ) async {
    final batch = _firestore.batch();

    for (final id in appointmentIds) {
      final docRef = _firestore.collection('appointments').doc(id);
      batch.update(docRef, {
        'status': newStatus,
        'updatedAt': FieldValue.serverTimestamp(),
      });
    }

    await batch.commit();
  }

  /// 获取待审批的预约数量
  static Stream<int> getPendingAppointmentsCount() {
    return _firestore
        .collection('appointments')
        .where('status', isEqualTo: 'pending')
        .snapshots()
        .map((snapshot) => snapshot.docs.length);
  }

  /// 获取今日待审批的预约
  static Stream<List<Appointment>> getTodayPendingAppointments() {
    final today = DateTime.now();
    final startOfDay = DateTime(today.year, today.month, today.day);
    final endOfDay = DateTime(today.year, today.month, today.day, 23, 59, 59);

    return _firestore
        .collection('appointments')
        .where('status', isEqualTo: 'pending')
        .where('date', isGreaterThanOrEqualTo: Timestamp.fromDate(startOfDay))
        .where('date', isLessThanOrEqualTo: Timestamp.fromDate(endOfDay))
        .orderBy('date')
        .orderBy('timeSlot')
        .snapshots()
        .map((snapshot) => snapshot.docs
        .map((doc) => Appointment.fromFirestore(doc))
        .toList());
  }
}

/// 每日行程统计
class DayScheduleStats {
  final DateTime date;
  final int total;
  final int pending;
  final int confirmed;
  final int completed;
  final int cancelled;

  DayScheduleStats({
    required this.date,
    required this.total,
    required this.pending,
    required this.confirmed,
    required this.completed,
    required this.cancelled,
  });

  /// 获取主要状态（数量最多的状态）
  String get primaryStatus {
    final statusCounts = {
      'pending': pending,
      'confirmed': confirmed,
      'completed': completed,
      'cancelled': cancelled,
    };

    return statusCounts.entries
        .where((entry) => entry.value > 0)
        .reduce((a, b) => a.value > b.value ? a : b)
        .key;
  }

  /// 检查是否有预约
  bool get hasAppointments => total > 0;

  /// 检查是否有待审批的预约
  bool get hasPendingAppointments => pending > 0;
}

/// 月度行程统计
class MonthlyScheduleStats {
  final Map<DateTime, DayScheduleStats> dayStats;

  MonthlyScheduleStats({required this.dayStats});

  /// 获取指定日期的统计
  DayScheduleStats? getStatsForDate(DateTime date) {
    final dateKey = DateTime(date.year, date.month, date.day);
    return dayStats[dateKey];
  }

  /// 获取月度总统计
  DayScheduleStats get monthlyTotal {
    int total = 0, pending = 0, confirmed = 0, completed = 0, cancelled = 0;

    for (final stats in dayStats.values) {
      total += stats.total;
      pending += stats.pending;
      confirmed += stats.confirmed;
      completed += stats.completed;
      cancelled += stats.cancelled;
    }

    return DayScheduleStats(
      date: DateTime.now(),
      total: total,
      pending: pending,
      confirmed: confirmed,
      completed: completed,
      cancelled: cancelled,
    );
  }

  /// 获取有预约的日期列表
  List<DateTime> get datesWithAppointments => dayStats.keys.toList()..sort();

  /// 获取待审批预约的日期列表
  List<DateTime> get datesWithPendingAppointments =>
      dayStats.entries
          .where((entry) => entry.value.hasPendingAppointments)
          .map((entry) => entry.key)
          .toList()..sort();
}