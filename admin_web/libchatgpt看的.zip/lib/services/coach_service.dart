// lib/services/coach_service.dart
// 用途：支持绑定/解绑请求的教练管理服务

import 'package:cloud_firestore/cloud_firestore.dart';
import '../models/coach.dart';
import '../models/binding_request.dart';
import '../models/course.dart';

class CoachService {
  static final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  /// 获取已批准的教练（仅显示活跃和休息状态的教练）
  static Stream<List<Coach>> getCoachesStream() {
    return _firestore
        .collection('coaches')
        .where('status', whereIn: ['active', 'break']) // 移除 'inactive'
        .snapshots()
        .map((snapshot) {
      return snapshot.docs.map((doc) => Coach.fromFirestore(doc)).toList();
    });
  }

  /// 获取所有教练（包括未激活的）- 新增方法
  static Stream<List<Coach>> getAllCoachesStream() {
    return _firestore
        .collection('coaches')
        .where('status', whereIn: ['active', 'inactive', 'break'])
        .snapshots()
        .map((snapshot) {
      return snapshot.docs.map((doc) => Coach.fromFirestore(doc)).toList();
    });
  }

  /// 获取待审核的绑定/解绑请求
  static Stream<List<BindingRequest>> getBindingRequestsStream() {
    try {
      return _firestore
          .collection('binding_requests')
          .where('status', isEqualTo: 'pending')
          .snapshots()
          .map((snapshot) {
        final requests = snapshot.docs.map((doc) {
          return BindingRequest.fromFirestore(doc);
        }).toList();

        // 在内存中排序，避免 Firestore 复合索引要求
        requests.sort((a, b) {
          if (a.createdAt == null) return 1;
          if (b.createdAt == null) return -1;
          return b.createdAt!.compareTo(a.createdAt!);
        });

        return requests;
      }).handleError((error) {
        print('❌ 获取绑定/解绑请求流失败: $error');
        return <BindingRequest>[];
      });
    } catch (e) {
      print('❌ 创建绑定/解绑请求流失败: $e');
      return Stream.value(<BindingRequest>[]);
    }
  }

  /// 获取特定教练的绑定请求流（用于移动端）
  static Stream<List<BindingRequest>> getCoachBindingRequestsStream(String coachId) {
    return _firestore
        .collection('binding_requests')
        .where('coachId', isEqualTo: coachId)
        .snapshots()
        .map((snapshot) {
      final requests = snapshot.docs.map((doc) => BindingRequest.fromFirestore(doc)).toList();

      // 在内存中排序
      requests.sort((a, b) {
        if (a.createdAt == null) return 1;
        if (b.createdAt == null) return -1;
        return b.createdAt!.compareTo(a.createdAt!);
      });

      return requests;
    });
  }

  /// 获取课程
  static Stream<List<Course>> getCoursesStream() {
    return _firestore.collection('courses').snapshots().map((snapshot) {
      return snapshot.docs.map((doc) => Course.fromFirestore(doc)).toList();
    });
  }

  /// 发送绑定/解绑请求（移动端调用）
  static Future<bool> sendBindingRequest({
    required String coachId,
    required String coachName,
    required String coachEmail,
    required String gymId,
    required String gymName,
    required String message,
    String type = 'bind', // 'bind' 或 'unbind'
  }) async {
    try {
      print('📤 发送${type == 'unbind' ? '解绑' : '绑定'}请求...');
      print('教练: $coachName ($coachEmail)');
      print('健身房: $gymName');
      print('类型: $type');

      // 检查是否已存在相同类型的待处理请求
      final existingRequests = await _firestore
          .collection('binding_requests')
          .where('coachId', isEqualTo: coachId)
          .where('gymId', isEqualTo: gymId)
          .where('type', isEqualTo: type)
          .where('status', isEqualTo: 'pending')
          .get();

      if (existingRequests.docs.isNotEmpty) {
        print('⚠️ 已存在待处理的${type == 'unbind' ? '解绑' : '绑定'}请求');
        return false;
      }

      // 创建新的请求
      final docRef = await _firestore.collection('binding_requests').add({
        'coachId': coachId,
        'coachName': coachName.isNotEmpty ? coachName : 'Unknown Coach',
        'coachEmail': coachEmail,
        'gymId': gymId,
        'gymName': gymName,
        'message': message,
        'type': type, // 添加请求类型
        'status': 'pending',
        'createdAt': FieldValue.serverTimestamp(),
      });

      print('✅ ${type == 'unbind' ? '解绑' : '绑定'}请求发送成功，文档ID: ${docRef.id}');
      return true;
    } catch (e) {
      print('❌ 发送${type == 'unbind' ? '解绑' : '绑定'}请求失败: $e');
      return false;
    }
  }

  /// 处理绑定/解绑请求 - 增强版
  static Future<bool> handleBindingRequest({
    required String requestId,
    required String action, // 'approve' or 'reject'
    String? rejectReason,
  }) async {
    try {
      print('🔄 处理请求: $requestId, 操作: $action');

      final batch = _firestore.batch();

      // 获取请求数据
      final requestRef = _firestore.collection('binding_requests').doc(requestId);
      final requestDoc = await requestRef.get();

      if (!requestDoc.exists) {
        print('❌ 请求不存在: $requestId');
        return false;
      }

      final requestData = requestDoc.data()!;
      final coachId = requestData['coachId'] as String;
      final coachName = requestData['coachName'] as String;
      final coachEmail = requestData['coachEmail'] as String;
      final gymId = requestData['gymId'] as String;
      final gymName = requestData['gymName'] as String;
      final requestType = requestData['type'] as String? ?? 'bind';

      if (action == 'approve') {
        print('✅ 批准${requestType == 'unbind' ? '解绑' : '绑定'}请求');

        // 1. 更新请求状态为approved
        batch.update(requestRef, {
          'status': 'approved',
          'processedAt': FieldValue.serverTimestamp(),
        });

        // 2. 根据请求类型处理教练记录
        final coachRef = _firestore.collection('coaches').doc(coachId);
        final existingCoach = await coachRef.get();

        if (requestType == 'bind') {
          // 绑定处理
          if (existingCoach.exists) {
            // 更新现有教练记录，支持多健身房绑定
            final currentData = existingCoach.data()!;
            List<String> boundGyms = [];

            // 获取当前绑定的健身房列表
            if (currentData['boundGyms'] != null) {
              boundGyms = List<String>.from(currentData['boundGyms']);
            } else if (currentData['assignedGymId'] != null) {
              boundGyms.add(currentData['assignedGymId']);
            }

            // 添加新的健身房
            if (!boundGyms.contains(gymId)) {
              boundGyms.add(gymId);
            }

            batch.update(coachRef, {
              'boundGyms': boundGyms,
              'assignedGymId': gymId, // 保持兼容性
              'assignedGymName': gymName, // 保持兼容性
              'status': 'active',
              'updatedAt': FieldValue.serverTimestamp(),
            });
            print('📝 更新教练记录，添加健身房绑定: $gymName');
          } else {
            // 创建新的教练记录
            batch.set(coachRef, {
              'id': coachId,
              'name': coachName,
              'email': coachEmail,
              'boundGyms': [gymId],
              'assignedGymId': gymId, // 保持兼容性
              'assignedGymName': gymName, // 保持兼容性
              'status': 'active',
              'role': 'coach',
              'joinedAt': FieldValue.serverTimestamp(),
              'updatedAt': FieldValue.serverTimestamp(),
            });
            print('🆕 创建新教练记录');
          }
        } else if (requestType == 'unbind') {
          // 解绑处理
          if (existingCoach.exists) {
            final currentData = existingCoach.data()!;
            List<String> boundGyms = [];

            // 获取当前绑定的健身房列表
            if (currentData['boundGyms'] != null) {
              boundGyms = List<String>.from(currentData['boundGyms']);
            } else if (currentData['assignedGymId'] != null) {
              boundGyms.add(currentData['assignedGymId']);
            }

            // 移除指定的健身房
            boundGyms.remove(gymId);

            if (boundGyms.isEmpty) {
              // 如果没有绑定的健身房了，设为inactive
              batch.update(coachRef, {
                'boundGyms': [],
                'assignedGymId': null,
                'assignedGymName': null,
                'status': 'inactive',
                'updatedAt': FieldValue.serverTimestamp(),
              });
              print('📝 教练已解绑所有健身房，设为inactive');
            } else {
              // 更新绑定列表
              final newPrimaryGym = boundGyms.first;
              batch.update(coachRef, {
                'boundGyms': boundGyms,
                'assignedGymId': newPrimaryGym, // 保持兼容性，设为第一个
                'updatedAt': FieldValue.serverTimestamp(),
              });
              print('📝 更新教练记录，移除健身房绑定: $gymName');
            }
          }
        }

        print('✅ 批准${requestType == 'unbind' ? '解绑' : '绑定'}请求: $coachName');
      } else if (action == 'reject') {
        print('❌ 拒绝${requestType == 'unbind' ? '解绑' : '绑定'}请求');

        // 拒绝请求
        batch.update(requestRef, {
          'status': 'rejected',
          'processedAt': FieldValue.serverTimestamp(),
          if (rejectReason != null && rejectReason.isNotEmpty) 'rejectReason': rejectReason,
        });

        print('❌ 拒绝${requestType == 'unbind' ? '解绑' : '绑定'}请求: $coachName, 原因: ${rejectReason ?? '无'}');
      }

      await batch.commit();
      print('✅ 请求处理完成');
      return true;
    } catch (e) {
      print('❌ 处理请求失败: $e');
      return false;
    }
  }

  /// 更新教练状态
  static Future<bool> updateCoachStatus(String coachId, String status) async {
    try {
      print('📝 更新教练状态: $coachId -> $status');

      await _firestore.collection('coaches').doc(coachId).update({
        'status': status,
        'updatedAt': FieldValue.serverTimestamp(),
      });

      print('✅ 教练状态更新成功');
      return true;
    } catch (e) {
      print('❌ 更新教练状态失败: $e');
      return false;
    }
  }

  /// 移除教练
  static Future<bool> removeCoach(String coachId) async {
    try {
      print('🗑️ 移除教练: $coachId');

      final batch = _firestore.batch();

      // 删除教练记录
      final coachRef = _firestore.collection('coaches').doc(coachId);
      batch.delete(coachRef);

      // 将相关的绑定请求标记为已取消
      final relatedRequests = await _firestore
          .collection('binding_requests')
          .where('coachId', isEqualTo: coachId)
          .where('status', isEqualTo: 'approved')
          .get();

      for (final requestDoc in relatedRequests.docs) {
        batch.update(requestDoc.reference, {
          'status': 'cancelled',
          'cancelledAt': FieldValue.serverTimestamp(),
        });
      }

      await batch.commit();
      print('✅ 教练移除成功');
      return true;
    } catch (e) {
      print('❌ 移除教练失败: $e');
      return false;
    }
  }

  /// 添加课程
  static Future<bool> addCourse({
    required String title,
    required String description,
    required String coachId,
    required String duration,
    required int maxParticipants,
  }) async {
    try {
      print('➕ 添加课程: $title');

      await _firestore.collection('courses').add({
        'title': title,
        'description': description,
        'coachId': coachId,
        'duration': duration,
        'maxParticipants': maxParticipants,
        'status': 'active',
        'createdAt': FieldValue.serverTimestamp(),
        'updatedAt': FieldValue.serverTimestamp(),
      });

      print('✅ 课程添加成功');
      return true;
    } catch (e) {
      print('❌ 添加课程失败: $e');
      return false;
    }
  }

  /// 删除课程
  static Future<bool> deleteCourse(String courseId) async {
    try {
      print('🗑️ 删除课程: $courseId');

      await _firestore.collection('courses').doc(courseId).delete();

      print('✅ 课程删除成功');
      return true;
    } catch (e) {
      print('❌ 删除课程失败: $e');
      return false;
    }
  }

  /// 获取统计信息
  static Future<Map<String, int>> getStatistics() async {
    try {
      final stats = <String, int>{};

      // 统计教练数量
      final coaches = await _firestore.collection('coaches').get();
      stats['total_coaches'] = coaches.docs.length;
      stats['active_coaches'] = coaches.docs.where((doc) {
        final data = doc.data();
        return data['status'] == 'active';
      }).length;
      stats['inactive_coaches'] = coaches.docs.where((doc) {
        final data = doc.data();
        return data['status'] == 'inactive';
      }).length;
      stats['break_coaches'] = coaches.docs.where((doc) {
        final data = doc.data();
        return data['status'] == 'break';
      }).length;

      // 统计请求（包括绑定和解绑）
      final requests = await _firestore.collection('binding_requests').get();
      stats['total_requests'] = requests.docs.length;
      stats['pending_requests'] = requests.docs.where((doc) {
        final data = doc.data();
        return data['status'] == 'pending';
      }).length;
      stats['approved_requests'] = requests.docs.where((doc) {
        final data = doc.data();
        return data['status'] == 'approved';
      }).length;
      stats['rejected_requests'] = requests.docs.where((doc) {
        final data = doc.data();
        return data['status'] == 'rejected';
      }).length;

      // 统计绑定和解绑请求
      stats['bind_requests'] = requests.docs.where((doc) {
        final data = doc.data();
        return (data['type'] ?? 'bind') == 'bind';
      }).length;
      stats['unbind_requests'] = requests.docs.where((doc) {
        final data = doc.data();
        return data['type'] == 'unbind';
      }).length;

      // 统计课程
      final courses = await _firestore.collection('courses').get();
      stats['total_courses'] = courses.docs.length;

      return stats;
    } catch (e) {
      print('❌ 获取统计信息失败: $e');
      return {};
    }
  }
}