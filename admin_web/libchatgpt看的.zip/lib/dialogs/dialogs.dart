// lib/dialogs/dialogs.dart
// 用途：统一导出所有对话框组件

export 'coach_details_dialog.dart';
export 'add_course_dialog.dart';