import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'screens/login_screen.dart';
import 'screens/main_screen.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(
    options: const FirebaseOptions(
        apiKey: "AIzaSyBN48JPJ-NIuBxvc5IfMFZf9evMsYzIKEg",
        authDomain: "gym-app-firebase-79daf.firebaseapp.com",
        projectId: "gym-app-firebase-79daf",
        storageBucket: "gym-app-firebase-79daf.firebasestorage.app",
        messagingSenderId: "780860598498",
        appId: "1:780860598498:web:f955ea17e136375fd416bb",
        measurementId: "G-7H44MZY9CW"
    ),
  );
  runApp(GymAdminApp());
}

class GymAdminApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'LTC Gym Admin',
      theme: ThemeData(
        primarySwatch: Colors.purple,
        visualDensity: VisualDensity.adaptivePlatformDensity,
      ),
      home: AuthWrapper(),
      debugShowCheckedModeBanner: false,
    );
  }
}

class AuthWrapper extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return StreamBuilder<User?>(
      stream: FirebaseAuth.instance.authStateChanges(),
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return const Scaffold(
            body: Center(
              child: CircularProgressIndicator(),
            ),
          );
        }

        if (snapshot.hasData) {
          return MainScreen();
        }

        return LoginScreen();
      },
    );
  }
}