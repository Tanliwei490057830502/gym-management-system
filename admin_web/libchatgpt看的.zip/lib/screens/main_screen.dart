// lib/screens/main_screen.dart
// 用途：主界面布局（集成行程功能）

import 'package:flutter/material.dart';
import '../widgets/sidebar.dart';
import '../services/auth_service.dart';
import '../services/schedule_service.dart';
import '../models/admin_info.dart';
import '../models/models.dart';
import 'home_screen.dart';
import 'today_schedule_screen.dart';
import 'monthly_schedule_screen.dart';
import 'appointment_screen.dart';
import 'coaches_screen.dart';
import 'charts_screen.dart';

class MainScreen extends StatefulWidget {
  const MainScreen({Key? key}) : super(key: key);

  @override
  State<MainScreen> createState() => _MainScreenState();
}

class _MainScreenState extends State<MainScreen> {
  int _selectedIndex = 0;

  // 更新页面列表，包含新的行程页面
  List<Widget> get _pages => [
    HomeScreen(
      onNavigateToPage: (index) {
        setState(() {
          _selectedIndex = index;
        });
      },
    ),
    const TodayScheduleScreen(),          // 新增：今日行程
    const MonthlyScheduleScreen(),        // 新增：月行程
    const AppointmentScreen(),
    const CoachesScreen(),
    const ChartsScreen(),
  ];

  // 更新页面标题
  final List<String> _pageTitles = [
    'Dashboard',
    'Today\'s Schedule',                  // 新增：今日行程标题
    'Monthly Schedule',                   // 新增：月行程标题
    'Appointment Management',
    'Coaches & Courses',
    'Analytics & Reports',
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Row(
        children: [
          // 使用模块化的侧边栏组件
          Sidebar(
            selectedIndex: _selectedIndex,
            onItemSelected: (index) {
              setState(() {
                _selectedIndex = index;
              });
            },
          ),

          // 主内容区域
          Expanded(
            child: Container(
              color: Colors.grey.shade50,
              child: Column(
                children: [
                  _buildTopBar(),
                  Expanded(
                    child: _pages[_selectedIndex],
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildTopBar() {
    return Container(
      height: 70,
      padding: const EdgeInsets.symmetric(horizontal: 30),
      decoration: BoxDecoration(
        color: Colors.white,
        boxShadow: [
          BoxShadow(
            color: Colors.grey.shade200,
            blurRadius: 5,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Row(
        children: [
          // 页面标题
          Text(
            _pageTitles[_selectedIndex],
            style: const TextStyle(
              fontSize: 24,
              fontWeight: FontWeight.w600,
              color: Colors.black87,
            ),
          ),

          const Spacer(),

          // 今日预约快速指示器（仅在非今日行程页面显示）
          if (_selectedIndex != 1) _buildTodayScheduleIndicator(),

          const SizedBox(width: 15),

          // 实时状态指示器
          _buildLiveIndicator(),

          const SizedBox(width: 20),

          // 通知按钮（增强版，显示待审批数量）
          _buildNotificationButton(),

          const SizedBox(width: 15),

          // 用户信息
          _buildUserInfo(),
        ],
      ),
    );
  }

  // 新增：今日预约快速指示器
  Widget _buildTodayScheduleIndicator() {
    return StreamBuilder<List<Appointment>>(
      stream: ScheduleService.getTodayAppointments(),
      builder: (context, snapshot) {
        final todayCount = snapshot.data?.length ?? 0;

        return GestureDetector(
          onTap: () => setState(() => _selectedIndex = 1),
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
            decoration: BoxDecoration(
              color: Colors.blue.shade50,
              borderRadius: BorderRadius.circular(20),
              border: Border.all(color: Colors.blue.shade200),
            ),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Icon(
                  Icons.today,
                  color: Colors.blue.shade600,
                  size: 14,
                ),
                const SizedBox(width: 6),
                Text(
                  'Today: $todayCount',
                  style: TextStyle(
                    color: Colors.blue.shade700,
                    fontWeight: FontWeight.w600,
                    fontSize: 12,
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  Widget _buildLiveIndicator() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 15, vertical: 8),
      decoration: BoxDecoration(
        color: Colors.green.shade50,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: Colors.green.shade200),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            width: 8,
            height: 8,
            decoration: BoxDecoration(
              color: Colors.green.shade500,
              shape: BoxShape.circle,
            ),
          ),
          const SizedBox(width: 8),
          Text(
            'Live',
            style: TextStyle(
              color: Colors.green.shade700,
              fontWeight: FontWeight.w600,
              fontSize: 12,
            ),
          ),
        ],
      ),
    );
  }

  // 增强版通知按钮，显示待审批数量
  Widget _buildNotificationButton() {
    return StreamBuilder<int>(
      stream: ScheduleService.getPendingAppointmentsCount(),
      builder: (context, snapshot) {
        final pendingCount = snapshot.data ?? 0;

        return Stack(
          children: [
            IconButton(
              onPressed: () => _showNotifications(context),
              icon: Icon(
                Icons.notifications_outlined,
                color: Colors.grey.shade600,
                size: 24,
              ),
              tooltip: 'Notifications${pendingCount > 0 ? ' ($pendingCount pending)' : ''}',
            ),
            if (pendingCount > 0)
              Positioned(
                right: 6,
                top: 6,
                child: Container(
                  padding: const EdgeInsets.all(2),
                  decoration: BoxDecoration(
                    color: Colors.red.shade500,
                    borderRadius: BorderRadius.circular(10),
                  ),
                  constraints: const BoxConstraints(
                    minWidth: 16,
                    minHeight: 16,
                  ),
                  child: Text(
                    pendingCount > 99 ? '99+' : pendingCount.toString(),
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 10,
                      fontWeight: FontWeight.bold,
                    ),
                    textAlign: TextAlign.center,
                  ),
                ),
              ),
          ],
        );
      },
    );
  }

  Widget _buildUserInfo() {
    return FutureBuilder<AdminInfo?>(
      future: AuthService.getAdminInfo(),
      builder: (context, snapshot) {
        final adminInfo = snapshot.data;

        return Container(
          padding: const EdgeInsets.symmetric(horizontal: 15, vertical: 8),
          decoration: BoxDecoration(
            color: Colors.purple.shade50,
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: Colors.purple.shade200),
          ),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              CircleAvatar(
                radius: 16,
                backgroundColor: Colors.purple.shade600,
                child: Text(
                  (adminInfo?.name.isNotEmpty == true)
                      ? adminInfo!.name[0].toUpperCase()
                      : 'A',
                  style: const TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.bold,
                    fontSize: 14,
                  ),
                ),
              ),
              const SizedBox(width: 10),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(
                    adminInfo?.name ?? 'Admin',
                    style: TextStyle(
                      color: Colors.purple.shade700,
                      fontWeight: FontWeight.w600,
                      fontSize: 12,
                    ),
                  ),
                  Text(
                    adminInfo?.roleDisplayText ?? 'Administrator',
                    style: TextStyle(
                      color: Colors.purple.shade500,
                      fontSize: 10,
                    ),
                  ),
                ],
              ),
            ],
          ),
        );
      },
    );
  }

  // 增强版通知对话框，包含行程相关通知
  void _showNotifications(BuildContext context) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(15),
        ),
        title: Row(
          children: [
            Icon(
              Icons.notifications,
              color: Colors.purple.shade600,
            ),
            const SizedBox(width: 10),
            const Text('Notifications'),
          ],
        ),
        content: SizedBox(
          width: 350,
          height: 300,
          child: Column(
            children: [
              // 待审批预约通知
              StreamBuilder<int>(
                stream: ScheduleService.getPendingAppointmentsCount(),
                builder: (context, snapshot) {
                  final pendingCount = snapshot.data ?? 0;
                  if (pendingCount == 0) return const SizedBox.shrink();

                  return Column(
                    children: [
                      _buildNotificationItem(
                        'Pending Approvals',
                        '$pendingCount appointment${pendingCount > 1 ? 's' : ''} need your approval',
                        'Now',
                        Icons.pending_actions,
                        Colors.orange,
                        onTap: () {
                          Navigator.of(context).pop();
                          setState(() => _selectedIndex = 1); // 跳转到今日行程
                        },
                      ),
                      const Divider(),
                    ],
                  );
                },
              ),

              // 今日预约概览通知
              StreamBuilder<List<Appointment>>(
                stream: ScheduleService.getTodayAppointments(),
                builder: (context, snapshot) {
                  final todayCount = snapshot.data?.length ?? 0;
                  if (todayCount == 0) return const SizedBox.shrink();

                  return Column(
                    children: [
                      _buildNotificationItem(
                        'Today\'s Schedule',
                        '$todayCount appointment${todayCount > 1 ? 's' : ''} scheduled for today',
                        'Today',
                        Icons.today,
                        Colors.blue,
                        onTap: () {
                          Navigator.of(context).pop();
                          setState(() => _selectedIndex = 1); // 跳转到今日行程
                        },
                      ),
                      const Divider(),
                    ],
                  );
                },
              ),

              // 其他通知
              _buildNotificationItem(
                'New Member Registration',
                'John Doe has joined the gym',
                '2 minutes ago',
                Icons.person_add,
                Colors.green,
              ),
              const Divider(),
              _buildNotificationItem(
                'Payment Received',
                'Monthly fee from Sarah Johnson',
                '15 minutes ago',
                Icons.payment,
                Colors.blue,
              ),
              const Divider(),
              _buildNotificationItem(
                'Appointment Cancelled',
                'Mike cancelled his 3 PM session',
                '1 hour ago',
                Icons.cancel,
                Colors.orange,
              ),
            ],
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(),
            child: const Text('Close'),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.of(context).pop();
              // 导航到通知页面或今日行程
              setState(() => _selectedIndex = 1);
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.purple.shade600,
            ),
            child: const Text(
              'View Schedule',
              style: TextStyle(color: Colors.white),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildNotificationItem(
      String title,
      String subtitle,
      String time,
      IconData icon,
      Color color, {
        VoidCallback? onTap,
      }) {
    Widget content = Padding(
      padding: const EdgeInsets.symmetric(vertical: 5),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              color: color.withOpacity(0.1),
              borderRadius: BorderRadius.circular(8),
            ),
            child: Icon(
              icon,
              color: color,
              size: 16,
            ),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: const TextStyle(
                    fontSize: 12,
                    fontWeight: FontWeight.w600,
                  ),
                ),
                Text(
                  subtitle,
                  style: TextStyle(
                    fontSize: 10,
                    color: Colors.grey.shade600,
                  ),
                ),
              ],
            ),
          ),
          Text(
            time,
            style: TextStyle(
              fontSize: 9,
              color: Colors.grey.shade500,
            ),
          ),
        ],
      ),
    );

    if (onTap != null) {
      return GestureDetector(
        onTap: onTap,
        child: Container(
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(8),
            color: Colors.transparent,
          ),
          child: content,
        ),
      );
    }

    return content;
  }
}

// 扩展：为侧边栏添加新的导航项（如果需要更新Sidebar组件）
// 这个可以作为Sidebar组件更新的参考
class NavigationItem {
  final IconData icon;
  final String label;
  final int index;
  final bool hasNotification;

  const NavigationItem({
    required this.icon,
    required this.label,
    required this.index,
    this.hasNotification = false,
  });
}

// 建议的侧边栏导航项配置
const List<NavigationItem> navigationItems = [
  NavigationItem(
    icon: Icons.dashboard,
    label: 'Dashboard',
    index: 0,
  ),
  NavigationItem(
    icon: Icons.today,
    label: 'Today\'s Schedule',
    index: 1,
  ),
  NavigationItem(
    icon: Icons.calendar_month,
    label: 'Monthly Schedule',
    index: 2,
  ),
  NavigationItem(
    icon: Icons.calendar_today,
    label: 'Appointments',
    index: 3,
  ),
  NavigationItem(
    icon: Icons.fitness_center,
    label: 'Coaches & Courses',
    index: 4,
  ),
  NavigationItem(
    icon: Icons.bar_chart,
    label: 'Analytics & Reports',
    index: 5,
  ),
];