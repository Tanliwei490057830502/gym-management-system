// lib/screens/gym_settings_screen.dart
// 用途：健身房设置界面

import 'package:flutter/material.dart';
import '../services/gym_service.dart';
import '../models/gym_info.dart';
import '../utils/snackbar_utils.dart';

class GymSettingsScreen extends StatefulWidget {
  const GymSettingsScreen({Key? key}) : super(key: key);

  @override
  State<GymSettingsScreen> createState() => _GymSettingsScreenState();
}

class _GymSettingsScreenState extends State<GymSettingsScreen> with TickerProviderStateMixin {
  final _formKey = GlobalKey<FormState>();
  late TabController _tabController;

  // 表单控制器
  final TextEditingController _nameController = TextEditingController();
  final TextEditingController _descriptionController = TextEditingController();
  final TextEditingController _phoneController = TextEditingController();
  final TextEditingController _emailController = TextEditingController();
  final TextEditingController _addressController = TextEditingController();
  final TextEditingController _websiteController = TextEditingController();

  // 营业时间控制器
  final Map<String, TextEditingController> _hoursControllers = {};

  // 设施和社交媒体
  List<String> _amenities = [];
  List<String> _socialMedia = [];

  bool _isLoading = false;
  bool _isSaving = false;
  GymInfo? _currentGymInfo;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 4, vsync: this);
    _initializeControllers();
    _loadGymInfo();
  }

  void _initializeControllers() {
    final days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];
    for (String day in days) {
      _hoursControllers[day] = TextEditingController();
    }
  }

  Future<void> _loadGymInfo() async {
    setState(() => _isLoading = true);

    try {
      // 检查用户是否已认证
      if (!GymService.isUserAuthenticated()) {
        SnackbarUtils.showError(context, 'Please log in to access gym settings');
        if (mounted) {
          Navigator.of(context).pop();
        }
        return;
      }

      final gymInfo = await GymService.getGymInfo();
      if (gymInfo != null && mounted) {
        _populateForm(gymInfo);
      }
    } catch (e) {
      if (mounted) {
        SnackbarUtils.showError(context, 'Error loading gym information: $e');
      }
    } finally {
      if (mounted) {
        setState(() => _isLoading = false);
      }
    }
  }

  void _populateForm(GymInfo gymInfo) {
    if (!mounted) return;

    setState(() {
      _currentGymInfo = gymInfo;
      _nameController.text = gymInfo.name;
      _descriptionController.text = gymInfo.description;
      _phoneController.text = gymInfo.phone;
      _emailController.text = gymInfo.email;
      _addressController.text = gymInfo.address;
      _websiteController.text = gymInfo.website;

      // 营业时间
      _hoursControllers.forEach((day, controller) {
        controller.text = gymInfo.operatingHours[day] ?? '';
      });

      _amenities = List.from(gymInfo.amenities);
      _socialMedia = List.from(gymInfo.socialMedia);
    });
  }

  @override
  void dispose() {
    _tabController.dispose();
    _nameController.dispose();
    _descriptionController.dispose();
    _phoneController.dispose();
    _emailController.dispose();
    _addressController.dispose();
    _websiteController.dispose();

    _hoursControllers.values.forEach((controller) => controller.dispose());
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (_isLoading) {
      return const Scaffold(
        body: Center(
          child: CircularProgressIndicator(),
        ),
      );
    }

    return Scaffold(
      body: Column(
        children: [
          _buildHeader(),
          _buildTabBar(),
          Expanded(
            child: TabBarView(
              controller: _tabController,
              children: [
                _buildBasicInfoTab(),
                _buildOperatingHoursTab(),
                _buildAmenitiesTab(),
                _buildPreviewTab(),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildHeader() {
    return Container(
      padding: const EdgeInsets.all(30),
      decoration: BoxDecoration(
        color: Colors.white,
        boxShadow: [
          BoxShadow(
            color: Colors.grey.shade200,
            blurRadius: 5,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Row(
        children: [
          IconButton(
            onPressed: () => Navigator.of(context).pop(),
            icon: const Icon(Icons.arrow_back, size: 24),
            color: Colors.grey.shade600,
          ),
          const SizedBox(width: 10),
          Icon(
            Icons.settings,
            color: Colors.purple.shade600,
            size: 28,
          ),
          const SizedBox(width: 15),
          const Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'Gym Settings',
                style: TextStyle(
                  fontSize: 24,
                  fontWeight: FontWeight.bold,
                  color: Colors.black87,
                ),
              ),
              Text(
                'Configure your fitness center information',
                style: TextStyle(
                  fontSize: 14,
                  color: Colors.grey,
                ),
              ),
            ],
          ),
          const Spacer(),
          Row(
            children: [
              OutlinedButton.icon(
                onPressed: _resetForm,
                icon: const Icon(Icons.refresh),
                label: const Text('Reset'),
              ),
              const SizedBox(width: 12),
              ElevatedButton.icon(
                onPressed: _isSaving ? null : _saveGymInfo,
                icon: _isSaving
                    ? const SizedBox(
                  width: 16,
                  height: 16,
                  child: CircularProgressIndicator(strokeWidth: 2),
                )
                    : const Icon(Icons.save),
                label: Text(_isSaving ? 'Saving...' : 'Save Changes'),
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.purple.shade600,
                  foregroundColor: Colors.white,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildTabBar() {
    return Container(
      color: Colors.white,
      child: TabBar(
        controller: _tabController,
        labelColor: Colors.purple.shade600,
        unselectedLabelColor: Colors.grey.shade600,
        indicatorColor: Colors.purple.shade600,
        tabs: const [
          Tab(text: 'Basic Info', icon: Icon(Icons.info_outline)),
          Tab(text: 'Operating Hours', icon: Icon(Icons.access_time)),
          Tab(text: 'Amenities', icon: Icon(Icons.fitness_center)),
          Tab(text: 'Preview', icon: Icon(Icons.preview)),
        ],
      ),
    );
  }

  Widget _buildBasicInfoTab() {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(30),
      child: Form(
        key: _formKey,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Expanded(
                  flex: 2,
                  child: Column(
                    children: [
                      _buildFormField(
                        'Gym Name',
                        _nameController,
                        Icons.business,
                        'Enter your gym name',
                        validator: (value) {
                          if (value == null || value.trim().isEmpty) {
                            return 'Please enter gym name';
                          }
                          return null;
                        },
                      ),
                      const SizedBox(height: 20),
                      _buildFormField(
                        'Description',
                        _descriptionController,
                        Icons.description,
                        'Describe your fitness center...',
                        maxLines: 4,
                      ),
                      const SizedBox(height: 20),
                      Row(
                        children: [
                          Expanded(
                            child: _buildFormField(
                              'Phone Number',
                              _phoneController,
                              Icons.phone,
                              '+60 XX-XXX XXXX',
                              validator: (value) {
                                if (value == null || value.trim().isEmpty) {
                                  return 'Please enter phone number';
                                }
                                return null;
                              },
                            ),
                          ),
                          const SizedBox(width: 20),
                          Expanded(
                            child: _buildFormField(
                              'Email Address',
                              _emailController,
                              Icons.email,
                              'contact@yourgym.com',
                              validator: (value) {
                                if (value == null || value.trim().isEmpty) {
                                  return 'Please enter email address';
                                }
                                if (!RegExp(r'^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$').hasMatch(value)) {
                                  return 'Please enter valid email';
                                }
                                return null;
                              },
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
                const SizedBox(width: 30),
                Expanded(
                  flex: 1,
                  child: Column(
                    children: [
                      _buildFormField(
                        'Address',
                        _addressController,
                        Icons.location_on,
                        'Enter complete address...',
                        maxLines: 6,
                      ),
                      const SizedBox(height: 20),
                      _buildFormField(
                        'Website (Optional)',
                        _websiteController,
                        Icons.language,
                        'www.yourgym.com',
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildOperatingHoursTab() {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(30),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              const Text(
                'Operating Hours',
                style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                ),
              ),
              const Spacer(),
              ElevatedButton.icon(
                onPressed: _setAllDaysSame,
                icon: const Icon(Icons.copy_all, size: 18),
                label: const Text('Copy to All Days'),
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.blue.shade600,
                  foregroundColor: Colors.white,
                ),
              ),
            ],
          ),
          const SizedBox(height: 20),
          Container(
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(12),
              boxShadow: [
                BoxShadow(
                  color: Colors.grey.shade200,
                  blurRadius: 8,
                  offset: const Offset(0, 2),
                ),
              ],
            ),
            child: Column(
              children: _hoursControllers.entries.map((entry) {
                return Padding(
                  padding: const EdgeInsets.symmetric(vertical: 8),
                  child: Row(
                    children: [
                      SizedBox(
                        width: 100,
                        child: Text(
                          entry.key,
                          style: const TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                      ),
                      const SizedBox(width: 20),
                      Expanded(
                        child: TextFormField(
                          controller: entry.value,
                          decoration: InputDecoration(
                            hintText: '7:00 AM - 11:00 PM',
                            border: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(8),
                            ),
                            contentPadding: const EdgeInsets.symmetric(
                              horizontal: 12,
                              vertical: 8,
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                );
              }).toList(),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildAmenitiesTab() {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(30),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // 设施管理
          Row(
            children: [
              const Text(
                'Gym Amenities',
                style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                ),
              ),
              const Spacer(),
              ElevatedButton.icon(
                onPressed: _addAmenity,
                icon: const Icon(Icons.add, size: 18),
                label: const Text('Add Amenity'),
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.green.shade600,
                  foregroundColor: Colors.white,
                ),
              ),
            ],
          ),
          const SizedBox(height: 20),

          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(12),
              boxShadow: [
                BoxShadow(
                  color: Colors.grey.shade200,
                  blurRadius: 8,
                  offset: const Offset(0, 2),
                ),
              ],
            ),
            child: _amenities.isEmpty
                ? const Center(
              child: Padding(
                padding: EdgeInsets.all(20),
                child: Text(
                  'No amenities added yet.\nClick "Add Amenity" to get started.',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    color: Colors.grey,
                    fontSize: 16,
                  ),
                ),
              ),
            )
                : Wrap(
              spacing: 8,
              runSpacing: 8,
              children: _amenities.map((amenity) {
                return Chip(
                  label: Text(amenity),
                  deleteIcon: const Icon(Icons.close, size: 18),
                  onDeleted: () => _removeAmenity(amenity),
                  backgroundColor: Colors.purple.shade50,
                  deleteIconColor: Colors.purple.shade600,
                );
              }).toList(),
            ),
          ),

          const SizedBox(height: 40),

          // 社交媒体管理
          Row(
            children: [
              const Text(
                'Social Media Links',
                style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                ),
              ),
              const Spacer(),
              ElevatedButton.icon(
                onPressed: _addSocialMedia,
                icon: const Icon(Icons.add, size: 18),
                label: const Text('Add Link'),
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.blue.shade600,
                  foregroundColor: Colors.white,
                ),
              ),
            ],
          ),
          const SizedBox(height: 20),

          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(12),
              boxShadow: [
                BoxShadow(
                  color: Colors.grey.shade200,
                  blurRadius: 8,
                  offset: const Offset(0, 2),
                ),
              ],
            ),
            child: _socialMedia.isEmpty
                ? const Center(
              child: Padding(
                padding: EdgeInsets.all(20),
                child: Text(
                  'No social media links added yet.\nClick "Add Link" to get started.',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    color: Colors.grey,
                    fontSize: 16,
                  ),
                ),
              ),
            )
                : Column(
              children: _socialMedia.map((link) {
                return Padding(
                  padding: const EdgeInsets.symmetric(vertical: 4),
                  child: Row(
                    children: [
                      Icon(
                        _getSocialMediaIcon(link),
                        color: Colors.blue.shade600,
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Text(
                          link,
                          style: const TextStyle(fontSize: 14),
                        ),
                      ),
                      IconButton(
                        onPressed: () => _removeSocialMedia(link),
                        icon: const Icon(Icons.delete, color: Colors.red),
                        iconSize: 20,
                      ),
                    ],
                  ),
                );
              }).toList(),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildPreviewTab() {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(30),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'Preview',
            style: TextStyle(
              fontSize: 20,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 20),

          // 预览卡片
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(30),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(16),
              boxShadow: [
                BoxShadow(
                  color: Colors.grey.shade200,
                  blurRadius: 10,
                  offset: const Offset(0, 4),
                ),
              ],
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // 标题区域
                Row(
                  children: [
                    Container(
                      padding: const EdgeInsets.all(16),
                      decoration: BoxDecoration(
                        color: Colors.purple.shade100,
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: Icon(
                        Icons.fitness_center,
                        color: Colors.purple.shade600,
                        size: 32,
                      ),
                    ),
                    const SizedBox(width: 20),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            _nameController.text.isNotEmpty
                                ? _nameController.text
                                : 'Your Gym Name',
                            style: const TextStyle(
                              fontSize: 24,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          const SizedBox(height: 4),
                          Text(
                            _descriptionController.text.isNotEmpty
                                ? _descriptionController.text
                                : 'Your gym description...',
                            style: TextStyle(
                              fontSize: 14,
                              color: Colors.grey.shade600,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),

                const SizedBox(height: 30),

                // 联系信息
                Row(
                  children: [
                    Expanded(
                      child: _buildPreviewInfo(
                        Icons.phone,
                        'Phone',
                        _phoneController.text.isNotEmpty ? _phoneController.text : 'Not set',
                        Colors.green,
                      ),
                    ),
                    const SizedBox(width: 20),
                    Expanded(
                      child: _buildPreviewInfo(
                        Icons.email,
                        'Email',
                        _emailController.text.isNotEmpty ? _emailController.text : 'Not set',
                        Colors.blue,
                      ),
                    ),
                  ],
                ),

                const SizedBox(height: 20),

                _buildPreviewInfo(
                  Icons.location_on,
                  'Address',
                  _addressController.text.isNotEmpty ? _addressController.text : 'Not set',
                  Colors.red,
                ),

                if (_websiteController.text.isNotEmpty) ...[
                  const SizedBox(height: 20),
                  _buildPreviewInfo(
                    Icons.language,
                    'Website',
                    _websiteController.text,
                    Colors.orange,
                  ),
                ],

                // 设施
                if (_amenities.isNotEmpty) ...[
                  const SizedBox(height: 30),
                  Row(
                    children: [
                      Icon(
                        Icons.fitness_center,
                        color: Colors.purple.shade600,
                        size: 18,
                      ),
                      const SizedBox(width: 8),
                      const Text(
                        'Amenities',
                        style: TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 10),
                  Wrap(
                    spacing: 8,
                    runSpacing: 8,
                    children: _amenities.map((amenity) {
                      return Chip(
                        label: Text(amenity),
                        backgroundColor: Colors.purple.shade50,
                      );
                    }).toList(),
                  ),
                ],

                // 营业时间预览
                if (_hoursControllers.values.any((controller) => controller.text.isNotEmpty)) ...[
                  const SizedBox(height: 30),
                  Row(
                    children: [
                      Icon(
                        Icons.access_time,
                        color: Colors.blue.shade600,
                        size: 18,
                      ),
                      const SizedBox(width: 8),
                      const Text(
                        'Operating Hours',
                        style: TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 10),
                  Container(
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      color: Colors.blue.shade50,
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: Column(
                      children: _hoursControllers.entries
                          .where((entry) => entry.value.text.isNotEmpty)
                          .map((entry) {
                        return Padding(
                          padding: const EdgeInsets.symmetric(vertical: 2),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Text(
                                entry.key,
                                style: const TextStyle(fontWeight: FontWeight.w500),
                              ),
                              Text(entry.value.text),
                            ],
                          ),
                        );
                      }).toList(),
                    ),
                  ),
                ],
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildFormField(
      String label,
      TextEditingController controller,
      IconData icon,
      String hint, {
        int maxLines = 1,
        String? Function(String?)? validator,
      }) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          label,
          style: const TextStyle(
            fontSize: 16,
            fontWeight: FontWeight.w500,
          ),
        ),
        const SizedBox(height: 8),
        TextFormField(
          controller: controller,
          maxLines: maxLines,
          validator: validator,
          decoration: InputDecoration(
            hintText: hint,
            prefixIcon: Icon(icon, color: Colors.purple.shade600),
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(12),
            ),
            focusedBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(12),
              borderSide: BorderSide(color: Colors.purple.shade600, width: 2),
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildPreviewInfo(IconData icon, String label, String value, Color color) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: color.withOpacity(0.05),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: color.withOpacity(0.2)),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              color: color.withOpacity(0.1),
              borderRadius: BorderRadius.circular(8),
            ),
            child: Icon(icon, color: color, size: 20),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  label,
                  style: TextStyle(
                    fontSize: 14,
                    fontWeight: FontWeight.w600,
                    color: Colors.grey.shade600,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  value,
                  style: const TextStyle(
                    fontSize: 16,
                    color: Colors.black87,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  IconData _getSocialMediaIcon(String url) {
    final lowercaseUrl = url.toLowerCase();
    if (lowercaseUrl.contains('facebook')) return Icons.facebook;
    if (lowercaseUrl.contains('instagram')) return Icons.camera_alt;
    if (lowercaseUrl.contains('twitter') || lowercaseUrl.contains('x.com')) return Icons.alternate_email;
    if (lowercaseUrl.contains('youtube')) return Icons.play_circle_outline;
    if (lowercaseUrl.contains('linkedin')) return Icons.work;
    if (lowercaseUrl.contains('tiktok')) return Icons.music_video;
    return Icons.link;
  }

  void _setAllDaysSame() {
    final mondayController = _hoursControllers['Monday'];
    if (mondayController != null && mondayController.text.isNotEmpty) {
      final mondayHours = mondayController.text;
      _hoursControllers.forEach((day, controller) {
        if (day != 'Monday') {
          controller.text = mondayHours;
        }
      });
      if (mounted) {
        setState(() {});
      }
      SnackbarUtils.showSuccess(context, 'Copied Monday hours to all days');
    } else {
      SnackbarUtils.showError(context, 'Please set Monday hours first');
    }
  }

  void _addAmenity() {
    showDialog(
      context: context,
      builder: (context) {
        final controller = TextEditingController();
        return AlertDialog(
          title: const Text('Add Amenity'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(
                controller: controller,
                decoration: const InputDecoration(
                  hintText: 'Enter amenity name',
                  border: OutlineInputBorder(),
                ),
                autofocus: true,
              ),
              const SizedBox(height: 16),
              const Text(
                'Examples: Free WiFi, Parking, Locker Room, Personal Training, etc.',
                style: TextStyle(
                  fontSize: 12,
                  color: Colors.grey,
                ),
              ),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(context).pop(),
              child: const Text('Cancel'),
            ),
            ElevatedButton(
              onPressed: () {
                final text = controller.text.trim();
                if (text.isNotEmpty && mounted) {
                  setState(() {
                    _amenities.add(text);
                  });
                  Navigator.of(context).pop();
                }
              },
              child: const Text('Add'),
            ),
          ],
        );
      },
    );
  }

  void _removeAmenity(String amenity) {
    setState(() {
      _amenities.remove(amenity);
    });
  }

  void _addSocialMedia() {
    showDialog(
      context: context,
      builder: (context) {
        final controller = TextEditingController();
        return AlertDialog(
          title: const Text('Add Social Media Link'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(
                controller: controller,
                decoration: const InputDecoration(
                  hintText: 'Enter URL (https://...)',
                  border: OutlineInputBorder(),
                ),
                autofocus: true,
              ),
              const SizedBox(height: 16),
              const Text(
                'Examples: Facebook, Instagram, Twitter, YouTube, etc.',
                style: TextStyle(
                  fontSize: 12,
                  color: Colors.grey,
                ),
              ),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(context).pop(),
              child: const Text('Cancel'),
            ),
            ElevatedButton(
              onPressed: () {
                final text = controller.text.trim();
                if (text.isNotEmpty && mounted) {
                  setState(() {
                    _socialMedia.add(text);
                  });
                  Navigator.of(context).pop();
                }
              },
              child: const Text('Add'),
            ),
          ],
        );
      },
    );
  }

  void _removeSocialMedia(String link) {
    setState(() {
      _socialMedia.remove(link);
    });
  }

  void _resetForm() {
    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: const Text('Reset Form'),
          content: const Text('Are you sure you want to reset all changes? This will restore the last saved data.'),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(context).pop(),
              child: const Text('Cancel'),
            ),
            ElevatedButton(
              onPressed: () {
                Navigator.of(context).pop();
                try {
                  if (_currentGymInfo != null) {
                    _populateForm(_currentGymInfo!);
                  } else {
                    _populateForm(GymInfo.defaultInfo());
                  }
                  SnackbarUtils.showSuccess(context, 'Form reset successfully');
                } catch (e) {
                  SnackbarUtils.showError(context, 'Error resetting form: $e');
                }
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.orange,
                foregroundColor: Colors.white,
              ),
              child: const Text('Reset'),
            ),
          ],
        );
      },
    );
  }

  Future<void> _saveGymInfo() async {
    // 检查表单状态
    if (_formKey.currentState == null) {
      SnackbarUtils.showError(context, 'Form is not properly initialized');
      return;
    }

    if (!_formKey.currentState!.validate()) {
      SnackbarUtils.showError(context, 'Please fix the errors in the form');
      return;
    }

    // 检查用户认证状态
    if (!GymService.isUserAuthenticated()) {
      SnackbarUtils.showError(context, 'Please log in to save gym information');
      return;
    }

    setState(() => _isSaving = true);

    try {
      final gymInfo = GymInfo(
        name: _nameController.text.trim(),
        description: _descriptionController.text.trim(),
        phone: _phoneController.text.trim(),
        email: _emailController.text.trim(),
        address: _addressController.text.trim(),
        website: _websiteController.text.trim(),
        operatingHours: Map.fromEntries(
          _hoursControllers.entries
              .where((entry) => entry.value.text.isNotEmpty)
              .map((entry) => MapEntry(entry.key, entry.value.text.trim())),
        ),
        amenities: List.from(_amenities),
        socialMedia: List.from(_socialMedia),
      );

      final success = await GymService.saveGymInfo(gymInfo);

      if (success) {
        SnackbarUtils.showSuccess(context, 'Gym information saved successfully!');
        setState(() {
          _currentGymInfo = gymInfo;
        });
      } else {
        SnackbarUtils.showError(context, 'Failed to save gym information');
      }
    } catch (e) {
      SnackbarUtils.showError(context, 'Error saving gym information: $e');
    } finally {
      if (mounted) {
        setState(() => _isSaving = false);
      }
    }
  }
}