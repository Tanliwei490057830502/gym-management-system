import 'package:flutter/material.dart';

class ChartsScreen extends StatefulWidget {
  const ChartsScreen({Key? key}) : super(key: key);

  @override
  State<ChartsScreen> createState() => _ChartsScreenState();
}

class _ChartsScreenState extends State<ChartsScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        width: double.infinity,
        height: double.infinity,
        color: Colors.grey.shade50,
        child: SingleChildScrollView(  // 添加滚动支持
          padding: const EdgeInsets.all(30),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // 页面标题
              _buildPageHeader(),

              const SizedBox(height: 30),

              // 空白内容区域
              _buildEmptyContent(),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildPageHeader() {
    return Row(
      children: [
        Expanded(  // 让标题区域可以自适应
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text(
                'Analytics & Reports',
                style: TextStyle(
                  fontSize: 28,
                  fontWeight: FontWeight.bold,
                  color: Colors.black87,
                ),
              ),
              const SizedBox(height: 8),
              Text(
                'Data analytics dashboard will appear here',
                style: TextStyle(
                  fontSize: 16,
                  color: Colors.grey.shade600,
                ),
              ),
            ],
          ),
        ),

        const SizedBox(width: 20),

        // 准备添加功能的按钮
        ElevatedButton.icon(
          onPressed: () {
            _showComingSoonDialog();
          },
          icon: const Icon(Icons.add_chart, size: 18),
          label: const Text('Add Chart'),
          style: ElevatedButton.styleFrom(
            backgroundColor: Colors.purple.shade600,
            foregroundColor: Colors.white,
            padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(10),
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildEmptyContent() {
    return Container(
      width: double.infinity,
      // 移除固定高度，让内容自适应
      constraints: BoxConstraints(
        minHeight: MediaQuery.of(context).size.height - 200, // 最小高度
      ),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: Colors.grey.shade200,
            blurRadius: 10,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Padding(
        padding: const EdgeInsets.all(40),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            // 空状态图标
            Container(
              padding: const EdgeInsets.all(30),
              decoration: BoxDecoration(
                color: Colors.grey.shade100,
                shape: BoxShape.circle,
              ),
              child: Icon(
                Icons.analytics_outlined,
                size: 80,
                color: Colors.grey.shade400,
              ),
            ),

            const SizedBox(height: 30),

            // 空状态文本
            const Text(
              'Analytics Dashboard',
              style: TextStyle(
                fontSize: 28,
                fontWeight: FontWeight.bold,
                color: Colors.black87,
              ),
            ),

            const SizedBox(height: 12),

            Text(
              'Your data analytics and reporting dashboard will be displayed here.\nConnect your data sources to start viewing insights.',
              textAlign: TextAlign.center,
              style: TextStyle(
                fontSize: 16,
                color: Colors.grey.shade600,
                height: 1.5,
              ),
            ),

            const SizedBox(height: 40),

            // 功能预览 - 改为网格布局以适应小屏幕
            LayoutBuilder(
              builder: (context, constraints) {
                if (constraints.maxWidth > 800) {
                  // 宽屏显示一行
                  return Row(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      _buildFeaturePreview(Icons.trending_up, 'Revenue\nTracking', Colors.green),
                      _buildFeaturePreview(Icons.people, 'Member\nAnalytics', Colors.blue),
                      _buildFeaturePreview(Icons.bar_chart, 'Performance\nReports', Colors.orange),
                      _buildFeaturePreview(Icons.calendar_today, 'Booking\nInsights', Colors.purple),
                    ],
                  );
                } else {
                  // 窄屏显示两行
                  return Column(
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                        children: [
                          _buildFeaturePreview(Icons.trending_up, 'Revenue\nTracking', Colors.green),
                          _buildFeaturePreview(Icons.people, 'Member\nAnalytics', Colors.blue),
                        ],
                      ),
                      const SizedBox(height: 20),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                        children: [
                          _buildFeaturePreview(Icons.bar_chart, 'Performance\nReports', Colors.orange),
                          _buildFeaturePreview(Icons.calendar_today, 'Booking\nInsights', Colors.purple),
                        ],
                      ),
                    ],
                  );
                }
              },
            ),

            const SizedBox(height: 40),

            // 操作按钮 - 改为响应式布局
            Wrap(
              spacing: 15,
              runSpacing: 15,
              alignment: WrapAlignment.center,
              children: [
                OutlinedButton.icon(
                  onPressed: () {
                    _showComingSoonDialog();
                  },
                  icon: const Icon(Icons.settings, size: 18),
                  label: const Text('Configure Data'),
                  style: OutlinedButton.styleFrom(
                    side: BorderSide(color: Colors.purple.shade600),
                    foregroundColor: Colors.purple.shade600,
                    padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 16),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(10),
                    ),
                  ),
                ),

                ElevatedButton.icon(
                  onPressed: () {
                    _showComingSoonDialog();
                  },
                  icon: const Icon(Icons.upload, size: 18),
                  label: const Text('Import Data'),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.purple.shade600,
                    foregroundColor: Colors.white,
                    padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 16),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(10),
                    ),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildFeaturePreview(IconData icon, String title, Color color) {
    return Container(
      width: 120, // 固定宽度，防止布局问题
      child: Column(
        children: [
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: color.withOpacity(0.1),
              borderRadius: BorderRadius.circular(12),
              border: Border.all(
                color: color.withOpacity(0.3),
                width: 2,
              ),
            ),
            child: Icon(
              icon,
              color: color,
              size: 28,
            ),
          ),
          const SizedBox(height: 10),
          Text(
            title,
            textAlign: TextAlign.center,
            style: TextStyle(
              fontSize: 12,
              fontWeight: FontWeight.w600,
              color: Colors.grey.shade700,
              height: 1.2,
            ),
          ),
        ],
      ),
    );
  }

  void _showComingSoonDialog() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(16),
        ),
        title: Row(
          children: [
            Icon(
              Icons.construction,
              color: Colors.orange.shade600,
            ),
            const SizedBox(width: 12),
            const Text('Coming Soon'),
          ],
        ),
        content: SingleChildScrollView(  // 防止对话框内容溢出
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text(
                'Analytics features are under development.',
                style: TextStyle(fontSize: 16),
              ),
              const SizedBox(height: 16),
              Text(
                'Upcoming features:',
                style: TextStyle(
                  fontSize: 14,
                  fontWeight: FontWeight.w600,
                  color: Colors.grey.shade700,
                ),
              ),
              const SizedBox(height: 8),
              ...[
                '📊 Revenue tracking and forecasting',
                '👥 Member analytics and trends',
                '📈 Performance dashboards',
                '📅 Booking and attendance insights',
                '📋 Custom reports generation',
              ].map((feature) => Padding(
                padding: const EdgeInsets.symmetric(vertical: 2),
                child: Text(
                  feature,
                  style: TextStyle(
                    fontSize: 13,
                    color: Colors.grey.shade600,
                  ),
                ),
              )),
            ],
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(),
            child: const Text('Got it'),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.of(context).pop();
              _showNotificationSettings();
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.purple.shade600,
            ),
            child: const Text(
              'Notify Me',
              style: TextStyle(color: Colors.white),
            ),
          ),
        ],
      ),
    );
  }

  void _showNotificationSettings() {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Row(
          children: [
            Icon(
              Icons.notifications_active,
              color: Colors.white,
            ),
            const SizedBox(width: 10),
            const Expanded(
              child: Text(
                'We\'ll notify you when analytics features are ready!',
                style: TextStyle(fontSize: 16),
              ),
            ),
          ],
        ),
        backgroundColor: Colors.green.shade600,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(10),
        ),
        margin: const EdgeInsets.all(20),
        duration: const Duration(seconds: 4),
      ),
    );
  }
}