// lib/screens/coaches_screen.dart
// 用途：管理员教练管理页面 - 主文件

import 'package:flutter/material.dart';
import '../services/coach_service.dart';
import '../widgets/coaches_tab.dart';
import '../widgets/binding_requests_tab.dart';
import '../widgets/courses_tab.dart';
import '../widgets/statistics_tab.dart';
import '../widgets/coaches_header.dart';

class CoachesScreen extends StatefulWidget {
  const CoachesScreen({Key? key}) : super(key: key);

  @override
  State<CoachesScreen> createState() => _CoachesScreenState();
}

class _CoachesScreenState extends State<CoachesScreen> with TickerProviderStateMixin {
  late TabController _tabController;
  bool _isLoading = false;
  Map<String, int> _statistics = {};

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 4, vsync: this);
    _loadStatistics();
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  Future<void> _loadStatistics() async {
    setState(() => _isLoading = true);
    try {
      final stats = await CoachService.getStatistics();
      setState(() => _statistics = stats);
    } catch (e) {
      print('加载统计信息失败: $e');
    } finally {
      setState(() => _isLoading = false);
    }
  }

  void _refreshStatistics() {
    _loadStatistics();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey.shade50,
      body: Column(
        children: [
          CoachesHeader(onRefreshStatistics: _refreshStatistics),
          _buildTabBar(),
          Expanded(
            child: TabBarView(
              controller: _tabController,
              children: [
                CoachesTab(onRefreshStatistics: _refreshStatistics),
                BindingRequestsTab(onRefreshStatistics: _refreshStatistics),
                CoursesTab(onRefreshStatistics: _refreshStatistics),
                StatisticsTab(
                  statistics: _statistics,
                  isLoading: _isLoading,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildTabBar() {
    return Container(
      color: Colors.white,
      child: TabBar(
        controller: _tabController,
        labelColor: Colors.purple.shade600,
        unselectedLabelColor: Colors.grey.shade600,
        indicatorColor: Colors.purple.shade600,
        indicatorWeight: 3,
        tabs: [
          Tab(
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Icon(Icons.people, size: 20),
                const SizedBox(width: 8),
                const Text('Coaches'),
                if (_statistics['total_coaches'] != null) ...[
                  const SizedBox(width: 8),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                    decoration: BoxDecoration(
                      color: Colors.blue.shade100,
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: Text(
                      '${_statistics['total_coaches']}',
                      style: TextStyle(
                        fontSize: 12,
                        color: Colors.blue.shade700,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ),
                ],
              ],
            ),
          ),
          Tab(
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Icon(Icons.pending_actions, size: 20),
                const SizedBox(width: 8),
                const Text('Requests'),
                if (_statistics['pending_requests'] != null && _statistics['pending_requests']! > 0) ...[
                  const SizedBox(width: 8),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                    decoration: BoxDecoration(
                      color: Colors.orange.shade100,
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: Text(
                      '${_statistics['pending_requests']}',
                      style: TextStyle(
                        fontSize: 12,
                        color: Colors.orange.shade700,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ),
                ],
              ],
            ),
          ),
          Tab(
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Icon(Icons.class_, size: 20),
                const SizedBox(width: 8),
                const Text('Courses'),
                if (_statistics['total_courses'] != null) ...[
                  const SizedBox(width: 8),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                    decoration: BoxDecoration(
                      color: Colors.green.shade100,
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: Text(
                      '${_statistics['total_courses']}',
                      style: TextStyle(
                        fontSize: 12,
                        color: Colors.green.shade700,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ),
                ],
              ],
            ),
          ),
          const Tab(
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Icon(Icons.analytics, size: 20),
                SizedBox(width: 8),
                Text('Statistics'),
              ],
            ),
          ),
        ],
      ),
    );
  }
}