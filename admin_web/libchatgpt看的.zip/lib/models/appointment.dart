// lib/models/appointment.dart
// 用途：预约数据模型

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';

/// 预约数据模型
class Appointment {
  final String id;
  final String userName;
  final String userEmail;
  final String coachName;
  final String gymName;
  final DateTime date;
  final String timeSlot;
  final String status; // 'pending', 'confirmed', 'completed', 'cancelled'
  final String? notes;
  final String? rejectReason;
  final DateTime? createdAt;
  final DateTime? updatedAt;

  Appointment({
    required this.id,
    required this.userName,
    required this.userEmail,
    required this.coachName,
    required this.gymName,
    required this.date,
    required this.timeSlot,
    required this.status,
    this.notes,
    this.rejectReason,
    this.createdAt,
    this.updatedAt,
  });

  /// 从 Firestore 数据创建对象
  factory Appointment.fromFirestore(DocumentSnapshot doc) {
    final data = doc.data() as Map<String, dynamic>;
    return Appointment(
      id: doc.id,
      userName: data['userName'] ?? 'Unknown User',
      userEmail: data['userEmail'] ?? '',
      coachName: data['coachName'] ?? 'Unknown Coach',
      gymName: data['gymName'] ?? 'Unknown Gym',
      date: (data['date'] as Timestamp).toDate(),
      timeSlot: data['timeSlot'] ?? '',
      status: data['status'] ?? 'pending',
      notes: data['notes'],
      rejectReason: data['rejectReason'],
      createdAt: (data['createdAt'] as Timestamp?)?.toDate(),
      updatedAt: (data['updatedAt'] as Timestamp?)?.toDate(),
    );
  }

  /// 转换为 Firestore 数据
  Map<String, dynamic> toMap() {
    return {
      'userName': userName,
      'userEmail': userEmail,
      'coachName': coachName,
      'gymName': gymName,
      'date': Timestamp.fromDate(date),
      'timeSlot': timeSlot,
      'status': status,
      'notes': notes,
      'rejectReason': rejectReason,
      'createdAt': createdAt != null ? Timestamp.fromDate(createdAt!) : null,
      'updatedAt': updatedAt != null ? Timestamp.fromDate(updatedAt!) : null,
    };
  }

  /// 状态显示文本
  String get statusDisplayText {
    switch (status) {
      case 'pending':
        return 'Pending';
      case 'confirmed':
        return 'Confirmed';
      case 'completed':
        return 'Completed';
      case 'cancelled':
        return 'Cancelled';
      default:
        return 'Unknown';
    }
  }

  /// 获取状态颜色
  Color get statusColor {
    switch (status) {
      case 'confirmed':
        return Colors.green;
      case 'completed':
        return Colors.purple;
      case 'cancelled':
        return Colors.red;
      default:
        return Colors.orange;
    }
  }

  /// 获取状态图标
  IconData get statusIcon {
    switch (status) {
      case 'confirmed':
        return Icons.check_circle;
      case 'completed':
        return Icons.done_all;
      case 'cancelled':
        return Icons.cancel;
      default:
        return Icons.schedule;
    }
  }

  /// 检查是否可以批准
  bool get canApprove => status == 'pending';

  /// 检查是否可以完成
  bool get canComplete => status == 'confirmed';

  /// 检查是否可以取消
  bool get canCancel => status == 'pending' || status == 'confirmed';

  /// 创建副本
  Appointment copyWith({
    String? id,
    String? userName,
    String? userEmail,
    String? coachName,
    String? gymName,
    DateTime? date,
    String? timeSlot,
    String? status,
    String? notes,
    String? rejectReason,
    DateTime? createdAt,
    DateTime? updatedAt,
  }) {
    return Appointment(
      id: id ?? this.id,
      userName: userName ?? this.userName,
      userEmail: userEmail ?? this.userEmail,
      coachName: coachName ?? this.coachName,
      gymName: gymName ?? this.gymName,
      date: date ?? this.date,
      timeSlot: timeSlot ?? this.timeSlot,
      status: status ?? this.status,
      notes: notes ?? this.notes,
      rejectReason: rejectReason ?? this.rejectReason,
      createdAt: createdAt ?? this.createdAt,
      updatedAt: updatedAt ?? this.updatedAt,
    );
  }

  @override
  String toString() {
    return 'Appointment(id: $id, userName: $userName, status: $status, date: $date)';
  }
}

/// 预约统计信息
class AppointmentStats {
  final int total;
  final int pending;
  final int confirmed;
  final int completed;
  final int cancelled;

  AppointmentStats({
    required this.total,
    required this.pending,
    required this.confirmed,
    required this.completed,
    required this.cancelled,
  });

  factory AppointmentStats.fromAppointments(List<Appointment> appointments) {
    return AppointmentStats(
      total: appointments.length,
      pending: appointments.where((a) => a.status == 'pending').length,
      confirmed: appointments.where((a) => a.status == 'confirmed').length,
      completed: appointments.where((a) => a.status == 'completed').length,
      cancelled: appointments.where((a) => a.status == 'cancelled').length,
    );
  }
}