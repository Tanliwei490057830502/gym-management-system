// lib/widgets/schedule_dashboard_widget.dart
// 用途：行程仪表盘组件（完全修复版）

import 'package:flutter/material.dart';
import '../models/models.dart';
import '../services/schedule_service.dart';
import '../utils/utils.dart';
import 'widgets.dart';

class ScheduleDashboardWidget extends StatelessWidget {
  final Function(int)? onNavigateToPage;

  const ScheduleDashboardWidget({
    super.key,
    this.onNavigateToPage,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        _buildSectionHeader('Today\'s Overview', Icons.today),
        const SizedBox(height: 16),
        Row(
          children: [
            Expanded(
              flex: 2,
              child: _buildTodayScheduleCard(),
            ),
            const SizedBox(width: 20),
            Expanded(
              flex: 1,
              child: _buildPendingApprovalsCard(),
            ),
          ],
        ),
        const SizedBox(height: 30),
        _buildSectionHeader('This Month', Icons.calendar_month),
        const SizedBox(height: 16),
        Row(
          children: [
            Expanded(
              flex: 1,
              child: _buildMonthlyCalendarCard(),
            ),
            const SizedBox(width: 20),
            Expanded(
              flex: 1,
              child: _buildMonthlyStatsCard(),
            ),
          ],
        ),
      ],
    );
  }

  Widget _buildSectionHeader(String title, IconData icon) {
    return Row(
      children: [
        Icon(icon, color: Colors.blue[600], size: 20),
        const SizedBox(width: 8),
        Text(
          title,
          style: const TextStyle(
            fontSize: 18,
            fontWeight: FontWeight.bold,
            color: Colors.black87,
          ),
        ),
      ],
    );
  }

  Widget _buildTodayScheduleCard() {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: Colors.grey[200]!,
            blurRadius: 8,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Column(
        children: [
          _buildCardHeader(
            'Today\'s Appointments',
            Icons.schedule,
            Colors.blue,
            onTap: () => onNavigateToPage?.call(1), // 跳转到今日行程页面
          ),
          StreamBuilder<List<Appointment>>(
            stream: ScheduleService.getTodayAppointments(),
            builder: (context, snapshot) {
              if (snapshot.connectionState == ConnectionState.waiting) {
                return const Padding(
                  padding: EdgeInsets.all(20),
                  child: Center(child: CircularProgressIndicator()),
                );
              }

              final appointments = snapshot.data ?? [];

              if (appointments.isEmpty) {
                return _buildEmptySchedule();
              }

              return Column(
                children: [
                  _buildTodayStats(appointments),
                  const Divider(height: 1),
                  _buildRecentAppointments(appointments.take(3).toList()),
                  if (appointments.length > 3)
                    _buildViewMoreButton(() => onNavigateToPage?.call(1)),
                ],
              );
            },
          ),
        ],
      ),
    );
  }

  Widget _buildPendingApprovalsCard() {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: Colors.grey[200]!,
            blurRadius: 8,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Column(
        children: [
          _buildCardHeader(
            'Pending Approvals',
            Icons.approval,
            Colors.orange,
            onTap: () => onNavigateToPage?.call(1),
          ),
          StreamBuilder<List<Appointment>>(
            stream: ScheduleService.getTodayPendingAppointments(),
            builder: (context, snapshot) {
              final pendingAppointments = snapshot.data ?? [];

              if (pendingAppointments.isEmpty) {
                return _buildNoPendingApprovals();
              }

              return Column(
                children: [
                  _buildPendingCount(pendingAppointments.length),
                  const Divider(height: 1),
                  ...pendingAppointments.take(2).map((appointment) =>
                      _buildPendingItem(appointment)),
                  if (pendingAppointments.length > 2)
                    _buildViewMoreButton(() => onNavigateToPage?.call(1)),
                ],
              );
            },
          ),
        ],
      ),
    );
  }

  Widget _buildMonthlyCalendarCard() {
    return Container(
      height: 320,
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: Colors.grey[200]!,
            blurRadius: 8,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Column(
        children: [
          _buildCardHeader(
            'Monthly Calendar',
            Icons.calendar_view_month,
            Colors.purple,
            onTap: () => onNavigateToPage?.call(2), // 跳转到月行程页面
          ),
          Expanded(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: CompactScheduleCalendar(
                month: DateTime.now(),
                onDateSelected: (date) => onNavigateToPage?.call(2),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildMonthlyStatsCard() {
    return Container(
      height: 320,
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: Colors.grey[200]!,
            blurRadius: 8,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Column(
        children: [
          _buildCardHeader(
            'Monthly Statistics',
            Icons.bar_chart,
            Colors.green,
            onTap: () => onNavigateToPage?.call(5), // 跳转到分析页面
          ),
          Expanded(
            child: StreamBuilder<List<Appointment>>(
              stream: ScheduleService.getCurrentMonthAppointments(),
              builder: (context, snapshot) {
                final appointments = snapshot.data ?? [];
                final stats = AppointmentStats.fromAppointments(appointments);

                return _buildMonthlyStatsContent(stats);
              },
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildCardHeader(String title, IconData icon, MaterialColor color, {VoidCallback? onTap}) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [color[100]!, color[50]!],
            begin: Alignment.centerLeft,
            end: Alignment.centerRight,
          ),
          borderRadius: const BorderRadius.only(
            topLeft: Radius.circular(16),
            topRight: Radius.circular(16),
          ),
        ),
        child: Row(
          children: [
            Icon(icon, color: color[700]!, size: 20),
            const SizedBox(width: 8),
            Text(
              title,
              style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.bold,
                color: color[700]!,
              ),
            ),
            const Spacer(),
            if (onTap != null)
              Icon(
                Icons.arrow_forward_ios,
                color: color[600]!,
                size: 14,
              ),
          ],
        ),
      ),
    );
  }

  Widget _buildEmptySchedule() {
    return Padding(
      padding: const EdgeInsets.all(32),
      child: Column(
        children: [
          Icon(
            Icons.free_breakfast,
            size: 48,
            color: Colors.grey[400],
          ),
          const SizedBox(height: 16),
          const Text(
            'No appointments today',
            style: TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.w500,
            ),
          ),
          Text(
            'Enjoy your free day!',
            style: TextStyle(
              fontSize: 14,
              color: Colors.grey[600],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildTodayStats(List<Appointment> appointments) {
    final stats = {
      'total': appointments.length,
      'pending': appointments.where((a) => a.status == 'pending').length,
      'confirmed': appointments.where((a) => a.status == 'confirmed').length,
      'completed': appointments.where((a) => a.status == 'completed').length,
    };

    return Padding(
      padding: const EdgeInsets.all(16),
      child: Row(
        children: [
          Expanded(child: _buildStatItem('Total', stats['total']!, Colors.blue)),
          Expanded(child: _buildStatItem('Pending', stats['pending']!, Colors.orange)),
          Expanded(child: _buildStatItem('Confirmed', stats['confirmed']!, Colors.green)),
          Expanded(child: _buildStatItem('Completed', stats['completed']!, Colors.purple)),
        ],
      ),
    );
  }

  Widget _buildStatItem(String label, int value, MaterialColor color) {
    return Column(
      children: [
        Text(
          value.toString(),
          style: TextStyle(
            fontSize: 20,
            fontWeight: FontWeight.bold,
            color: color,
          ),
        ),
        Text(
          label,
          style: TextStyle(
            fontSize: 12,
            color: Colors.grey[600],
          ),
        ),
      ],
    );
  }

  Widget _buildRecentAppointments(List<Appointment> appointments) {
    return Column(
      children: appointments.map((appointment) =>
          _buildAppointmentSummary(appointment)).toList(),
    );
  }

  Widget _buildAppointmentSummary(Appointment appointment) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(6),
            decoration: BoxDecoration(
              color: appointment.statusColor.withValues(alpha: 0.1),
              borderRadius: BorderRadius.circular(6),
            ),
            child: Icon(
              appointment.statusIcon,
              size: 14,
              color: appointment.statusColor,
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  '${appointment.timeSlot} - ${appointment.userName}',
                  style: const TextStyle(
                    fontSize: 14,
                    fontWeight: FontWeight.w500,
                  ),
                ),
                Text(
                  'Coach: ${appointment.coachName}',
                  style: TextStyle(
                    fontSize: 12,
                    color: Colors.grey[600],
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildNoPendingApprovals() {
    return Padding(
      padding: const EdgeInsets.all(24),
      child: Column(
        children: [
          Icon(
            Icons.check_circle,
            size: 40,
            color: Colors.green[400],
          ),
          const SizedBox(height: 12),
          const Text(
            'All caught up!',
            style: TextStyle(
              fontSize: 14,
              fontWeight: FontWeight.w500,
            ),
          ),
          Text(
            'No pending approvals',
            style: TextStyle(
              fontSize: 12,
              color: Colors.grey[600],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildPendingCount(int count) {
    return Padding(
      padding: const EdgeInsets.all(16),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
            decoration: BoxDecoration(
              color: Colors.orange[100],
              borderRadius: BorderRadius.circular(20),
            ),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Icon(
                  Icons.pending_actions,
                  size: 16,
                  color: Colors.orange[700],
                ),
                const SizedBox(width: 6),
                Text(
                  '$count Pending',
                  style: TextStyle(
                    fontSize: 12,
                    fontWeight: FontWeight.w600,
                    color: Colors.orange[700],
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildPendingItem(Appointment appointment) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
      child: Row(
        children: [
          Container(
            width: 8,
            height: 8,
            decoration: BoxDecoration(
              color: Colors.orange[400],
              shape: BoxShape.circle,
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  appointment.userName,
                  style: const TextStyle(
                    fontSize: 13,
                    fontWeight: FontWeight.w500,
                  ),
                ),
                Text(
                  '${appointment.timeSlot} - ${appointment.coachName}',
                  style: TextStyle(
                    fontSize: 11,
                    color: Colors.grey[600],
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildMonthlyStatsContent(AppointmentStats stats) {
    return Padding(
      padding: const EdgeInsets.all(16),
      child: Column(
        children: [
          _buildMonthlyStatRow('Total Appointments', stats.total, Icons.calendar_today, Colors.blue),
          const SizedBox(height: 12),
          _buildMonthlyStatRow('Pending Approval', stats.pending, Icons.schedule, Colors.orange),
          const SizedBox(height: 12),
          _buildMonthlyStatRow('Confirmed', stats.confirmed, Icons.check_circle, Colors.green),
          const SizedBox(height: 12),
          _buildMonthlyStatRow('Completed', stats.completed, Icons.done_all, Colors.purple),
          const Spacer(),
          _buildCompletionRate(stats),
        ],
      ),
    );
  }

  Widget _buildMonthlyStatRow(String label, int value, IconData icon, MaterialColor color) {
    return Row(
      children: [
        Icon(icon, size: 18, color: color),
        const SizedBox(width: 12),
        Expanded(
          child: Text(
            label,
            style: const TextStyle(
              fontSize: 14,
              fontWeight: FontWeight.w500,
            ),
          ),
        ),
        Text(
          value.toString(),
          style: TextStyle(
            fontSize: 16,
            fontWeight: FontWeight.bold,
            color: color,
          ),
        ),
      ],
    );
  }

  Widget _buildCompletionRate(AppointmentStats stats) {
    final total = stats.total;
    final completed = stats.completed;
    final rate = total > 0 ? (completed / total * 100).round() : 0;

    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: Colors.grey[50],
        borderRadius: BorderRadius.circular(8),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          const Text(
            'Completion Rate',
            style: TextStyle(
              fontSize: 12,
              fontWeight: FontWeight.w500,
            ),
          ),
          Text(
            '$rate%',
            style: TextStyle(
              fontSize: 14,
              fontWeight: FontWeight.bold,
              color: rate >= 80 ? Colors.green : rate >= 60 ? Colors.orange : Colors.red,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildViewMoreButton(VoidCallback onTap) {
    return Padding(
      padding: const EdgeInsets.all(12),
      child: Center(
        child: TextButton(
          onPressed: onTap,
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(
                'View More',
                style: TextStyle(
                  fontSize: 12,
                  color: Colors.blue[600],
                ),
              ),
              const SizedBox(width: 4),
              Icon(
                Icons.arrow_forward,
                size: 14,
                color: Colors.blue[600],
              ),
            ],
          ),
        ),
      ),
    );
  }
}